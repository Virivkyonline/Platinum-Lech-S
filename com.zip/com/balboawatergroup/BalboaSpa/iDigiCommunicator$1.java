package com.balboawatergroup.BalboaSpa;
 class iDigiCommunicator$1 extends android.os.Handler {
    final synthetic com.balboawatergroup.BalboaSpa.iDigiCommunicator this$0;

    iDigiCommunicator$1(com.balboawatergroup.BalboaSpa.iDigiCommunicator p1)
    {
        this.this$0 = p1;
        return;
    }

    public void handleMessage(android.os.Message p2)
    {
        // Both branches of the condition point to the same code.
        // if (p2.what != 0) {
            return;
        // }
    }
}
