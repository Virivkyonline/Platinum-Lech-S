package com.balboawatergroup.BalboaSpa;
 class ConfigureActivity$3 implements android.widget.AdapterView$OnItemSelectedListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConfigureActivity this$0;

    ConfigureActivity$3(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onItemSelected(android.widget.AdapterView p4, android.view.View p5, int p6, long p7)
    {
        com.balboawatergroup.BalboaSpa.WifiNetwork v0 = com.balboawatergroup.BalboaSpa.ConfigureActivity.access$100(this.this$0).getItem(p6);
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$200(this.this$0).setText(v0.getName());
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$300(this.this$0).setChecked(v0.IsWPA);
        android.util.Log.i("Balboa", v0.getName());
        return;
    }

    public void onNothingSelected(android.widget.AdapterView p1)
    {
        return;
    }
}
