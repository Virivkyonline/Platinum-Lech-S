package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$13 implements android.widget.TimePicker$OnTimeChangedListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$13(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeChanged(android.widget.TimePicker p1, int p2, int p3)
    {
        return;
    }
}
