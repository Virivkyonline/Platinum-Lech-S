package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$4$1 implements java.lang.Runnable {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment$4 this$1;

    ConnectDialogFragment$4$1(com.balboawatergroup.BalboaSpa.ConnectDialogFragment$4 p1)
    {
        this.this$1 = p1;
        return;
    }

    public void run()
    {
        if (this.this$1.this$0.progress != null) {
            this.this$1.this$0.progress.dismiss();
        }
        return;
    }
}
