package com.balboawatergroup.BalboaSpa;
public final enum class ConnectionMethod extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.ConnectionMethod[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.ConnectionMethod KnownNetwork;
    public static final enum com.balboawatergroup.BalboaSpa.ConnectionMethod WPS;
    public int id;

    static ConnectionMethod()
    {
        com.balboawatergroup.BalboaSpa.ConnectionMethod.KnownNetwork = new com.balboawatergroup.BalboaSpa.ConnectionMethod("KnownNetwork", 0, 1);
        com.balboawatergroup.BalboaSpa.ConnectionMethod.WPS = new com.balboawatergroup.BalboaSpa.ConnectionMethod("WPS", 1, 2);
        com.balboawatergroup.BalboaSpa.ConnectionMethod[] v0_0 = new com.balboawatergroup.BalboaSpa.ConnectionMethod[2];
        v0_0[0] = com.balboawatergroup.BalboaSpa.ConnectionMethod.KnownNetwork;
        v0_0[1] = com.balboawatergroup.BalboaSpa.ConnectionMethod.WPS;
        com.balboawatergroup.BalboaSpa.ConnectionMethod.$VALUES = v0_0;
        return;
    }

    private ConnectionMethod(String p1, int p2, int p3)
    {
        super(p1, p2);
        super.id = p3;
        return;
    }

    public static com.balboawatergroup.BalboaSpa.ConnectionMethod valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.ConnectionMethod) Enum.valueOf(com.balboawatergroup.BalboaSpa.ConnectionMethod, p1));
    }

    public static com.balboawatergroup.BalboaSpa.ConnectionMethod[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.ConnectionMethod[]) com.balboawatergroup.BalboaSpa.ConnectionMethod.$VALUES.clone());
    }
}
