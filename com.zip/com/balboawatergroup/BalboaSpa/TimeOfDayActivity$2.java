package com.balboawatergroup.BalboaSpa;
 class TimeOfDayActivity$2 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.TimeOfDayActivity this$0;

    TimeOfDayActivity$2(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        this.this$0.showDialog(999);
        return;
    }
}
