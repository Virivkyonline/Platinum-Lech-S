package com.balboawatergroup.BalboaSpa;
public class SpaModuleIdentification implements java.io.Serializable {
    private static final long serialVersionUID;
    public byte[] iDigiDeviceID;

    public SpaModuleIdentification()
    {
        byte[] v0_1 = new byte[16];
        this.iDigiDeviceID = v0_1;
        return;
    }
}
