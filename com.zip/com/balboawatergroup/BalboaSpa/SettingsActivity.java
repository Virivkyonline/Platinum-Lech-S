package com.balboawatergroup.BalboaSpa;
public class SettingsActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    private float currentTempSetting;
    private int ignoreCycleCounter;
    private Boolean ignoreTargetTemp;
    private android.widget.ImageView imgAccessibility;
    private Boolean isUserTouchingSeekbar;
    private android.content.BroadcastReceiver mMessageReceiver;
    private float maxTemp;
    private float minTemp;
    private final int numberOfCyclesToIgnore;
    private int panelUpdatesToIgnore;
    private android.widget.SeekBar seekbar;
    private android.widget.ToggleButton tbHeatMode;
    private android.widget.ToggleButton tbTempRange;
    private android.widget.ToggleButton tbTempUnit;
    private android.widget.TextView tvMaxTemp;
    private android.widget.TextView tvMinTemp;
    private android.widget.TextView tvTargetTemp;

    public SettingsActivity()
    {
        this.ignoreTargetTemp = Boolean.valueOf(0);
        this.ignoreCycleCounter = 0;
        this.numberOfCyclesToIgnore = 3;
        this.isUserTouchingSeekbar = Boolean.valueOf(0);
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.SettingsActivity$2(this);
        return;
    }

    static synthetic android.widget.ToggleButton access$000(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        return p1.tbTempUnit;
    }

    static synthetic float access$100(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        return p1.currentTempSetting;
    }

    static synthetic float access$102(com.balboawatergroup.BalboaSpa.SettingsActivity p0, float p1)
    {
        p0.currentTempSetting = p1;
        return p1;
    }

    static synthetic float access$200(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        return p1.minTemp;
    }

    static synthetic android.widget.TextView access$300(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        return p1.tvTargetTemp;
    }

    static synthetic Boolean access$402(com.balboawatergroup.BalboaSpa.SettingsActivity p0, Boolean p1)
    {
        p0.isUserTouchingSeekbar = p1;
        return p1;
    }

    static synthetic int access$500(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        return p1.panelUpdatesToIgnore;
    }

    static synthetic int access$502(com.balboawatergroup.BalboaSpa.SettingsActivity p0, int p1)
    {
        p0.panelUpdatesToIgnore = p1;
        return p1;
    }

    static synthetic int access$510(com.balboawatergroup.BalboaSpa.SettingsActivity p2)
    {
        int v0 = p2.panelUpdatesToIgnore;
        p2.panelUpdatesToIgnore = (v0 - 1);
        return v0;
    }

    static synthetic Boolean access$602(com.balboawatergroup.BalboaSpa.SettingsActivity p0, Boolean p1)
    {
        p0.ignoreTargetTemp = p1;
        return p1;
    }

    static synthetic void access$700(com.balboawatergroup.BalboaSpa.SettingsActivity p0)
    {
        p0.refreshControls();
        return;
    }

    private void getControls()
    {
        this.tvTargetTemp = ((android.widget.TextView) this.findViewById(2131230788));
        this.tvMinTemp = ((android.widget.TextView) this.findViewById(2131230795));
        this.tvMaxTemp = ((android.widget.TextView) this.findViewById(2131230796));
        this.tbTempUnit = ((android.widget.ToggleButton) this.findViewById(2131230797));
        this.tbHeatMode = ((android.widget.ToggleButton) this.findViewById(2131230799));
        this.tbTempRange = ((android.widget.ToggleButton) this.findViewById(2131230801));
        this.imgAccessibility = ((android.widget.ImageView) this.findViewById(2131230734));
        this.seekbar = ((android.widget.SeekBar) this.findViewById(2131230794));
        return;
    }

    private void refreshControls()
    {
        android.widget.ToggleButton v1_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v0 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        if (v0.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius) {
            v1_2 = 0;
        } else {
            v1_2 = 1;
        }
        android.widget.ToggleButton v1_23;
        this.tbTempUnit.setChecked(v1_2);
        if (v0.HeatMode != com.balboawatergroup.BalboaSpa.HeatMode.Ready) {
            v1_23 = 0;
        } else {
            v1_23 = 1;
        }
        android.widget.ToggleButton v1_25;
        this.tbHeatMode.setChecked(v1_23);
        if (v0.TemperateRange != com.balboawatergroup.BalboaSpa.TemperatureRange.High) {
            v1_25 = 0;
        } else {
            v1_25 = 1;
        }
        this.tbTempRange.setChecked(v1_25);
        if (v0.TemperateRange != com.balboawatergroup.BalboaSpa.TemperatureRange.High) {
            if (v0.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit) {
                this.minTemp = 1092616192;
                this.maxTemp = 1104412672;
            } else {
                this.minTemp = 1112014848;
                this.maxTemp = 1117782016;
            }
        } else {
            if (v0.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit) {
                this.minTemp = 1104412672;
                this.maxTemp = 1109393408;
            } else {
                this.minTemp = 1117782016;
                this.maxTemp = 1120927744;
            }
        }
        this.tvMinTemp.setText(com.balboawatergroup.BalboaSpa.Utility.formatDouble(((double) this.minTemp)));
        this.tvMaxTemp.setText(com.balboawatergroup.BalboaSpa.Utility.formatDouble(((double) this.maxTemp)));
        if (!this.isUserTouchingSeekbar.booleanValue()) {
            if (this.ignoreTargetTemp.booleanValue()) {
                this.ignoreCycleCounter = (this.ignoreCycleCounter + 1);
                if (this.ignoreCycleCounter == 3) {
                    this.ignoreCycleCounter = 0;
                    this.ignoreTargetTemp = Boolean.valueOf(0);
                }
            } else {
                if (!this.tbTempUnit.isChecked()) {
                    this.seekbar.setMax(((int) (this.maxTemp - this.minTemp)));
                    this.seekbar.setProgress(((int) (v0.TargetTemperature - this.minTemp)));
                } else {
                    this.seekbar.setMax(((int) ((this.maxTemp - this.minTemp) * 1073741824)));
                    this.seekbar.setProgress(((int) ((v0.TargetTemperature - this.minTemp) * 1073741824)));
                }
            }
        }
        if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL) {
            if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT) {
                if (v0.AccessibilityType == com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE) {
                    this.imgAccessibility.setImageResource(2130837562);
                    this.imgAccessibility.setVisibility(0);
                    this.seekbar.setEnabled(0);
                    this.tbTempUnit.setEnabled(0);
                    this.tbHeatMode.setEnabled(0);
                    this.tbTempRange.setEnabled(0);
                }
            } else {
                this.imgAccessibility.setImageResource(2130837563);
                this.imgAccessibility.setVisibility(0);
                this.seekbar.setEnabled(0);
                this.tbTempUnit.setEnabled(0);
                this.tbHeatMode.setEnabled(0);
                this.tbTempRange.setEnabled(0);
            }
        } else {
            this.imgAccessibility.setVisibility(4);
            this.seekbar.setEnabled(1);
            this.tbTempUnit.setEnabled(1);
            this.tbHeatMode.setEnabled(1);
            this.tbTempRange.setEnabled(1);
        }
        return;
    }

    public void addListenersOnButtons()
    {
        this.tbTempRange.setOnClickListener(new com.balboawatergroup.BalboaSpa.SettingsActivity$3(this));
        this.tbHeatMode.setOnClickListener(new com.balboawatergroup.BalboaSpa.SettingsActivity$4(this));
        this.tbTempUnit.setOnClickListener(new com.balboawatergroup.BalboaSpa.SettingsActivity$5(this));
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        this.panelUpdatesToIgnore = 0;
        super.onCreate(p5);
        this.setContentView(2130903047);
        this.getControls();
        this.seekbar.setOnSeekBarChangeListener(new com.balboawatergroup.BalboaSpa.SettingsActivity$1(this));
        this.refreshControls();
        this.addListenersOnButtons();
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter("spa-state-updated"));
        return;
    }

    protected void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this).unregisterReceiver(this.mMessageReceiver);
        super.onDestroy();
        return;
    }

    public void onWindowFocusChanged(boolean p3)
    {
        if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode != "Wifi") {
            com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles);
        }
        return;
    }

    public void showAdvanced(android.view.View p3)
    {
        this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.AdvancedSettingsActivity));
        return;
    }

    public void showFilterCycles(android.view.View p3)
    {
        this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.FilterCyclesActivity));
        return;
    }

    public void showTimeOfDay(android.view.View p3)
    {
        this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.TimeOfDayActivity));
        return;
    }
}
