package com.balboawatergroup.BalboaSpa;
public class iDigiCommunicator implements com.balboawatergroup.BalboaSpa.ISpaCommunicator {
    private android.content.Context context;
    public String deviceID;
    public android.os.Handler mainHandler;
    private com.balboawatergroup.BalboaSpa.iDigiThread myThread;

    public iDigiCommunicator(String p2, android.content.Context p3)
    {
        this.mainHandler = new com.balboawatergroup.BalboaSpa.iDigiCommunicator$1(this);
        this.deviceID = p2;
        this.context = p3;
        if ((com.balboawatergroup.BalboaSpa.Connectivity.isConnectedMobile(p3)) && (!this.hasShownCellularWarning())) {
            this.showCellularWarning(p3);
        }
        this.StartThread(p3);
        return;
    }

    private com.balboawatergroup.BalboaSpa.SpaControlState GetIntialDemoState()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v1_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        v1_1.Aux1On = 1;
        v1_1.Aux2On = 0;
        v1_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Off;
        v1_1.Light1On = 1;
        v1_1.Light2On = 0;
        v1_1.MisterOn = 0;
        v1_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v1_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v1_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.High;
        v1_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v1_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v1_1.Is24HourTime = 0;
        java.util.Calendar.getInstance();
        v1_1.CurrentTimeHour = 10;
        return v1_1;
    }

    private void SendButtonCommand(String p2, com.balboawatergroup.BalboaSpa.SpaButtonCode p3, String p4)
    {
        this.SendCommand(p2, Integer.toString(p3.code), p4);
        return;
    }

    private void SendCommand(String p4, String p5, String p6)
    {
        if (this.myThread != null) {
            android.os.Message v1_1 = new android.os.Message();
            android.os.Bundle v0_1 = new android.os.Bundle();
            v1_1.what = 0;
            v0_1.putString("target", p4);
            v0_1.putString("content", p5);
            v0_1.putString("deviceID", p6);
            v1_1.setData(v0_1);
            this.myThread.getHandler().sendMessage(v1_1);
        }
        return;
    }

    private boolean hasShownCellularWarning()
    {
        return com.balboawatergroup.BalboaSpa.Utility.GetBooleanSettingValue("hasShownCellularWarning", Boolean.valueOf(0), this.context).booleanValue();
    }

    private void showCellularWarning(android.content.Context p4)
    {
        new android.app.AlertDialog$Builder(p4).setTitle("Data Warning").setMessage("You are using the cellular data network which may incur data usage charges on your mobile plan.").setPositiveButton("Ok", new com.balboawatergroup.BalboaSpa.iDigiCommunicator$2(this)).show();
        com.balboawatergroup.BalboaSpa.Utility.StoreBooleanSettingValue("hasShownCellularWarning", Boolean.valueOf(1), p4);
        return;
    }

    public void Aux1ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux1, this.deviceID);
        return;
    }

    public void Aux2ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux2, this.deviceID);
        return;
    }

    public void BlowerControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Blower, this.deviceID);
        return;
    }

    public void ConnectToWifi(com.balboawatergroup.BalboaSpa.ConnectionMethod p1, com.balboawatergroup.BalboaSpa.SecurityType p2, String p3, String p4)
    {
        return;
    }

    public com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetCurrentConfiguration()
    {
        int v0_1;
        if (this.myThread == null) {
            v0_1 = 0;
        } else {
            v0_1 = this.myThread.CurrentConfiguration;
        }
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.SpaControlState GetCurrentState()
    {
        if ((this.myThread == null) || (this.myThread.CurrentState == null)) {
            com.balboawatergroup.BalboaSpa.SpaControlState v0_3 = this.GetIntialDemoState();
        } else {
            v0_3 = this.myThread.CurrentState;
        }
        return v0_3;
    }

    public com.balboawatergroup.BalboaSpa.SpaSystemInformation GetCurrentSystemInformation()
    {
        com.balboawatergroup.BalboaSpa.SpaSystemInformation v0_1 = new com.balboawatergroup.BalboaSpa.SpaSystemInformation();
        v0_1.isOldVersion = 0;
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.FilterCycle GetFilterCycle()
    {
        int v0_2;
        if (this.myThread.CurrentFilterCycle == null) {
            v0_2 = 0;
        } else {
            v0_2 = this.myThread.CurrentFilterCycle;
        }
        return v0_2;
    }

    public com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState()
    {
        com.balboawatergroup.BalboaSpa.WifiSocketState v0_1;
        if (this.myThread == null) {
            v0_1 = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
        } else {
            v0_1 = this.myThread.ConnectionState;
        }
        return v0_1;
    }

    public boolean HasCurrentDeviceConfig()
    {
        return this.myThread.HasCurrentDeviceConfig;
    }

    public void HeatModePushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.HeatMode, this.deviceID);
        return;
    }

    public void Light1ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Light1, this.deviceID);
        return;
    }

    public void Light2ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Light2, this.deviceID);
        return;
    }

    public void MisterControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Mister, this.deviceID);
        return;
    }

    public void Pump1ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump1, this.deviceID);
        return;
    }

    public void Pump2ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump2, this.deviceID);
        return;
    }

    public void Pump3ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump3, this.deviceID);
        return;
    }

    public void Pump4ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump4, this.deviceID);
        return;
    }

    public void Pump5ControlPushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump5, this.deviceID);
        return;
    }

    public void SaveFilterCycle(com.balboawatergroup.BalboaSpa.FilterCycle p11)
    {
        int v2;
        if (!p11.FilterCycle2Enabled) {
            v2 = 0;
        } else {
            v2 = 128;
        }
        int v3 = p11.FilterCycle2StartsAtHour;
        byte[] v0 = new byte[13];
        v0[0] = 13;
        v0[1] = 10;
        v0[2] = -65;
        v0[3] = 35;
        v0[4] = ((byte) p11.FilterCycle1StartsAtHour);
        v0[5] = ((byte) p11.FilterCycle1StartsAtMinute);
        v0[6] = ((byte) p11.FilterCycle1DurationHour);
        v0[7] = ((byte) p11.FilterCycle1DurationMinute);
        v0[8] = ((byte) (v2 | v3));
        v0[9] = ((byte) p11.FilterCycle2StartsAtMinute);
        v0[10] = ((byte) p11.FilterCycle2DurationHour);
        v0[11] = ((byte) p11.FilterCycle2DurationMinute);
        v0[12] = 0;
        v0[12] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 12, 0);
        this.SendCommand("Filters", android.util.Base64.encodeToString(v0, 2), this.deviceID);
        return;
    }

    public void SendDevicePresentQuery()
    {
        return;
    }

    public void SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType p4)
    {
        switch (com.balboawatergroup.BalboaSpa.iDigiCommunicator$3.$SwitchMap$com$balboawatergroup$BalboaSpa$PanelRequestType[p4.ordinal()]) {
            case 1:
            case 3:
            default:
                break;
            case 2:
                android.util.Log.i("Balboa", "Requesting filter cycles");
                this.SendCommand("Request", "Filters", this.deviceID);
            case 1:
            case 3:
                break;
        }
        return;
    }

    public void Set24HourTime(boolean p4)
    {
        if (!p4) {
            this.SendCommand("TimeFormat", "12", this.deviceID);
        } else {
            this.SendCommand("TimeFormat", "24", this.deviceID);
        }
        return;
    }

    public void SetTargetTemperature(float p4)
    {
        if (this.GetCurrentState().TemperatureScale == com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius) {
            p4 *= 1073741824;
        }
        this.SendCommand("SetTemp", Float.toString(p4), this.deviceID);
        return;
    }

    public void SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale p4)
    {
        if (p4 != com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius) {
            this.SendCommand("TempUnits", "F", this.deviceID);
        } else {
            this.SendCommand("TempUnits", "C", this.deviceID);
        }
        return;
    }

    public void SetTime(int p9, int p10, boolean p11)
    {
        String v4_3 = new Object[1];
        v4_3[0] = Integer.valueOf(p9);
        String v0 = String.format("%02d", v4_3);
        String v4_0 = new Object[1];
        v4_0[0] = Integer.valueOf(p10);
        this.SendCommand("SystemTime", new StringBuilder().append(v0).append(":").append(String.format("%02d", v4_0)).toString(), this.deviceID);
        return;
    }

    public void StartThread(android.content.Context p5)
    {
        this.context = p5;
        if (this.myThread == null) {
            this.myThread = new com.balboawatergroup.BalboaSpa.iDigiThread(this.mainHandler, this.context, this.deviceID);
            this.myThread.stopped = 0;
            this.myThread.start();
        }
        return;
    }

    public void StopThread()
    {
        if (this.myThread != null) {
            this.myThread.stopped = 1;
            this.myThread.ConnectionState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
            this.myThread.interrupt();
            this.myThread = 0;
        }
        return;
    }

    public void TempRangePushed()
    {
        this.SendButtonCommand("Button", com.balboawatergroup.BalboaSpa.SpaButtonCode.TempRange, this.deviceID);
        return;
    }
}
