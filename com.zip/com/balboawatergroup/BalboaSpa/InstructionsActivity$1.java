package com.balboawatergroup.BalboaSpa;
 class InstructionsActivity$1 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.InstructionsActivity this$0;

    InstructionsActivity$1(com.balboawatergroup.BalboaSpa.InstructionsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p4)
    {
        if (com.balboawatergroup.BalboaSpa.InstructionsActivity.access$000(this.this$0).isChecked()) {
            com.balboawatergroup.BalboaSpa.Utility.StoreBooleanSettingValue("showInstructions", Boolean.valueOf(0), this.this$0.getApplicationContext());
        }
        this.this$0.finish();
        return;
    }
}
