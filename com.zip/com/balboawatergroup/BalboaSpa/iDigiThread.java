package com.balboawatergroup.BalboaSpa;
public class iDigiThread extends java.lang.Thread {
    public com.balboawatergroup.BalboaSpa.WifiSocketState ConnectionState;
    public com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration CurrentConfiguration;
    public com.balboawatergroup.BalboaSpa.FilterCycle CurrentFilterCycle;
    public com.balboawatergroup.BalboaSpa.SpaControlState CurrentState;
    public boolean HasCurrentDeviceConfig;
    private boolean IsLockedOut;
    private final android.content.Context context;
    private final String deviceConfigurationFileName;
    public String deviceID;
    private final String digiDeviceCoreURL;
    private final String digiFileURL;
    private final String digiURL;
    private final String messageFileName;
    private volatile java.util.Queue messageQueue;
    private long mostRecentPanelUpdate;
    private android.os.Handler myThreadHandler;
    private final String panelUpdateFileName;
    private android.os.Handler parentHandler;
    private final String password;
    public volatile boolean stopped;
    private final String username;

    public iDigiThread(android.os.Handler p3, android.content.Context p4, String p5)
    {
        this.username = "BalboaWaterAndroidApp";
        this.password = "SW2Bra7a!";
        this.digiURL = "http://my.idigi.com/ws/sci";
        this.digiFileURL = "https://my.idigi.com/ws/data/~/";
        this.digiDeviceCoreURL = "https://my.idigi.com/ws/DeviceCore";
        this.panelUpdateFileName = "PanelUpdate.txt";
        this.deviceConfigurationFileName = "DeviceConfiguration.txt";
        this.messageFileName = "message.txt";
        this.myThreadHandler = new com.balboawatergroup.BalboaSpa.iDigiThread$1(this);
        this.CurrentFilterCycle = 0;
        this.HasCurrentDeviceConfig = 0;
        this.parentHandler = p3;
        this.context = p4;
        this.deviceID = p5;
        this.ConnectionState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
        this.IsLockedOut = 0;
        this.messageQueue = new java.util.LinkedList();
        return;
    }

    private void FetchDigiMessageFile()
    {
        String v9_1 = new Object[3];
        v9_1[0] = "https://my.idigi.com/ws/data/~/";
        v9_1[1] = this.deviceID;
        v9_1[2] = "message.txt";
        try {
            org.apache.http.HttpResponse v4 = this.getDefaultHttpClient().execute(new org.apache.http.client.methods.HttpGet(String.format("%s%s/%s", v9_1)));
        } catch (java.io.IOException v0_0) {
            android.util.Log.e("Balboa", "Exception fetching panel update", v0_0);
        }
        org.apache.http.StatusLine v6 = 0;
        if (v4 != null) {
            v6 = v4.getStatusLine();
        }
        // Both branches of the condition point to the same code.
        // if (v6.getStatusCode() == 200) {
            try {
                this.HandleDigiMessageResponse(org.apache.http.util.EntityUtils.toString(v4.getEntity()));
            } catch (java.io.IOException v0_1) {
                android.util.Log.e("Balboa", "Exception fetching panel update", v0_1);
            }
            return;
        // }
    }

    private com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetIDigiDeviceConfigurationFromFileService()
    {
        com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration v0_1 = new com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration();
        try {
            org.apache.http.impl.client.DefaultHttpClient v3 = this.getDefaultHttpClient();
            org.apache.http.client.methods.HttpPost v4_1 = new org.apache.http.client.methods.HttpPost("http://my.idigi.com/ws/sci");
            v4_1.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            v4_1.setHeader("Pragma", "no-cache");
            try {
                String v11_2 = new Object[2];
                v11_2[0] = this.deviceID;
                v11_2[1] = "DeviceConfiguration.txt";
                String v6 = String.format("<sci_request version=\"1.0\"><file_system cache=\"false\"><targets><device id=\"%s\"/></targets><commands><get_file path=\"%s\"/></commands></file_system></sci_request>", v11_2);
                android.util.Log.i("Balboa", v6);
                org.apache.http.entity.StringEntity v9_1 = new org.apache.http.entity.StringEntity(v6, "UTF-8");
                v9_1.setContentType("text/xml");
                v4_1.setEntity(v9_1);
                String v8 = org.apache.http.util.EntityUtils.toString(v3.execute(v4_1).getEntity());
                v0_1 = this.HandleDeviceConfigResponse(v8);
                this.HasCurrentDeviceConfig = 1;
                android.util.Log.i("Balboa", v8);
            } catch (java.io.IOException v2_1) {
                android.util.Log.e("Balboa", "ClientProtocolException posting to idigi", v2_1);
            } catch (java.io.IOException v2_0) {
                android.util.Log.e("Balboa", "IOException posting to idigi", v2_0);
            }
            return v0_1;
        } catch (java.io.IOException v2_2) {
            v2_2.printStackTrace();
            return v0_1;
        } catch (String v10_9) {
            throw v10_9;
        }
    }

    private com.balboawatergroup.BalboaSpa.SpaControlState GetIDigiPanelUpdateFromFileService()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v9_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        v9_1.SuccessfulFetch = 0;
        try {
            org.apache.http.impl.client.DefaultHttpClient v2 = this.getDefaultHttpClient();
            org.apache.http.client.methods.HttpPost v3_0 = new org.apache.http.client.methods.HttpPost(new StringBuilder().append("http://my.idigi.com/ws/sci?unused=").append(this.someRandomString()).toString());
            try {
                String v11_3 = new Object[2];
                v11_3[0] = this.deviceID;
                v11_3[1] = "PanelUpdate.txt";
                String v5 = String.format("<sci_request version=\"1.0\"><file_system cache=\"false\"><targets><device id=\"%s\"/></targets><commands><get_file path=\"%s\"/></commands></file_system></sci_request>", v11_3);
                android.util.Log.i("Balboa", v5);
                org.apache.http.entity.StringEntity v8_1 = new org.apache.http.entity.StringEntity(v5, "UTF-8");
                v8_1.setContentType("text/xml");
                v3_0.setEntity(v8_1);
                v3_0.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                v3_0.setHeader("Pragma", "no-cache");
                String v7 = org.apache.http.util.EntityUtils.toString(v2.execute(v3_0).getEntity());
                v9_1 = this.HandlePanelUpdateResponse(v7);
                android.util.Log.i("Balboa", v7);
            } catch (java.io.IOException v1_1) {
                android.util.Log.e("Balboa", "ClientProtocolException posting to idigi", v1_1);
            } catch (java.io.IOException v1_0) {
                android.util.Log.e("Balboa", "IOException posting to idigi", v1_0);
            }
            return v9_1;
        } catch (java.io.IOException v1_2) {
            v1_2.printStackTrace();
            return v9_1;
        } catch (String v10_13) {
            throw v10_13;
        }
    }

    private com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration HandleDeviceConfigResponse(String p8)
    {
        com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration v0_1 = new com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration();
        String v3 = com.balboawatergroup.BalboaSpa.SpaXmlParser.ParsePanelUpdate(p8);
        if (v3 != "") {
            byte[] v1 = android.util.Base64.decode(v3.getBytes(), 0);
            byte[] v2 = new byte[(v1.length + 1)];
            v2[0] = 126;
            System.arraycopy(v1, 0, v2, 1, v1.length);
            v0_1 = com.balboawatergroup.BalboaSpa.PacketParser.ParseDeviceConfiguration(v2);
        }
        return v0_1;
    }

    private void HandleDigiMessageResponse(String p5)
    {
        com.balboawatergroup.BalboaSpa.DigiUserMessage v1 = com.balboawatergroup.BalboaSpa.SpaXmlParser.ParseDigiMessage(p5);
        if ((v1.text != null) && (v1.text != "")) {
            android.content.Intent v0_1 = new android.content.Intent("digi-message");
            v0_1.putExtra("text", v1.text);
            v0_1.putExtra("url", v1.url);
            v0_1.putExtra("lockout", v1.lockout.toString());
            if (v1.lockout.booleanValue()) {
                this.IsLockedOut = 1;
            }
            android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(v0_1);
        }
        return;
    }

    private void HandleFilterResponse(String p10)
    {
        try {
            String v2 = com.balboawatergroup.BalboaSpa.SpaXmlParser.ParseFilterCycle(p10);
        } catch (java.io.IOException v1_1) {
            v1_1.printStackTrace();
        } catch (java.io.IOException v1_0) {
            v1_0.printStackTrace();
        }
        if (v2 != "") {
            byte[] v0 = android.util.Base64.decode(v2.getBytes(), 0);
            byte[] v4 = new byte[(v0.length + 1)];
            v4[0] = 126;
            System.arraycopy(v0, 0, v4, 1, v0.length);
            this.CurrentFilterCycle = com.balboawatergroup.BalboaSpa.PacketParser.ParseFilterCycle(v4);
            android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(new android.content.Intent(com.balboawatergroup.BalboaSpa.BroadcastMessage.FilterCyclesUpdated.name()));
        }
        return;
    }

    private com.balboawatergroup.BalboaSpa.SpaControlState HandlePanelUpdateResponse(String p8)
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v3_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        String v1 = com.balboawatergroup.BalboaSpa.SpaXmlParser.ParsePanelUpdate(p8);
        if (v1 != "") {
            byte[] v0 = android.util.Base64.decode(v1.getBytes(), 0);
            byte[] v2 = new byte[(v0.length + 1)];
            v2[0] = 126;
            System.arraycopy(v0, 0, v2, 1, v0.length);
            v3_1 = com.balboawatergroup.BalboaSpa.PacketParser.ParsePanelUpdate(v2);
            this.mostRecentPanelUpdate = System.currentTimeMillis();
            v3_1.SuccessfulFetch = 1;
        }
        return v3_1;
    }

    private void ProvisionDevice()
    {
        try {
            org.apache.http.impl.client.DefaultHttpClient v2 = this.getDefaultHttpClient();
            org.apache.http.client.methods.HttpPost v3_1 = new org.apache.http.client.methods.HttpPost("https://my.idigi.com/ws/DeviceCore");
            try {
                String v10_3 = new Object[1];
                v10_3[0] = this.deviceID;
                String v5 = String.format("<DeviceCore><devConnectwareId>%s</devConnectwareId></DeviceCore>", v10_3);
                android.util.Log.i("Balboa", v5);
                org.apache.http.entity.StringEntity v8_1 = new org.apache.http.entity.StringEntity(v5, "UTF-8");
                v8_1.setContentType("text/xml");
                v3_1.setEntity(v8_1);
                android.util.Log.i("Balboa", org.apache.http.util.EntityUtils.toString(v2.execute(v3_1).getEntity()));
            } catch (java.io.IOException v1_1) {
                android.util.Log.e("Balboa", "ClientProtocolException posting to idigi", v1_1);
            } catch (java.io.IOException v1_0) {
                android.util.Log.e("Balboa", "IOException posting to idigi", v1_0);
            }
            return;
        } catch (java.io.IOException v1_2) {
            v1_2.printStackTrace();
            return;
        } catch (String v9_7) {
            throw v9_7;
        }
    }

    private void SendCommandToDigi(String p13, String p14, String p15)
    {
        try {
            org.apache.http.impl.client.DefaultHttpClient v2 = this.getDefaultHttpClient();
            org.apache.http.client.methods.HttpPost v3_1 = new org.apache.http.client.methods.HttpPost("http://my.idigi.com/ws/sci");
        } catch (java.io.IOException v1_2) {
            v1_2.printStackTrace();
            return;
        } catch (String v9_18) {
            throw v9_18;
        } catch (java.io.IOException v1_1) {
            android.util.Log.e("Balboa", "ClientProtocolException posting to idigi", v1_1);
            return;
        } catch (java.io.IOException v1_0) {
            android.util.Log.e("Balboa", "IOException posting to idigi", v1_0);
            return;
        }
        if ((!p13.equals("TempUnits")) && ((!p14.equals("Filters")) && (!p13.equals("Filters")))) {
            Object[] v10_1 = new Object[3];
            v10_1[0] = p15;
            v10_1[1] = p13;
            v10_1[2] = p14;
            String v5 = String.format("<sci_request version=\"1.0\"><data_service><targets><device id=\"%s\"/></targets><requests><device_request target_name=\"%s\"> %s </device_request></requests></data_service></sci_request>", v10_1);
        } else {
            Object[] v10_3 = new Object[3];
            v10_3[0] = p15;
            v10_3[1] = p13;
            v10_3[2] = p14;
            v5 = String.format("<sci_request version=\"1.0\"><data_service><targets><device id=\"%s\"/></targets><requests><device_request target_name=\"%s\">%s</device_request></requests></data_service></sci_request>", v10_3);
        }
        android.util.Log.i("Balboa", v5);
        org.apache.http.entity.StringEntity v8_1 = new org.apache.http.entity.StringEntity(v5, "UTF-8");
        v8_1.setContentType("text/xml");
        v3_1.setEntity(v8_1);
        String v7 = org.apache.http.util.EntityUtils.toString(v2.execute(v3_1).getEntity());
        if ((p13.equals("Request")) && (p14.equals("Filters"))) {
            this.HandleFilterResponse(v7);
        }
        android.util.Log.i("Balboa", v7);
        return;
    }

    static synthetic java.util.Queue access$000(com.balboawatergroup.BalboaSpa.iDigiThread p1)
    {
        return p1.messageQueue;
    }

    private org.apache.http.impl.client.DefaultHttpClient getDefaultHttpClient()
    {
        org.apache.http.impl.client.BasicCredentialsProvider v0_1 = new org.apache.http.impl.client.BasicCredentialsProvider();
        v0_1.setCredentials(new org.apache.http.auth.AuthScope(org.apache.http.auth.AuthScope.ANY_HOST, -1), new org.apache.http.auth.UsernamePasswordCredentials("BalboaWaterAndroidApp", "SW2Bra7a!"));
        org.apache.http.impl.client.DefaultHttpClient v1_1 = new org.apache.http.impl.client.DefaultHttpClient();
        v1_1.setCredentialsProvider(v0_1);
        return v1_1;
    }

    private String someRandomString()
    {
        return java.util.UUID.randomUUID().toString();
    }

    public android.os.Handler getHandler()
    {
        return this.myThreadHandler;
    }

    public void run()
    {
        try {
            this.ProvisionDevice();
            com.balboawatergroup.BalboaSpa.iDigiThread.sleep(25);
            this.CurrentConfiguration = this.GetIDigiDeviceConfigurationFromFileService();
            com.balboawatergroup.BalboaSpa.iDigiThread.sleep(25);
            this.FetchDigiMessageFile();
            int v7 = 0;
            int v3 = 0;
        } catch (Exception v2_0) {
            android.util.Log.e("Balboa", new StringBuilder().append("iDigi thread loop exception - ").append(v2_0).toString());
            return;
        }
        while (!this.stopped) {
            try {
                if (!this.IsLockedOut) {
                    v3++;
                    v7++;
                    if (((System.currentTimeMillis() - this.mostRecentPanelUpdate) > 30000) && (this.ConnectionState == com.balboawatergroup.BalboaSpa.WifiSocketState.Connected)) {
                        this.ConnectionState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
                        android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(new android.content.Intent("digi-disconnected"));
                    }
                    if (v7 == 0) {
                        this.CurrentConfiguration = this.GetIDigiDeviceConfigurationFromFileService();
                    }
                    if (v7 == 30) {
                        v7 = 0;
                    }
                    if (v3 == 10) {
                        this.CurrentState = this.GetIDigiPanelUpdateFromFileService();
                        if (this.CurrentState.SuccessfulFetch) {
                            android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(new android.content.Intent("spa-state-updated"));
                            if (this.CurrentState.WifiState != com.balboawatergroup.BalboaSpa.SpaWifiState.Ok) {
                                android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(new android.content.Intent("returnToHome"));
                            }
                            if (this.ConnectionState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
                                this.ConnectionState = com.balboawatergroup.BalboaSpa.WifiSocketState.Connected;
                                android.support.v4.content.LocalBroadcastManager.getInstance(this.context).sendBroadcast(new android.content.Intent("digi-connected"));
                            }
                        }
                        v3 = 0;
                    }
                    if (this.messageQueue.size() > 0) {
                        com.balboawatergroup.BalboaSpa.DigiMessage v8_1 = ((com.balboawatergroup.BalboaSpa.DigiMessage) this.messageQueue.remove());
                        this.SendCommandToDigi(v8_1.target, v8_1.content, v8_1.deviceID);
                    }
                } else {
                    this.ConnectionState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
                }
                try {
                    com.balboawatergroup.BalboaSpa.iDigiThread.sleep(20);
                } catch (android.support.v4.content.LocalBroadcastManager v9) {
                }
            } catch (Exception v2_1) {
                android.util.Log.e("Balboa", "Thread error in idigi", v2_1);
            }
        }
        return;
    }
}
