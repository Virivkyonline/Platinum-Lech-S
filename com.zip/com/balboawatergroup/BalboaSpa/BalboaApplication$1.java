package com.balboawatergroup.BalboaSpa;
 class BalboaApplication$1 extends java.util.TimerTask {
    final synthetic com.balboawatergroup.BalboaSpa.BalboaApplication this$0;

    BalboaApplication$1(com.balboawatergroup.BalboaSpa.BalboaApplication p1)
    {
        this.this$0 = p1;
        return;
    }

    public void run()
    {
        android.util.Log.i("Balboa", "Entering background");
        this.this$0.wasInBackground = 1;
        com.balboawatergroup.BalboaSpa.SpaController.StopThread();
        return;
    }
}
