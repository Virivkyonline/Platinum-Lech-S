package com.balboawatergroup.BalboaSpa;
public class BaseFragmentActivity extends android.support.v4.app.FragmentActivity {
    private android.content.BroadcastReceiver dismissConnectingDialog;
    public Boolean isConnectDialogCurrentlyBeingShown;
    public android.app.ProgressDialog progress;

    public BaseFragmentActivity()
    {
        this.isConnectDialogCurrentlyBeingShown = Boolean.valueOf(0);
        this.dismissConnectingDialog = new com.balboawatergroup.BalboaSpa.BaseFragmentActivity$1(this);
        return;
    }

    private void showConnectingDialog()
    {
        if (!this.isConnectDialogCurrentlyBeingShown.booleanValue()) {
            this.progress = new android.app.ProgressDialog(this);
            this.progress.setTitle("Connecting");
            this.progress.setCancelable(0);
            this.progress.setMessage("Wait while connecting...");
            this.progress.show();
        }
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.dismissConnectingDialog, new android.content.IntentFilter("spa-state-updated"));
        return;
    }

    protected void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this).unregisterReceiver(this.dismissConnectingDialog);
        super.onDestroy();
        return;
    }

    public void onPause()
    {
        super.onPause();
        ((com.balboawatergroup.BalboaSpa.BalboaApplication) this.getApplication()).startActivityTransitionTimer();
        return;
    }

    public void onResume()
    {
        super.onResume();
        com.balboawatergroup.BalboaSpa.BalboaApplication v0_1 = ((com.balboawatergroup.BalboaSpa.BalboaApplication) this.getApplication());
        if (v0_1.wasInBackground) {
            this.showConnectingDialog();
            v0_1.RecoverFromBackground();
        }
        v0_1.stopActivityTransitionTimer();
        return;
    }
}
