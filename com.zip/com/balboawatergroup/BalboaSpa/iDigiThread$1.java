package com.balboawatergroup.BalboaSpa;
 class iDigiThread$1 extends android.os.Handler {
    final synthetic com.balboawatergroup.BalboaSpa.iDigiThread this$0;

    iDigiThread$1(com.balboawatergroup.BalboaSpa.iDigiThread p1)
    {
        this.this$0 = p1;
        return;
    }

    public void handleMessage(android.os.Message p7)
    {
        if (p7.what == 0) {
            String v3 = p7.getData().getString("target");
            String v0 = p7.getData().getString("content");
            String v1 = p7.getData().getString("deviceID");
            com.balboawatergroup.BalboaSpa.DigiMessage v2_1 = new com.balboawatergroup.BalboaSpa.DigiMessage();
            v2_1.target = v3;
            v2_1.content = v0;
            v2_1.deviceID = v1;
            com.balboawatergroup.BalboaSpa.iDigiThread.access$000(this.this$0).offer(v2_1);
        }
        return;
    }
}
