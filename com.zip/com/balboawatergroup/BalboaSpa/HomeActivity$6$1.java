package com.balboawatergroup.BalboaSpa;
 class HomeActivity$6$1 implements java.lang.Runnable {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity$6 this$1;

    HomeActivity$6$1(com.balboawatergroup.BalboaSpa.HomeActivity$6 p1)
    {
        this.this$1 = p1;
        return;
    }

    public void run()
    {
        com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.SystemInfo);
        return;
    }
}
