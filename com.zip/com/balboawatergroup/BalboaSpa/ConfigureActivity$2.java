package com.balboawatergroup.BalboaSpa;
 class ConfigureActivity$2 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConfigureActivity this$0;

    ConfigureActivity$2(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p1, int p2)
    {
        return;
    }
}
