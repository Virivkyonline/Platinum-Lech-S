package com.balboawatergroup.BalboaSpa;
 class HomeActivity$1 extends java.lang.Thread {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$1(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void run()
    {
        while(true) {
            com.balboawatergroup.BalboaSpa.HomeActivity.access$000(this.this$0).sendEmptyMessage(0);
            Thread.sleep(1000);
            android.util.Log.e("Balboa", "InterruptedException", InterruptedException v0);
        }
    }
}
