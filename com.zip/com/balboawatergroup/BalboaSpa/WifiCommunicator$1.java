package com.balboawatergroup.BalboaSpa;
synthetic class WifiCommunicator$1 {
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$PanelRequestType;

    static WifiCommunicator$1()
    {
        NoSuchFieldError v0_5 = new int[com.balboawatergroup.BalboaSpa.PanelRequestType.values().length];
        com.balboawatergroup.BalboaSpa.WifiCommunicator$1.$SwitchMap$com$balboawatergroup$BalboaSpa$PanelRequestType = v0_5;
        try {
            com.balboawatergroup.BalboaSpa.PanelRequestType.SystemInfo.ordinal()[int v1_7] = 1;
            try {
                com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles.ordinal()[int v1_1] = 2;
                try {
                    com.balboawatergroup.BalboaSpa.PanelRequestType.SetupParameters.ordinal()[int v1_3] = 3;
                    try {
                        com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration.ordinal()[int v1_5] = 4;
                    } catch (NoSuchFieldError v0) {
                    }
                    return;
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
