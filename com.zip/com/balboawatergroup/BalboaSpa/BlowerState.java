package com.balboawatergroup.BalboaSpa;
public final enum class BlowerState extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.BlowerState[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.BlowerState High;
    public static final enum com.balboawatergroup.BalboaSpa.BlowerState Low;
    public static final enum com.balboawatergroup.BalboaSpa.BlowerState Medium;
    public static final enum com.balboawatergroup.BalboaSpa.BlowerState Off;

    static BlowerState()
    {
        com.balboawatergroup.BalboaSpa.BlowerState.Off = new com.balboawatergroup.BalboaSpa.BlowerState("Off", 0);
        com.balboawatergroup.BalboaSpa.BlowerState.Low = new com.balboawatergroup.BalboaSpa.BlowerState("Low", 1);
        com.balboawatergroup.BalboaSpa.BlowerState.Medium = new com.balboawatergroup.BalboaSpa.BlowerState("Medium", 2);
        com.balboawatergroup.BalboaSpa.BlowerState.High = new com.balboawatergroup.BalboaSpa.BlowerState("High", 3);
        com.balboawatergroup.BalboaSpa.BlowerState[] v0_6 = new com.balboawatergroup.BalboaSpa.BlowerState[4];
        v0_6[0] = com.balboawatergroup.BalboaSpa.BlowerState.Off;
        v0_6[1] = com.balboawatergroup.BalboaSpa.BlowerState.Low;
        v0_6[2] = com.balboawatergroup.BalboaSpa.BlowerState.Medium;
        v0_6[3] = com.balboawatergroup.BalboaSpa.BlowerState.High;
        com.balboawatergroup.BalboaSpa.BlowerState.$VALUES = v0_6;
        return;
    }

    private BlowerState(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.BlowerState valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.BlowerState) Enum.valueOf(com.balboawatergroup.BalboaSpa.BlowerState, p1));
    }

    public static com.balboawatergroup.BalboaSpa.BlowerState[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.BlowerState[]) com.balboawatergroup.BalboaSpa.BlowerState.$VALUES.clone());
    }

    public com.balboawatergroup.BalboaSpa.BlowerState successor()
    {
        return com.balboawatergroup.BalboaSpa.BlowerState.values()[((this.ordinal() + 1) % com.balboawatergroup.BalboaSpa.BlowerState.values().length)];
    }
}
