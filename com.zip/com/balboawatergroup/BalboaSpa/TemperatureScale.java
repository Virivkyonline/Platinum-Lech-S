package com.balboawatergroup.BalboaSpa;
public final enum class TemperatureScale extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.TemperatureScale[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.TemperatureScale Celsius;
    public static final enum com.balboawatergroup.BalboaSpa.TemperatureScale Farenheit;

    static TemperatureScale()
    {
        com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit = new com.balboawatergroup.BalboaSpa.TemperatureScale("Farenheit", 0);
        com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius = new com.balboawatergroup.BalboaSpa.TemperatureScale("Celsius", 1);
        com.balboawatergroup.BalboaSpa.TemperatureScale[] v0_1 = new com.balboawatergroup.BalboaSpa.TemperatureScale[2];
        v0_1[0] = com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit;
        v0_1[1] = com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius;
        com.balboawatergroup.BalboaSpa.TemperatureScale.$VALUES = v0_1;
        return;
    }

    private TemperatureScale(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.TemperatureScale valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.TemperatureScale) Enum.valueOf(com.balboawatergroup.BalboaSpa.TemperatureScale, p1));
    }

    public static com.balboawatergroup.BalboaSpa.TemperatureScale[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.TemperatureScale[]) com.balboawatergroup.BalboaSpa.TemperatureScale.$VALUES.clone());
    }
}
