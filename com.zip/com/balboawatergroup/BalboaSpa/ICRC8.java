package com.balboawatergroup.BalboaSpa;
public interface ICRC8 {

    public abstract int calc();

    public abstract int calc();

    public abstract int calc();

    public abstract int calc();

    public abstract int calc();

    public abstract int calc();

    public abstract int calc();
}
