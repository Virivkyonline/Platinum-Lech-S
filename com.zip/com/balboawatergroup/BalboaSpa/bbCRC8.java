package com.balboawatergroup.BalboaSpa;
public class bbCRC8 {
    static char crc8;

    public bbCRC8()
    {
        return;
    }

    static byte HdlcCrc8(byte[] p2, int p3)
    {
        com.balboawatergroup.BalboaSpa.bbCRC8.HdlcCrc8Initialize();
        int v0 = 0;
        while (v0 < p3) {
            com.balboawatergroup.BalboaSpa.bbCRC8.HdlcCrc8AddByte(p2[v0]);
            v0++;
        }
        return ((byte) com.balboawatergroup.BalboaSpa.bbCRC8.crc8);
    }

    static void HdlcCrc8AddByte(byte p1)
    {
        byte v1_1 = ((byte) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ p1));
        com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = 0;
        if ((v1_1 & 128) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 128));
            v1_1 = ((byte) (v1_1 ^ 131));
        }
        if ((v1_1 & 64) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 192));
            v1_1 = ((byte) (v1_1 ^ 65));
        }
        if ((v1_1 & 32) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 224));
            v1_1 = ((byte) (v1_1 ^ 32));
        }
        if ((v1_1 & 16) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 112));
            v1_1 = ((byte) (v1_1 ^ 16));
        }
        if ((v1_1 & 8) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 56));
            v1_1 = ((byte) (v1_1 ^ 8));
        }
        if ((v1_1 & 4) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 28));
            v1_1 = ((byte) (v1_1 ^ 4));
        }
        if ((v1_1 & 2) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 14));
            v1_1 = ((byte) (v1_1 ^ 2));
        }
        if ((v1_1 & 1) != 0) {
            com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = ((char) (com.balboawatergroup.BalboaSpa.bbCRC8.crc8 ^ 7));
        }
        return;
    }

    static byte HdlcCrc8Get()
    {
        return ((byte) com.balboawatergroup.BalboaSpa.bbCRC8.crc8);
    }

    static void HdlcCrc8Initialize()
    {
        com.balboawatergroup.BalboaSpa.bbCRC8.crc8 = 255;
        return;
    }
}
