package com.balboawatergroup.BalboaSpa;
public class DigiMessageDialogFragment extends android.support.v4.app.DialogFragment {

    public DigiMessageDialogFragment()
    {
        return;
    }

    public android.app.Dialog onCreateDialog(android.os.Bundle p8)
    {
        String v2 = this.getArguments().getString("text");
        String v3 = this.getArguments().getString("url");
        this.getArguments().getString("lockout");
        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(this.getActivity());
        v0_1.setMessage(v2).setPositiveButton(2131099667, new com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment$2(this)).setNegativeButton(2131099668, new com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment$1(this, v3));
        return v0_1.create();
    }
}
