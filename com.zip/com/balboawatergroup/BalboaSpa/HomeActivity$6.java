package com.balboawatergroup.BalboaSpa;
 class HomeActivity$6 extends java.util.TimerTask {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;
    final synthetic android.os.Handler val$handlerSysInfo;

    HomeActivity$6(com.balboawatergroup.BalboaSpa.HomeActivity p1, android.os.Handler p2)
    {
        this.this$0 = p1;
        this.val$handlerSysInfo = p2;
        return;
    }

    public void run()
    {
        this.val$handlerSysInfo.post(new com.balboawatergroup.BalboaSpa.HomeActivity$6$1(this));
        return;
    }
}
