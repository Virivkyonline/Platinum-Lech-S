package com.balboawatergroup.BalboaSpa;
public class ConnectDialogFragment extends android.support.v4.app.DialogFragment {
    private android.content.BroadcastReceiver mMessageReceiver;
    public android.app.ProgressDialog progress;

    public ConnectDialogFragment()
    {
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3(this);
        return;
    }

    public void goAway()
    {
        new java.util.Timer().schedule(new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$4(this, new android.os.Handler()), 5000);
        return;
    }

    public android.app.Dialog onCreateDialog(android.os.Bundle p6)
    {
        this.setCancelable(0);
        android.support.v4.content.LocalBroadcastManager.getInstance(this.getActivity()).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter("spa-state-updated"));
        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(this.getActivity());
        v0_1.setMessage(2131099663).setPositiveButton(2131099664, new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$2(this)).setNegativeButton(2131099665, new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$1(this));
        return v0_1.create();
    }

    public void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this.getActivity()).unregisterReceiver(this.mMessageReceiver);
        super.onDestroy();
        return;
    }
}
