package com.balboawatergroup.BalboaSpa;
public final class R$color {
    public static final int HomePageButtonColor = 2130968576;

    public R$color()
    {
        return;
    }
}
