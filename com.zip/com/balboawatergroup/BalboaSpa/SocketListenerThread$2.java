package com.balboawatergroup.BalboaSpa;
 class SocketListenerThread$2 implements javax.jmdns.ServiceListener {
    final synthetic com.balboawatergroup.BalboaSpa.SocketListenerThread this$0;

    SocketListenerThread$2(com.balboawatergroup.BalboaSpa.SocketListenerThread p1)
    {
        this.this$0 = p1;
        return;
    }

    public void serviceAdded(javax.jmdns.ServiceEvent p6)
    {
        com.balboawatergroup.BalboaSpa.SocketListenerThread.access$600(this.this$0).requestServiceInfo(p6.getType(), p6.getName(), 1);
        return;
    }

    public void serviceRemoved(javax.jmdns.ServiceEvent p1)
    {
        return;
    }

    public void serviceResolved(javax.jmdns.ServiceEvent p8)
    {
        if ((p8.getInfo().getInetAddresses() != null) && (p8.getInfo().getInetAddresses().length > 0)) {
            String v0 = p8.getInfo().getInetAddresses()[0].getHostAddress();
            Object[] v3 = new Object[1];
            v3[0] = p8.getName();
            android.util.Log.i("Balboa", String.format("Discovered bonjour service %s", v3));
            if (p8.getName().equals(com.balboawatergroup.BalboaSpa.SocketListenerThread.access$300(this.this$0))) {
                com.balboawatergroup.BalboaSpa.SocketListenerThread.access$402(this.this$0, v0);
                com.balboawatergroup.BalboaSpa.SocketListenerThread.access$502(this.this$0, 1);
                if (this.this$0.lock != null) {
                    this.this$0.lock.release();
                }
            }
        }
        return;
    }
}
