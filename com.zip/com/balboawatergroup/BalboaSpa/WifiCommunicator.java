package com.balboawatergroup.BalboaSpa;
public class WifiCommunicator implements com.balboawatergroup.BalboaSpa.ISpaCommunicator {

    public WifiCommunicator(android.content.Context p1)
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.start(p1);
        return;
    }

    private com.balboawatergroup.BalboaSpa.SpaControlState GetIntialDemoState()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v0_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        v0_1.Aux1On = 1;
        v0_1.Aux2On = 0;
        v0_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Off;
        v0_1.Light1On = 1;
        v0_1.Light2On = 0;
        v0_1.MisterOn = 0;
        v0_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v0_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v0_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.High;
        v0_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v0_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v0_1.Is24HourTime = 0;
        v0_1.CurrentTimeHour = 10;
        return v0_1;
    }

    private void SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode p10)
    {
        byte[] v0 = new byte[9];
        v0[0] = 126;
        v0[1] = 7;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 17;
        v0[5] = ((byte) p10.code);
        v0[6] = 0;
        v0[7] = 0;
        v0[8] = 126;
        android.util.Log.d("WifiCommunicator", "Sending Button");
        v0[7] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 6, 1);
        this.SendCommand(v0);
        return;
    }

    private void SendCommand(byte[] p1)
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.SendNetworkPacket(p1);
        return;
    }

    public void Aux1ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux1);
        return;
    }

    public void Aux2ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux2);
        return;
    }

    public void BlowerControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Blower);
        return;
    }

    public void ConnectToWifi(com.balboawatergroup.BalboaSpa.ConnectionMethod p12, com.balboawatergroup.BalboaSpa.SecurityType p13, String p14, String p15)
    {
        byte[] v4 = p14.getBytes();
        byte[] v3 = p15.getBytes();
        byte[] v0 = new byte[107];
        v0[0] = 126;
        v0[1] = 105;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = -110;
        v0[5] = ((byte) p12.id);
        v0[6] = ((byte) v4.length);
        int v2_0 = 0;
        while (v2_0 < 32) {
            if (v2_0 >= v4.length) {
                v0[(v2_0 + 7)] = 0;
            } else {
                v0[(v2_0 + 7)] = v4[v2_0];
            }
            v2_0++;
        }
        v0[39] = ((byte) p13.id);
        v0[40] = ((byte) v3.length);
        int v2_1 = 0;
        while (v2_1 < 64) {
            if (v2_1 >= v3.length) {
                v0[(v2_1 + 41)] = 0;
            } else {
                v0[(v2_1 + 41)] = v3[v2_1];
            }
            v2_1++;
        }
        v0[105] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 104, 1);
        v0[106] = 126;
        android.util.Log.i("Balboa", "Sending message to connect to wifi");
        this.SendCommand(v0);
        return;
    }

    public com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetCurrentConfiguration()
    {
        return com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentConfiguration;
    }

    public com.balboawatergroup.BalboaSpa.SpaControlState GetCurrentState()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v0_1;
        if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentState == null) {
            v0_1 = this.GetIntialDemoState();
        } else {
            v0_1 = com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentState;
        }
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.SpaSystemInformation GetCurrentSystemInformation()
    {
        return com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentSystemInformation;
    }

    public com.balboawatergroup.BalboaSpa.FilterCycle GetFilterCycle()
    {
        int v0_1;
        if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentFilterCycle == null) {
            v0_1 = 0;
        } else {
            v0_1 = com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentFilterCycle;
        }
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState()
    {
        return com.balboawatergroup.BalboaSpa.ThreadedSocketController.GetWifiSocketState();
    }

    public boolean HasCurrentDeviceConfig()
    {
        return 1;
    }

    public void HeatModePushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.HeatMode);
        return;
    }

    public void Light1ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Light1);
        return;
    }

    public void Light2ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Light2);
        return;
    }

    public void MisterControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Mister);
        return;
    }

    public void Pump1ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump1);
        return;
    }

    public void Pump2ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump2);
        return;
    }

    public void Pump3ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump3);
        return;
    }

    public void Pump4ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump4);
        return;
    }

    public void Pump5ControlPushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump5);
        return;
    }

    public void SaveFilterCycle(com.balboawatergroup.BalboaSpa.FilterCycle p2)
    {
        this.SendCommand(com.balboawatergroup.BalboaSpa.Utility.GetBytesForFilterCycle(p2));
        return;
    }

    public void SendDevicePresentQuery()
    {
        byte[] v0 = new byte[7];
        v0 = {126, 5, 10, -65, 4, 0, 126};
        android.util.Log.i("WifiCommunicator", "Sending DevicePresentQuery");
        v0[5] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 4, 1);
        this.SendCommand(v0);
        return;
    }

    public void SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType p12)
    {
        int v1 = 0;
        int v2 = 0;
        switch (com.balboawatergroup.BalboaSpa.WifiCommunicator$1.$SwitchMap$com$balboawatergroup$BalboaSpa$PanelRequestType[p12.ordinal()]) {
            case 1:
                v1 = 2;
                break;
            case 2:
                v1 = 1;
                break;
            case 3:
                v1 = 4;
                break;
            case 4:
                android.util.Log.i("Balboa", "Requesting device config");
                v2 = 1;
                break;
        }
        byte[] v0 = new byte[10];
        v0[0] = 126;
        v0[1] = 8;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 34;
        v0[5] = v1;
        v0[6] = 0;
        v0[7] = v2;
        v0[8] = 0;
        v0[9] = 126;
        v0[8] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 7, 1);
        this.SendCommand(v0);
        return;
    }

    public void Set24HourTime(boolean p3)
    {
        this.SetTime(this.GetCurrentState().CurrentTimeHour, this.GetCurrentState().CurrentTimeMinute, p3);
        return;
    }

    public void SetTargetTemperature(float p10)
    {
        if (this.GetCurrentState().TemperatureScale == com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius) {
            p10 *= 1073741824;
        }
        byte[] v0 = new byte[8];
        v0[0] = 126;
        v0[1] = 6;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 32;
        v0[5] = ((byte) ((int) p10));
        v0[6] = 0;
        v0[7] = 126;
        v0[6] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 5, 1);
        this.SendCommand(v0);
        return;
    }

    public void SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale p11)
    {
        int v2;
        if (p11 != com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius) {
            v2 = 0;
        } else {
            v2 = 1;
        }
        byte[] v0 = new byte[9];
        v0[0] = 126;
        v0[1] = 7;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 39;
        v0[5] = 1;
        v0[6] = v2;
        v0[7] = 0;
        v0[8] = 126;
        v0[7] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 6, 1);
        this.SendCommand(v0);
        return;
    }

    public void SetTime(int p12, int p13, boolean p14)
    {
        int v2;
        if (!p14) {
            v2 = 0;
        } else {
            v2 = 128;
        }
        int v3 = (v2 | p12);
        byte[] v0 = new byte[9];
        v0[0] = 126;
        v0[1] = 7;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 33;
        v0[5] = ((byte) v3);
        v0[6] = ((byte) p13);
        v0[7] = 0;
        v0[8] = 126;
        v0[7] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 6, 1);
        this.SendCommand(v0);
        return;
    }

    public void StartThread(android.content.Context p1)
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.start(p1);
        return;
    }

    public void StopThread()
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.StopThread();
        return;
    }

    public void TempRangePushed()
    {
        this.SendButtonCode(com.balboawatergroup.BalboaSpa.SpaButtonCode.TempRange);
        return;
    }
}
