package com.balboawatergroup.BalboaSpa;
public class ThreadedSocketController {
    private static android.content.Context context;
    public static com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration currentConfiguration;
    public static com.balboawatergroup.BalboaSpa.FilterCycle currentFilterCycle;
    public static com.balboawatergroup.BalboaSpa.SpaModuleIdentification currentModuleIdentification;
    public static com.balboawatergroup.BalboaSpa.SpaControlState currentState;
    public static com.balboawatergroup.BalboaSpa.SpaSystemInformation currentSystemInformation;
    private static boolean isInitialized;
    public static android.os.Handler mainHandler;
    private static com.balboawatergroup.BalboaSpa.SocketListenerThread myThread;

    static ThreadedSocketController()
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.isInitialized = 0;
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.mainHandler = new com.balboawatergroup.BalboaSpa.ThreadedSocketController$1();
        return;
    }

    public ThreadedSocketController()
    {
        return;
    }

    public static com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState()
    {
        com.balboawatergroup.BalboaSpa.WifiSocketState v0_1;
        if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread == null) {
            v0_1 = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
        } else {
            v0_1 = com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.currentState;
        }
        return v0_1;
    }

    public static void SendNetworkPacket(byte[] p4)
    {
        if ((com.balboawatergroup.BalboaSpa.ThreadedSocketController.isInitialized) && (com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread != null)) {
            android.os.Message v1_1 = new android.os.Message();
            android.os.Bundle v0_1 = new android.os.Bundle();
            v1_1.what = 0;
            v0_1.putByteArray("outgoingData", p4);
            v0_1.putInt("outgoingDataLength", p4.length);
            v1_1.setData(v0_1);
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.getHandler().sendMessage(v1_1);
        }
        return;
    }

    public static void StopThread()
    {
        if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread != null) {
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.stopped = 1;
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.currentState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.interrupt();
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread = 0;
        }
        return;
    }

    static synthetic android.content.Context access$000()
    {
        return com.balboawatergroup.BalboaSpa.ThreadedSocketController.context;
    }

    public static void start(android.content.Context p3)
    {
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.context = p3;
        if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread == null) {
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread = new com.balboawatergroup.BalboaSpa.SocketListenerThread(com.balboawatergroup.BalboaSpa.ThreadedSocketController.mainHandler, com.balboawatergroup.BalboaSpa.ThreadedSocketController.context);
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.stopped = 0;
            com.balboawatergroup.BalboaSpa.ThreadedSocketController.myThread.start();
        }
        com.balboawatergroup.BalboaSpa.ThreadedSocketController.isInitialized = 1;
        return;
    }
}
