package com.balboawatergroup.BalboaSpa;
public class BalboaApplication extends android.app.Application {
    private final long MAX_ACTIVITY_TRANSITION_TIME_MS;
    private java.util.Timer mActivityTransitionTimer;
    private java.util.TimerTask mActivityTransitionTimerTask;
    public boolean wasInBackground;

    public BalboaApplication()
    {
        this.MAX_ACTIVITY_TRANSITION_TIME_MS = 2000;
        return;
    }

    public void RecoverFromBackground()
    {
        android.util.Log.i("Balboa", "RecoverFromBackground");
        com.balboawatergroup.BalboaSpa.SpaController.StartThread();
        return;
    }

    public void startActivityTransitionTimer()
    {
        this.mActivityTransitionTimer = new java.util.Timer();
        this.mActivityTransitionTimerTask = new com.balboawatergroup.BalboaSpa.BalboaApplication$1(this);
        this.mActivityTransitionTimer.schedule(this.mActivityTransitionTimerTask, 2000);
        return;
    }

    public void stopActivityTransitionTimer()
    {
        if (this.mActivityTransitionTimerTask != null) {
            this.mActivityTransitionTimerTask.cancel();
        }
        if (this.mActivityTransitionTimer != null) {
            this.mActivityTransitionTimer.cancel();
        }
        this.wasInBackground = 0;
        return;
    }
}
