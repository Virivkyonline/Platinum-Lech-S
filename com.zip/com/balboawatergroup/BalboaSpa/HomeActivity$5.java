package com.balboawatergroup.BalboaSpa;
 class HomeActivity$5 extends java.util.TimerTask {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;
    final synthetic android.os.Handler val$handler;

    HomeActivity$5(com.balboawatergroup.BalboaSpa.HomeActivity p1, android.os.Handler p2)
    {
        this.this$0 = p1;
        this.val$handler = p2;
        return;
    }

    public void run()
    {
        this.val$handler.post(new com.balboawatergroup.BalboaSpa.HomeActivity$5$1(this));
        return;
    }
}
