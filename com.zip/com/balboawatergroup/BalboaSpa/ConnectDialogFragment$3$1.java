package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$3$1 extends java.util.TimerTask {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3 this$1;
    final synthetic android.os.Handler val$handler;

    ConnectDialogFragment$3$1(com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3 p1, android.os.Handler p2)
    {
        this.this$1 = p1;
        this.val$handler = p2;
        return;
    }

    public void run()
    {
        this.val$handler.post(new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3$1$1(this));
        return;
    }
}
