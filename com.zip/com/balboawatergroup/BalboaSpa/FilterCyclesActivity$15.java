package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$15 implements android.app.TimePickerDialog$OnTimeSetListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$15(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeSet(android.widget.TimePicker p3, int p4, int p5)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$602(this.this$0, p4);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$702(this.this$0, p5);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$100(this.this$0);
        this.this$0.removeDialog(995);
        return;
    }
}
