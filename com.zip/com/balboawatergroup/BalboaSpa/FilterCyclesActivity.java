package com.balboawatergroup.BalboaSpa;
public class FilterCyclesActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    static final int FILTER1_DURATION_TIME_DIALOG_ID = 994;
    static final int FILTER1_TIME_DIALOG_ID = 996;
    static final int FILTER2_DURATION_TIME_DIALOG_ID = 993;
    static final int FILTER2_TIME_DIALOG_ID = 995;
    private android.widget.Button btnCancel;
    private android.widget.Button btnFilterCycle1Duration;
    private android.widget.Button btnFilterCycle1StartsAt;
    private android.widget.Button btnFilterCycle2Duration;
    private android.widget.Button btnFilterCycle2StartsAt;
    private android.widget.Button btnSave;
    private int filter1DurationHour;
    private int filter1DurationMinute;
    private android.app.TimePickerDialog$OnTimeSetListener filter1DurationTimePickerListener;
    private int filter1StartsAtHour;
    private int filter1StartsAtMinute;
    private android.app.TimePickerDialog$OnTimeSetListener filter1TimePickerListener;
    private int filter2DurationHour;
    private int filter2DurationMinute;
    private android.app.TimePickerDialog$OnTimeSetListener filter2DurationTimePickerListener;
    private int filter2StartsAtHour;
    private int filter2StartsAtMinute;
    private android.app.TimePickerDialog$OnTimeSetListener filter2TimePickerListener;
    private android.widget.ImageView imgAccessibility;
    private android.content.BroadcastReceiver mMessageReceiver;
    private android.widget.TimePicker$OnTimeChangedListener mNullTimeChangedListener;
    private android.widget.TimePicker$OnTimeChangedListener mStartTimeChangedListener;
    private android.widget.ToggleButton tbFilter2Enabled;
    private android.widget.TextView tvFilter1Duration;
    private android.widget.TextView tvFilter1EndsAt;
    private android.widget.TextView tvFilter1StartsAt;
    private android.widget.TextView tvFilter2Duration;
    private android.widget.TextView tvFilter2EndsAt;
    private android.widget.TextView tvFilter2StartsAt;

    public FilterCyclesActivity()
    {
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$1(this);
        this.mStartTimeChangedListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$12(this);
        this.mNullTimeChangedListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$13(this);
        this.filter1TimePickerListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$14(this);
        this.filter2TimePickerListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$15(this);
        this.filter1DurationTimePickerListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$16(this);
        this.filter2DurationTimePickerListener = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$17(this);
        return;
    }

    private java.util.Calendar AddTime(int p9, int p10, int p11, int p12)
    {
        Object[] v5_1 = new Object[2];
        v5_1[0] = Integer.valueOf(p9);
        v5_1[1] = Integer.valueOf(p10);
        java.util.Date v2 = new java.text.SimpleDateFormat("HH:mm").parse(String.format("%02d:%02d", v5_1));
        java.util.GregorianCalendar v0_1 = new java.util.GregorianCalendar();
        v0_1.setTime(v2);
        v0_1.add(12, p12);
        v0_1.add(10, p11);
        return v0_1;
    }

    private void ApplyLocks()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v0 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL) {
            if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT) {
                if (v0.AccessibilityType == com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE) {
                    this.imgAccessibility.setImageResource(2130837562);
                    this.imgAccessibility.setVisibility(0);
                    this.btnFilterCycle1StartsAt.setEnabled(0);
                    this.btnFilterCycle2StartsAt.setEnabled(0);
                    this.btnFilterCycle1Duration.setEnabled(0);
                    this.btnFilterCycle2Duration.setEnabled(0);
                    this.btnSave.setEnabled(0);
                    this.tbFilter2Enabled.setEnabled(0);
                }
            } else {
                this.imgAccessibility.setImageResource(2130837563);
                this.imgAccessibility.setVisibility(0);
                this.btnFilterCycle1StartsAt.setEnabled(0);
                this.btnFilterCycle2StartsAt.setEnabled(0);
                this.btnFilterCycle1Duration.setEnabled(0);
                this.btnFilterCycle2Duration.setEnabled(0);
                this.btnSave.setEnabled(0);
                this.tbFilter2Enabled.setEnabled(0);
            }
        } else {
            this.imgAccessibility.setVisibility(4);
            this.btnFilterCycle1StartsAt.setEnabled(1);
            this.btnFilterCycle2StartsAt.setEnabled(1);
            this.btnFilterCycle1Duration.setEnabled(1);
            this.btnFilterCycle2Duration.setEnabled(1);
            this.btnSave.setEnabled(1);
            this.tbFilter2Enabled.setEnabled(1);
        }
        return;
    }

    private void RefreshControls()
    {
        com.balboawatergroup.BalboaSpa.FilterCycle v0 = com.balboawatergroup.BalboaSpa.SpaController.GetFilterCycle();
        if (v0 != null) {
            this.filter1StartsAtHour = v0.FilterCycle1StartsAtHour;
            this.filter1StartsAtMinute = v0.FilterCycle1StartsAtMinute;
            this.filter2StartsAtHour = v0.FilterCycle2StartsAtHour;
            this.filter2StartsAtMinute = v0.FilterCycle2StartsAtMinute;
            this.filter1DurationHour = v0.FilterCycle1DurationHour;
            this.filter1DurationMinute = v0.FilterCycle1DurationMinute;
            this.filter2DurationHour = v0.FilterCycle2DurationHour;
            this.filter2DurationMinute = v0.FilterCycle2DurationMinute;
            this.tbFilter2Enabled.setChecked(v0.FilterCycle2Enabled);
        }
        this.ApplyLocks();
        return;
    }

    private void SaveFilterCycle()
    {
        com.balboawatergroup.BalboaSpa.FilterCycle v0_1 = new com.balboawatergroup.BalboaSpa.FilterCycle();
        v0_1.FilterCycle1StartsAtHour = this.filter1StartsAtHour;
        v0_1.FilterCycle1StartsAtMinute = this.filter1StartsAtMinute;
        v0_1.FilterCycle2StartsAtHour = this.filter2StartsAtHour;
        v0_1.FilterCycle2StartsAtMinute = this.filter2StartsAtMinute;
        v0_1.FilterCycle1DurationHour = this.filter1DurationHour;
        v0_1.FilterCycle1DurationMinute = this.filter1DurationMinute;
        v0_1.FilterCycle2DurationHour = this.filter2DurationHour;
        v0_1.FilterCycle2DurationMinute = this.filter2DurationMinute;
        v0_1.FilterCycle2Enabled = this.tbFilter2Enabled.isChecked();
        com.balboawatergroup.BalboaSpa.SpaController.SaveFilterCycle(v0_1);
        if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode != "Wifi") {
            com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles);
        }
        this.finish();
        return;
    }

    private void UpdateFilterTimes()
    {
        if (!com.balboawatergroup.BalboaSpa.SpaController.Get24HourTime()) {
            int v4 = this.filter1StartsAtHour;
            String v5 = "AM";
            int v8 = this.filter2StartsAtHour;
            String v9 = "AM";
            if (v4 > 12) {
                v5 = "PM";
                v4 -= 12;
            }
            if (v4 == 0) {
                v4 = 12;
            }
            if (v8 > 12) {
                v9 = "PM";
                v8 -= 12;
            }
            if (v8 == 0) {
                v8 = 12;
            }
            android.widget.TextView v10_9 = this.tvFilter1StartsAt;
            Object[] v12_14 = new Object[3];
            v12_14[0] = Integer.valueOf(v4);
            v12_14[1] = Integer.valueOf(this.filter1StartsAtMinute);
            v12_14[2] = v5;
            v10_9.setText(String.format("%02d:%02d %s", v12_14));
            android.widget.TextView v10_16 = this.tvFilter2StartsAt;
            Object[] v12_22 = new Object[3];
            v12_22[0] = Integer.valueOf(v8);
            v12_22[1] = Integer.valueOf(this.filter2StartsAtMinute);
            v12_22[2] = v9;
            v10_16.setText(String.format("%02d:%02d %s", v12_22));
            android.widget.TextView v10_17 = this.tvFilter1Duration;
            Object[] v12_24 = new Object[2];
            v12_24[0] = Integer.valueOf(this.filter1DurationHour);
            v12_24[1] = Integer.valueOf(this.filter1DurationMinute);
            v10_17.setText(String.format("%d Hr and %d Min", v12_24));
            android.widget.TextView v10_19 = this.tvFilter2Duration;
            Object[] v12_26 = new Object[2];
            v12_26[0] = Integer.valueOf(this.filter2DurationHour);
            v12_26[1] = Integer.valueOf(this.filter2DurationMinute);
            v10_19.setText(String.format("%d Hr and %d Min", v12_26));
            try {
                java.util.Calendar v0_3 = this.AddTime(this.filter1StartsAtHour, this.filter1StartsAtMinute, this.filter1DurationHour, this.filter1DurationMinute);
                int v2 = v0_3.get(11);
                String v3 = "AM";
            } catch (java.text.ParseException v1_0) {
                v1_0.printStackTrace();
            }
            if (v2 > 12) {
                v3 = "PM";
                v2 -= 12;
            }
            if (v2 == 0) {
                v2 = 12;
            }
            android.widget.TextView v10_1 = this.tvFilter1EndsAt;
            Object[] v12_1 = new Object[3];
            v12_1[0] = Integer.valueOf(v2);
            v12_1[1] = Integer.valueOf(v0_3.get(12));
            v12_1[2] = v3;
            v10_1.setText(String.format("Ends at %02d:%02d %s", v12_1));
            java.util.Calendar v0_0 = this.AddTime(this.filter2StartsAtHour, this.filter2StartsAtMinute, this.filter2DurationHour, this.filter2DurationMinute);
            int v6 = v0_0.get(11);
            String v7 = "AM";
            if (v6 > 12) {
                v7 = "PM";
                v6 -= 12;
            }
            if (v6 == 0) {
                v6 = 12;
            }
            android.widget.TextView v10_6 = this.tvFilter2EndsAt;
            Object[] v12_4 = new Object[3];
            v12_4[0] = Integer.valueOf(v6);
            v12_4[1] = Integer.valueOf(v0_0.get(12));
            v12_4[2] = v7;
            v10_6.setText(String.format("Ends at %02d:%02d %s", v12_4));
        } else {
            android.widget.TextView v10_7 = this.tvFilter1StartsAt;
            Object[] v12_6 = new Object[2];
            v12_6[0] = Integer.valueOf(this.filter1StartsAtHour);
            v12_6[1] = Integer.valueOf(this.filter1StartsAtMinute);
            v10_7.setText(String.format("%02d:%02d", v12_6));
            android.widget.TextView v10_8 = this.tvFilter2StartsAt;
            Object[] v12_8 = new Object[2];
            v12_8[0] = Integer.valueOf(this.filter2StartsAtHour);
            v12_8[1] = Integer.valueOf(this.filter2StartsAtMinute);
            v10_8.setText(String.format("%02d:%02d", v12_8));
            android.widget.TextView v10_10 = this.tvFilter1Duration;
            Object[] v12_10 = new Object[2];
            v12_10[0] = Integer.valueOf(this.filter1DurationHour);
            v12_10[1] = Integer.valueOf(this.filter1DurationMinute);
            v10_10.setText(String.format("%d Hr and %d Min", v12_10));
            android.widget.TextView v10_11 = this.tvFilter2Duration;
            Object[] v12_13 = new Object[2];
            v12_13[0] = Integer.valueOf(this.filter2DurationHour);
            v12_13[1] = Integer.valueOf(this.filter2DurationMinute);
            v10_11.setText(String.format("%d Hr and %d Min", v12_13));
            try {
                java.util.Calendar v0_1 = this.AddTime(this.filter1StartsAtHour, this.filter1StartsAtMinute, this.filter1DurationHour, this.filter1DurationMinute);
                android.widget.TextView v10_13 = this.tvFilter1EndsAt;
                Object[] v12_17 = new Object[2];
                v12_17[0] = Integer.valueOf(v0_1.get(11));
                v12_17[1] = Integer.valueOf(v0_1.get(12));
                v10_13.setText(String.format("Ends at %02d:%02d", v12_17));
                java.util.Calendar v0_2 = this.AddTime(this.filter2StartsAtHour, this.filter2StartsAtMinute, this.filter2DurationHour, this.filter2DurationMinute);
                android.widget.TextView v10_15 = this.tvFilter2EndsAt;
                Object[] v12_20 = new Object[2];
                v12_20[0] = Integer.valueOf(v0_2.get(11));
                v12_20[1] = Integer.valueOf(v0_2.get(12));
                v10_15.setText(String.format("Ends at %02d:%02d", v12_20));
            } catch (java.text.ParseException v1_1) {
                v1_1.printStackTrace();
            }
        }
        return;
    }

    static synthetic void access$000(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0)
    {
        p0.RefreshControls();
        return;
    }

    static synthetic void access$100(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0)
    {
        p0.UpdateFilterTimes();
        return;
    }

    static synthetic int access$1002(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter2DurationHour = p1;
        return p1;
    }

    static synthetic int access$1102(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter2DurationMinute = p1;
        return p1;
    }

    static synthetic void access$200(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0)
    {
        p0.SaveFilterCycle();
        return;
    }

    static synthetic void access$300(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, android.widget.TimePicker p1, int p2, int p3)
    {
        p0.updateDisplay(p1, p2, p3);
        return;
    }

    static synthetic int access$402(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter1StartsAtHour = p1;
        return p1;
    }

    static synthetic int access$502(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter1StartsAtMinute = p1;
        return p1;
    }

    static synthetic int access$602(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter2StartsAtHour = p1;
        return p1;
    }

    static synthetic int access$702(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter2StartsAtMinute = p1;
        return p1;
    }

    static synthetic int access$802(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter1DurationHour = p1;
        return p1;
    }

    static synthetic int access$902(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p0, int p1)
    {
        p0.filter1DurationMinute = p1;
        return p1;
    }

    private void getControls()
    {
        this.btnFilterCycle1StartsAt = ((android.widget.Button) this.findViewById(2131230772));
        this.btnFilterCycle1Duration = ((android.widget.Button) this.findViewById(2131230774));
        this.btnFilterCycle2StartsAt = ((android.widget.Button) this.findViewById(2131230778));
        this.btnFilterCycle2Duration = ((android.widget.Button) this.findViewById(2131230779));
        this.btnSave = ((android.widget.Button) this.findViewById(2131230733));
        this.btnCancel = ((android.widget.Button) this.findViewById(2131230771));
        this.tvFilter1StartsAt = ((android.widget.TextView) this.findViewById(2131230773));
        this.tvFilter1Duration = ((android.widget.TextView) this.findViewById(2131230775));
        this.tvFilter2StartsAt = ((android.widget.TextView) this.findViewById(2131230780));
        this.tvFilter2Duration = ((android.widget.TextView) this.findViewById(2131230781));
        this.tvFilter1EndsAt = ((android.widget.TextView) this.findViewById(2131230776));
        this.tvFilter2EndsAt = ((android.widget.TextView) this.findViewById(2131230782));
        this.imgAccessibility = ((android.widget.ImageView) this.findViewById(2131230734));
        this.tbFilter2Enabled = ((android.widget.ToggleButton) this.findViewById(2131230783));
        return;
    }

    private void setButtonAlpha()
    {
        this.btnFilterCycle1StartsAt.getBackground().setAlpha(55);
        this.btnFilterCycle1Duration.getBackground().setAlpha(55);
        this.btnFilterCycle2StartsAt.getBackground().setAlpha(55);
        this.btnFilterCycle2Duration.getBackground().setAlpha(55);
        return;
    }

    private void updateDisplay(android.widget.TimePicker p8, int p9, int p10)
    {
        int v0;
        p8.setOnTimeChangedListener(this.mNullTimeChangedListener);
        if ((p10 < 45) || (p10 > 59)) {
            if (p10 < 30) {
                if (p10 < 15) {
                    if (p10 <= 0) {
                        v0 = 45;
                    } else {
                        v0 = 0;
                    }
                } else {
                    v0 = 15;
                }
            } else {
                v0 = 30;
            }
        } else {
            v0 = 45;
        }
        if ((p10 - v0) == 1) {
            if ((p10 < 45) || (p10 > 59)) {
                if (p10 < 30) {
                    if (p10 < 15) {
                        if (p10 <= 0) {
                            v0 = 15;
                        } else {
                            v0 = 15;
                        }
                    } else {
                        v0 = 30;
                    }
                } else {
                    v0 = 45;
                }
            } else {
                v0 = 0;
            }
        }
        p8.setCurrentMinute(Integer.valueOf(v0));
        p8.setOnTimeChangedListener(this.mStartTimeChangedListener);
        return;
    }

    public void addListenersOnButtons()
    {
        this.btnFilterCycle1StartsAt.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$2(this));
        this.btnFilterCycle2StartsAt.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$3(this));
        this.btnFilterCycle1Duration.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$4(this));
        this.btnFilterCycle2Duration.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$5(this));
        this.btnSave.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$6(this));
        this.btnCancel.setOnClickListener(new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$7(this));
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        this.setContentView(2130903043);
        this.getControls();
        this.setButtonAlpha();
        this.addListenersOnButtons();
        this.RefreshControls();
        this.UpdateFilterTimes();
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter(com.balboawatergroup.BalboaSpa.BroadcastMessage.FilterCyclesUpdated.name()));
        com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles);
        return;
    }

    protected android.app.Dialog onCreateDialog(int p11)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity$8 v0_1;
        switch (p11) {
            case 993:
                android.app.TimePickerDialog$OnTimeSetListener v3_4 = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$11(this, this, this.filter2DurationTimePickerListener, this.filter2DurationHour, this.filter2DurationMinute, 1);
                v3_4.setTitle("Duration");
                v0_1 = v3_4;
                break;
            case 994:
                com.balboawatergroup.BalboaSpa.FilterCyclesActivity v2_2 = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$10(this, this, this.filter1DurationTimePickerListener, this.filter1DurationHour, this.filter1DurationMinute, 1);
                v2_2.setTitle("Duration");
                v0_1 = v2_2;
                break;
            case 995:
                v0_1 = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$9(this, this, this.filter2TimePickerListener, this.filter2StartsAtHour, this.filter2StartsAtMinute, com.balboawatergroup.BalboaSpa.SpaController.Get24HourTime());
                break;
            case 996:
                v0_1 = new com.balboawatergroup.BalboaSpa.FilterCyclesActivity$8(this, this, this.filter1TimePickerListener, this.filter1StartsAtHour, this.filter1StartsAtMinute, com.balboawatergroup.BalboaSpa.SpaController.Get24HourTime());
                break;
            default:
                v0_1 = 0;
        }
        return v0_1;
    }
}
