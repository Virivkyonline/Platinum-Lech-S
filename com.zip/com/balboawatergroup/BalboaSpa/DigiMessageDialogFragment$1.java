package com.balboawatergroup.BalboaSpa;
 class DigiMessageDialogFragment$1 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment this$0;
    final synthetic String val$url;

    DigiMessageDialogFragment$1(com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment p1, String p2)
    {
        this.this$0 = p1;
        this.val$url = p2;
        return;
    }

    public void onClick(android.content.DialogInterface p4, int p5)
    {
        this.this$0.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(this.val$url)));
        return;
    }
}
