package com.balboawatergroup.BalboaSpa;
 class ConfigureActivity$4$1 implements android.widget.AdapterView$OnItemSelectedListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConfigureActivity$4 this$1;

    ConfigureActivity$4$1(com.balboawatergroup.BalboaSpa.ConfigureActivity$4 p1)
    {
        this.this$1 = p1;
        return;
    }

    public void onItemSelected(android.widget.AdapterView p4, android.view.View p5, int p6, long p7)
    {
        android.util.Log.i("Balboa", com.balboawatergroup.BalboaSpa.ConfigureActivity.access$100(this.this$1.this$0).getItem(p6).getName());
        return;
    }

    public void onNothingSelected(android.widget.AdapterView p1)
    {
        return;
    }
}
