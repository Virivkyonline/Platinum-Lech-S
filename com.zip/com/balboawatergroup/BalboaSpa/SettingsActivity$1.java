package com.balboawatergroup.BalboaSpa;
 class SettingsActivity$1 implements android.widget.SeekBar$OnSeekBarChangeListener {
    final synthetic com.balboawatergroup.BalboaSpa.SettingsActivity this$0;

    SettingsActivity$1(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onProgressChanged(android.widget.SeekBar p5, int p6, boolean p7)
    {
        if (!com.balboawatergroup.BalboaSpa.SettingsActivity.access$000(this.this$0).isChecked()) {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$102(this.this$0, (com.balboawatergroup.BalboaSpa.SettingsActivity.access$200(this.this$0) + ((float) p6)));
        } else {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$102(this.this$0, (com.balboawatergroup.BalboaSpa.SettingsActivity.access$200(this.this$0) + (((float) p6) / 1073741824)));
        }
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$300(this.this$0).setText(new StringBuilder().append("").append(com.balboawatergroup.BalboaSpa.SettingsActivity.access$100(this.this$0)).toString());
        return;
    }

    public void onStartTrackingTouch(android.widget.SeekBar p3)
    {
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$402(this.this$0, Boolean.valueOf(1));
        return;
    }

    public void onStopTrackingTouch(android.widget.SeekBar p3)
    {
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$502(this.this$0, 2);
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$402(this.this$0, Boolean.valueOf(0));
        com.balboawatergroup.BalboaSpa.SpaController.SetTargetTemperature(com.balboawatergroup.BalboaSpa.SettingsActivity.access$100(this.this$0));
        android.util.Log.i("Balboa", "sending temp");
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$602(this.this$0, Boolean.valueOf(1));
        return;
    }
}
