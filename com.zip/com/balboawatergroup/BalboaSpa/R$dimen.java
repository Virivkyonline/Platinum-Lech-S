package com.balboawatergroup.BalboaSpa;
public final class R$dimen {
    public static final int zero = 2131034112;

    public R$dimen()
    {
        return;
    }
}
