package com.balboawatergroup.BalboaSpa;
 class TimeOfDayActivity$4 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.TimeOfDayActivity this$0;

    TimeOfDayActivity$4(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        com.balboawatergroup.BalboaSpa.SpaController.set24HourTime(com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$200(this.this$0).isChecked());
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$302(this.this$0, com.balboawatergroup.BalboaSpa.SpaController.GetSpaTimeHour());
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$402(this.this$0, com.balboawatergroup.BalboaSpa.SpaController.GetSpaTimeMinute());
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$000(this.this$0);
        return;
    }
}
