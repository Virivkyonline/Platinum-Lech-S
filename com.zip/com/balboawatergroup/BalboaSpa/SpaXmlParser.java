package com.balboawatergroup.BalboaSpa;
public class SpaXmlParser {
    private static final String ns;

    static SpaXmlParser()
    {
        com.balboawatergroup.BalboaSpa.SpaXmlParser.ns = 0;
        return;
    }

    public SpaXmlParser()
    {
        return;
    }

    public static com.balboawatergroup.BalboaSpa.DigiUserMessage ParseDigiMessage(String p8)
    {
        com.balboawatergroup.BalboaSpa.DigiUserMessage v3_1 = new com.balboawatergroup.BalboaSpa.DigiUserMessage();
        try {
            javax.xml.xpath.XPath v4 = javax.xml.xpath.XPathFactory.newInstance().newXPath();
            v3_1.text = v4.evaluate("//text", new org.xml.sax.InputSource(new java.io.StringReader(p8)));
            v3_1.url = v4.evaluate("//url", new org.xml.sax.InputSource(new java.io.StringReader(p8)));
        } catch (Exception v0) {
            android.util.Log.e("Balboa", "Exception parsing DigiUserMessage xml", v0);
            return v3_1;
        }
        if (!v4.evaluate("//lockout", new org.xml.sax.InputSource(new java.io.StringReader(p8))).toLowerCase().equals("true")) {
            v3_1.lockout = Boolean.valueOf(0);
            return v3_1;
        } else {
            v3_1.lockout = Boolean.valueOf(1);
            return v3_1;
        }
    }

    public static String ParseFilterCycle(String p4)
    {
        try {
            org.xmlpull.v1.XmlPullParser v1 = android.util.Xml.newPullParser();
            v1.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", 0);
            v1.setInput(new java.io.StringReader(p4));
            v1.nextTag();
            String v2_0 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readFilterCycleElement(v1);
        } catch (Exception v0) {
            android.util.Log.e("Balboa", "Exception parsing filter cycle xml", v0);
            v2_0 = "";
        }
        return v2_0;
    }

    public static String ParsePanelUpdate(String p7)
    {
        try {
            String v0 = javax.xml.xpath.XPathFactory.newInstance().newXPath().evaluate("//data", new org.xml.sax.InputSource(new java.io.StringReader(p7)));
        } catch (Exception v1) {
            android.util.Log.e("Balboa", "Exception parsing panel update xml", v1);
            v0 = "";
        }
        return v0;
    }

    private static String readData_service(org.xmlpull.v1.XmlPullParser p5)
    {
        String v1 = "";
        p5.require(2, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "data_service");
        while (p5.next() != 3) {
            if (p5.getEventType() == 2) {
                if (!p5.getName().equals("device")) {
                    com.balboawatergroup.BalboaSpa.SpaXmlParser.skip(p5);
                } else {
                    v1 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readDevice(p5);
                }
            }
        }
        return v1;
    }

    private static String readDevice(org.xmlpull.v1.XmlPullParser p5)
    {
        String v1 = "";
        p5.require(2, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "device");
        while (p5.next() != 3) {
            if (p5.getEventType() == 2) {
                if (!p5.getName().equals("requests")) {
                    com.balboawatergroup.BalboaSpa.SpaXmlParser.skip(p5);
                } else {
                    v1 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readRequest(p5);
                }
            }
        }
        return v1;
    }

    private static String readDevice_request(org.xmlpull.v1.XmlPullParser p4)
    {
        p4.require(2, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "device_request");
        String v0 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readText(p4);
        p4.require(3, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "device_request");
        return v0;
    }

    private static String readFilterCycleElement(org.xmlpull.v1.XmlPullParser p5)
    {
        String v0 = "";
        p5.require(2, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "sci_reply");
        while (p5.next() != 3) {
            if (p5.getEventType() == 2) {
                if (!p5.getName().equals("data_service")) {
                    com.balboawatergroup.BalboaSpa.SpaXmlParser.skip(p5);
                } else {
                    v0 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readData_service(p5);
                }
            }
        }
        return v0;
    }

    private static String readRequest(org.xmlpull.v1.XmlPullParser p5)
    {
        String v1 = "";
        p5.require(2, com.balboawatergroup.BalboaSpa.SpaXmlParser.ns, "requests");
        while (p5.next() != 3) {
            if (p5.getEventType() == 2) {
                if (!p5.getName().equals("device_request")) {
                    com.balboawatergroup.BalboaSpa.SpaXmlParser.skip(p5);
                } else {
                    v1 = com.balboawatergroup.BalboaSpa.SpaXmlParser.readDevice_request(p5);
                }
            }
        }
        return v1;
    }

    private static String readText(org.xmlpull.v1.XmlPullParser p3)
    {
        String v0 = "";
        if (p3.next() == 4) {
            v0 = p3.getText();
            p3.nextTag();
        }
        return v0;
    }

    private static void skip(org.xmlpull.v1.XmlPullParser p3)
    {
        if (p3.getEventType() == 2) {
            int v0 = 1;
            while (v0 != 0) {
                switch (p3.next()) {
                    case 2:
                        v0++;
                        break;
                    case 3:
                        v0--;
                        break;
                    default:
                }
            }
            return;
        } else {
            throw new IllegalStateException();
        }
    }
}
