package com.balboawatergroup.BalboaSpa;
public class SpaControlState implements java.io.Serializable {
    private static final long serialVersionUID;
    public com.balboawatergroup.BalboaSpa.Accessibility AccessibilityType;
    public float ActualTemperature;
    public boolean Aux1On;
    public boolean Aux2On;
    public com.balboawatergroup.BalboaSpa.BlowerState BlowerState;
    public int CurrentTimeHour;
    public int CurrentTimeMinute;
    public com.balboawatergroup.BalboaSpa.FilterMode FilterMode;
    public com.balboawatergroup.BalboaSpa.HeatMode HeatMode;
    public boolean Is24HourTime;
    public boolean Light1On;
    public boolean Light2On;
    public boolean MisterOn;
    public com.balboawatergroup.BalboaSpa.PumpState Pump1State;
    public com.balboawatergroup.BalboaSpa.PumpState Pump2State;
    public com.balboawatergroup.BalboaSpa.PumpState Pump3State;
    public com.balboawatergroup.BalboaSpa.PumpState Pump4State;
    public com.balboawatergroup.BalboaSpa.PumpState Pump5State;
    public com.balboawatergroup.BalboaSpa.PumpState Pump6State;
    public com.balboawatergroup.BalboaSpa.PumpState PumpStateStatus;
    public boolean SuccessfulFetch;
    public float TargetTemperature;
    public com.balboawatergroup.BalboaSpa.TemperatureRange TemperateRange;
    public com.balboawatergroup.BalboaSpa.TemperatureScale TemperatureScale;
    public com.balboawatergroup.BalboaSpa.SpaWifiState WifiState;

    public SpaControlState()
    {
        this.Light1On = 0;
        this.Light2On = 0;
        this.MisterOn = 0;
        this.Aux1On = 0;
        this.Aux2On = 0;
        this.Is24HourTime = 0;
        return;
    }
}
