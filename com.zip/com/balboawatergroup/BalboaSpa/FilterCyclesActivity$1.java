package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$1 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$1(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        p4.getStringExtra("message");
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$000(this.this$0);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$100(this.this$0);
        return;
    }
}
