package com.balboawatergroup.BalboaSpa;
synthetic class SocketListenerThread$3 {
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$PacketType;

    static SocketListenerThread$3()
    {
        NoSuchFieldError v0_5 = new int[com.balboawatergroup.BalboaSpa.PacketType.values().length];
        com.balboawatergroup.BalboaSpa.SocketListenerThread$3.$SwitchMap$com$balboawatergroup$BalboaSpa$PacketType = v0_5;
        try {
            com.balboawatergroup.BalboaSpa.PacketType.PanelUpdate.ordinal()[int v1_11] = 1;
            try {
                com.balboawatergroup.BalboaSpa.PacketType.DeviceConfiguration.ordinal()[int v1_1] = 2;
                try {
                    com.balboawatergroup.BalboaSpa.PacketType.SetupParameters.ordinal()[int v1_3] = 3;
                    try {
                        com.balboawatergroup.BalboaSpa.PacketType.SystemInformation.ordinal()[int v1_5] = 4;
                        try {
                            com.balboawatergroup.BalboaSpa.PacketType.FilterCycleInfo.ordinal()[int v1_7] = 5;
                            try {
                                com.balboawatergroup.BalboaSpa.PacketType.ModuleIdentification.ordinal()[int v1_9] = 6;
                            } catch (NoSuchFieldError v0) {
                            }
                            return;
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
