package com.balboawatergroup.BalboaSpa;
public class SpaDeviceConfiguration implements java.io.Serializable {
    private static final long serialVersionUID;
    public boolean HasAux1;
    public boolean HasAux2;
    public boolean HasBlower;
    public boolean HasLight1;
    public boolean HasLight2;
    public boolean HasMister;
    public boolean HasPump0;
    public boolean HasPump1;
    public boolean HasPump2;
    public boolean HasPump3;
    public boolean HasPump4;
    public boolean HasPump5;
    public boolean HasPump6;

    public SpaDeviceConfiguration()
    {
        this.HasPump0 = 0;
        this.HasPump1 = 0;
        this.HasPump2 = 0;
        this.HasPump3 = 0;
        this.HasPump4 = 0;
        this.HasPump5 = 0;
        this.HasPump6 = 0;
        this.HasLight1 = 0;
        this.HasLight2 = 0;
        this.HasAux1 = 0;
        this.HasBlower = 0;
        this.HasMister = 0;
        this.HasAux2 = 0;
        return;
    }
}
