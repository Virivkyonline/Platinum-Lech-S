package com.balboawatergroup.BalboaSpa;
public final enum class TemperatureRange extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.TemperatureRange[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.TemperatureRange High;
    public static final enum com.balboawatergroup.BalboaSpa.TemperatureRange Low;

    static TemperatureRange()
    {
        com.balboawatergroup.BalboaSpa.TemperatureRange.Low = new com.balboawatergroup.BalboaSpa.TemperatureRange("Low", 0);
        com.balboawatergroup.BalboaSpa.TemperatureRange.High = new com.balboawatergroup.BalboaSpa.TemperatureRange("High", 1);
        com.balboawatergroup.BalboaSpa.TemperatureRange[] v0_1 = new com.balboawatergroup.BalboaSpa.TemperatureRange[2];
        v0_1[0] = com.balboawatergroup.BalboaSpa.TemperatureRange.Low;
        v0_1[1] = com.balboawatergroup.BalboaSpa.TemperatureRange.High;
        com.balboawatergroup.BalboaSpa.TemperatureRange.$VALUES = v0_1;
        return;
    }

    private TemperatureRange(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.TemperatureRange valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.TemperatureRange) Enum.valueOf(com.balboawatergroup.BalboaSpa.TemperatureRange, p1));
    }

    public static com.balboawatergroup.BalboaSpa.TemperatureRange[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.TemperatureRange[]) com.balboawatergroup.BalboaSpa.TemperatureRange.$VALUES.clone());
    }
}
