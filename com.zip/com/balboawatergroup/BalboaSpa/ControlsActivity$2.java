package com.balboawatergroup.BalboaSpa;
synthetic class ControlsActivity$2 {
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$BlowerState;
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$PumpState;

    static ControlsActivity$2()
    {
        NoSuchFieldError v0_5 = new int[com.balboawatergroup.BalboaSpa.BlowerState.values().length];
        com.balboawatergroup.BalboaSpa.ControlsActivity$2.$SwitchMap$com$balboawatergroup$BalboaSpa$BlowerState = v0_5;
        try {
            com.balboawatergroup.BalboaSpa.BlowerState.Off.ordinal()[int v1_17] = 1;
            try {
                com.balboawatergroup.BalboaSpa.BlowerState.Low.ordinal()[int v1_1] = 2;
                try {
                    com.balboawatergroup.BalboaSpa.BlowerState.Medium.ordinal()[int v1_3] = 3;
                    try {
                        com.balboawatergroup.BalboaSpa.BlowerState.High.ordinal()[int v1_5] = 4;
                    } catch (NoSuchFieldError v0) {
                    }
                    NoSuchFieldError v0_8 = new int[com.balboawatergroup.BalboaSpa.PumpState.values().length];
                    com.balboawatergroup.BalboaSpa.ControlsActivity$2.$SwitchMap$com$balboawatergroup$BalboaSpa$PumpState = v0_8;
                    try {
                        com.balboawatergroup.BalboaSpa.PumpState.Low.ordinal()[int v1_7] = 1;
                        try {
                            com.balboawatergroup.BalboaSpa.PumpState.LowHeat.ordinal()[int v1_9] = 2;
                            try {
                                com.balboawatergroup.BalboaSpa.PumpState.Off.ordinal()[int v1_11] = 3;
                                try {
                                    com.balboawatergroup.BalboaSpa.PumpState.High.ordinal()[int v1_14] = 4;
                                    try {
                                        com.balboawatergroup.BalboaSpa.PumpState.HighHeat.ordinal()[int v1_16] = 5;
                                    } catch (NoSuchFieldError v0) {
                                    }
                                    return;
                                } catch (NoSuchFieldError v0) {
                                }
                            } catch (NoSuchFieldError v0) {
                            }
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
