package com.balboawatergroup.BalboaSpa;
public final class R$string {
    public static final int ControlsButtonText = 2131099649;
    public static final int SettingsButtonText = 2131099650;
    public static final int aboutText = 2131099651;
    public static final int app_name = 2131099648;
    public static final int cancelbuttontext = 2131099658;
    public static final int connect = 2131099664;
    public static final int defaultTemperatureSetting = 2131099652;
    public static final int demo = 2131099665;
    public static final int dialog_connect = 2131099663;
    public static final int digi_dialog_ok = 2131099667;
    public static final int digi_dialog_title = 2131099666;
    public static final int digi_dialog_visit_site = 2131099668;
    public static final int filterCycle1Label = 2131099661;
    public static final int filtercycles_startsatbuttontext = 2131099662;
    public static final int filtercycletitletext = 2131099660;
    public static final int heatModeSettingLabel = 2131099654;
    public static final int savebuttontext = 2131099659;
    public static final int temperatureUnitLabel = 2131099653;
    public static final int temprangelabel = 2131099655;
    public static final int timeOfDayLabel = 2131099656;
    public static final int timeOfDayTitle = 2131099657;

    public R$string()
    {
        return;
    }
}
