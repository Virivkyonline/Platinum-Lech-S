package com.balboawatergroup.BalboaSpa;
public class WifiNetwork {
    public boolean IsWPA;
    private int _id;
    private String _name;

    public WifiNetwork(int p1, String p2)
    {
        this._id = p1;
        this._name = p2;
        return;
    }

    public int getId()
    {
        return this._id;
    }

    public String getName()
    {
        return this._name;
    }

    public void setId(int p1)
    {
        this._id = p1;
        return;
    }

    public void setName(String p1)
    {
        this._name = p1;
        return;
    }
}
