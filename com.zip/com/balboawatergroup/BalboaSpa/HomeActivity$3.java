package com.balboawatergroup.BalboaSpa;
 class HomeActivity$3 extends android.os.Handler {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$3(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void handleMessage(android.os.Message p4)
    {
        switch (com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$WifiSocketState[com.balboawatergroup.BalboaSpa.SpaController.GetWifiSocketState().ordinal()]) {
            case 1:
                if (com.balboawatergroup.BalboaSpa.HomeActivity.access$200(this.this$0)) {
                    this.this$0.tvConnectionState.setText("");
                } else {
                    this.this$0.tvConnectionState.setText("Connected");
                    com.balboawatergroup.BalboaSpa.HomeActivity.access$202(this.this$0, 1);
                }
                break;
            case 2:
                this.this$0.tvConnectionState.setText("Disconnected");
                break;
            case 3:
                this.this$0.tvConnectionState.setText("");
                break;
            case 4:
                if (com.balboawatergroup.BalboaSpa.HomeActivity.access$300(this.this$0) != 0) {
                    if (com.balboawatergroup.BalboaSpa.HomeActivity.access$300(this.this$0) != 1) {
                        if (com.balboawatergroup.BalboaSpa.HomeActivity.access$300(this.this$0) != 2) {
                            if (com.balboawatergroup.BalboaSpa.HomeActivity.access$300(this.this$0) == 3) {
                                this.this$0.tvConnectionState.setText("Connecting...");
                                com.balboawatergroup.BalboaSpa.HomeActivity.access$302(this.this$0, 0);
                            }
                        } else {
                            this.this$0.tvConnectionState.setText("Connecting..");
                        }
                    } else {
                        this.this$0.tvConnectionState.setText("Connecting.");
                    }
                } else {
                    this.this$0.tvConnectionState.setText("Connecting");
                }
                com.balboawatergroup.BalboaSpa.HomeActivity.access$308(this.this$0);
                break;
        }
        return;
    }
}
