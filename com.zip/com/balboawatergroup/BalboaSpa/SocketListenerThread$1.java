package com.balboawatergroup.BalboaSpa;
 class SocketListenerThread$1 extends android.os.Handler {
    final synthetic com.balboawatergroup.BalboaSpa.SocketListenerThread this$0;

    SocketListenerThread$1(com.balboawatergroup.BalboaSpa.SocketListenerThread p1)
    {
        this.this$0 = p1;
        return;
    }

    public void handleMessage(android.os.Message p4)
    {
        if (p4.what == 0) {
            com.balboawatergroup.BalboaSpa.SocketListenerThread.access$002(this.this$0, p4.getData().getByteArray("outgoingData"));
            com.balboawatergroup.BalboaSpa.SocketListenerThread.access$102(this.this$0, p4.getData().getInt("outgoingDataLength"));
            com.balboawatergroup.BalboaSpa.SocketListenerThread.access$202(this.this$0, 1);
        }
        return;
    }
}
