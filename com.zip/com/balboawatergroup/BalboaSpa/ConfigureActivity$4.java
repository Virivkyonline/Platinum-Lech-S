package com.balboawatergroup.BalboaSpa;
 class ConfigureActivity$4 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.ConfigureActivity this$0;
    final synthetic android.net.wifi.WifiManager val$wifiManager;

    ConfigureActivity$4(com.balboawatergroup.BalboaSpa.ConfigureActivity p1, android.net.wifi.WifiManager p2)
    {
        this.this$0 = p1;
        this.val$wifiManager = p2;
        return;
    }

    public void onReceive(android.content.Context p7, android.content.Intent p8)
    {
        java.util.List v2 = this.val$wifiManager.getScanResults();
        com.balboawatergroup.BalboaSpa.WifiNetwork[] v1 = new com.balboawatergroup.BalboaSpa.WifiNetwork[v2.size()];
        int v0 = 0;
        while (v0 < v2.size()) {
            v1[v0] = new com.balboawatergroup.BalboaSpa.WifiNetwork(v0, ((android.net.wifi.ScanResult) v2.get(v0)).SSID);
            v0++;
        }
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$402(this.this$0, ((android.widget.Spinner) this.this$0.findViewById(2131230730)));
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$102(this.this$0, new com.balboawatergroup.BalboaSpa.SpinnerAdapter(p7, 17367048, v1));
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$400(this.this$0).setAdapter(com.balboawatergroup.BalboaSpa.ConfigureActivity.access$100(this.this$0));
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$400(this.this$0).setOnItemSelectedListener(new com.balboawatergroup.BalboaSpa.ConfigureActivity$4$1(this));
        return;
    }
}
