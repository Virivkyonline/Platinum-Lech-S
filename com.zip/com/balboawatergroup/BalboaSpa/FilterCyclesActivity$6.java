package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$6 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$6(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p2)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$200(this.this$0);
        return;
    }
}
