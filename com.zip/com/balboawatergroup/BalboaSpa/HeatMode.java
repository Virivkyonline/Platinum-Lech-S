package com.balboawatergroup.BalboaSpa;
public final enum class HeatMode extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.HeatMode[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.HeatMode None;
    public static final enum com.balboawatergroup.BalboaSpa.HeatMode Ready;
    public static final enum com.balboawatergroup.BalboaSpa.HeatMode ReadyInRest;
    public static final enum com.balboawatergroup.BalboaSpa.HeatMode Rest;

    static HeatMode()
    {
        com.balboawatergroup.BalboaSpa.HeatMode.Ready = new com.balboawatergroup.BalboaSpa.HeatMode("Ready", 0);
        com.balboawatergroup.BalboaSpa.HeatMode.ReadyInRest = new com.balboawatergroup.BalboaSpa.HeatMode("ReadyInRest", 1);
        com.balboawatergroup.BalboaSpa.HeatMode.Rest = new com.balboawatergroup.BalboaSpa.HeatMode("Rest", 2);
        com.balboawatergroup.BalboaSpa.HeatMode.None = new com.balboawatergroup.BalboaSpa.HeatMode("None", 3);
        com.balboawatergroup.BalboaSpa.HeatMode[] v0_6 = new com.balboawatergroup.BalboaSpa.HeatMode[4];
        v0_6[0] = com.balboawatergroup.BalboaSpa.HeatMode.Ready;
        v0_6[1] = com.balboawatergroup.BalboaSpa.HeatMode.ReadyInRest;
        v0_6[2] = com.balboawatergroup.BalboaSpa.HeatMode.Rest;
        v0_6[3] = com.balboawatergroup.BalboaSpa.HeatMode.None;
        com.balboawatergroup.BalboaSpa.HeatMode.$VALUES = v0_6;
        return;
    }

    private HeatMode(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.HeatMode valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.HeatMode) Enum.valueOf(com.balboawatergroup.BalboaSpa.HeatMode, p1));
    }

    public static com.balboawatergroup.BalboaSpa.HeatMode[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.HeatMode[]) com.balboawatergroup.BalboaSpa.HeatMode.$VALUES.clone());
    }
}
