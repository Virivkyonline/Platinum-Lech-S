package com.balboawatergroup.BalboaSpa;
 class HomeActivity$4 extends android.os.Handler {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$4(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void handleMessage(android.os.Message p3)
    {
        switch (com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$WifiSocketState[com.balboawatergroup.BalboaSpa.SpaController.GetWifiSocketState().ordinal()]) {
            case 1:
            case 3:
            default:
                break;
            case 2:
                com.balboawatergroup.BalboaSpa.HomeActivity.access$400(this.this$0);
            case 1:
            case 3:
                break;
            case 4:
                com.balboawatergroup.BalboaSpa.HomeActivity.access$400(this.this$0);
                break;
        }
        return;
    }
}
