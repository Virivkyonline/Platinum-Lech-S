package com.balboawatergroup.BalboaSpa;
 class HomeActivity$7 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$7(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p4, android.content.Intent p5)
    {
        p5.getStringExtra("message");
        this.this$0.connectDialogFragment.goAway();
        this.this$0.isConnectDialogCurrentlyBeingShown = Boolean.valueOf(0);
        com.balboawatergroup.BalboaSpa.HomeActivity.access$500(this.this$0);
        return;
    }
}
