package com.balboawatergroup.BalboaSpa;
public class SpaController {
    public static String CurrentMode = "";
    public static boolean HasPump0 = False;
    private static final long MAX_WIFI_CONNECTION_TIME_MS = 5000;
    public static final String PREFS_NAME = "MyPrefsFile";
    public static android.os.Handler UIHandler;
    private static android.content.Context context;
    private static java.util.TimerTask mConnectionManagerTask;
    private static java.util.Timer mConnectionManagerTimer;
    private static com.balboawatergroup.BalboaSpa.ISpaCommunicator spaCommunicator;

    static SpaController()
    {
        com.balboawatergroup.BalboaSpa.SpaController.CurrentMode = "";
        com.balboawatergroup.BalboaSpa.SpaController.UIHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        return;
    }

    public SpaController()
    {
        return;
    }

    public static void Aux1ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Aux1ControlPushed();
        return;
    }

    public static void Aux2ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Aux2ControlPushed();
        return;
    }

    public static void BlowerControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.BlowerControlPushed();
        return;
    }

    public static void ConnectToWifi(com.balboawatergroup.BalboaSpa.ConnectionMethod p1, com.balboawatergroup.BalboaSpa.SecurityType p2, String p3, String p4)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.ConnectToWifi(p1, p2, p3, p4);
        return;
    }

    public static boolean Get24HourTime()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetCurrentState().Is24HourTime;
    }

    public static String GetDigiDeviceIdentifier()
    {
        String v1 = 0;
        if (com.balboawatergroup.BalboaSpa.SpaController.context != null) {
            v1 = com.balboawatergroup.BalboaSpa.SpaController.context.getSharedPreferences("MyPrefsFile", 0).getString("idigiDeviceIdentifier", 0);
        }
        return v1;
    }

    public static com.balboawatergroup.BalboaSpa.FilterCycle GetFilterCycle()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetFilterCycle();
    }

    public static com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetOldVersionConfiguration()
    {
        com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration v0_1 = new com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration();
        v0_1.HasLight1 = 1;
        v0_1.HasPump2 = 1;
        v0_1.HasMister = 1;
        v0_1.HasBlower = 1;
        v0_1.HasAux1 = 1;
        v0_1.HasLight2 = 1;
        v0_1.HasAux2 = 1;
        v0_1.HasPump0 = 1;
        v0_1.HasPump1 = 1;
        v0_1.HasPump3 = 1;
        v0_1.HasPump4 = 1;
        v0_1.HasPump5 = 0;
        v0_1.HasPump6 = 0;
        return v0_1;
    }

    public static com.balboawatergroup.BalboaSpa.SpaControlState GetSpaControlState()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetCurrentState();
    }

    public static com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetSpaDeviceConfiguration()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetCurrentConfiguration();
    }

    public static com.balboawatergroup.BalboaSpa.SpaSystemInformation GetSpaSystemInformation()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetCurrentSystemInformation();
    }

    public static int GetSpaTimeHour()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState().CurrentTimeHour;
    }

    public static int GetSpaTimeMinute()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState().CurrentTimeMinute;
    }

    public static com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.GetWifiSocketState();
    }

    public static boolean HasCurrentDeviceConfig()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.HasCurrentDeviceConfig();
    }

    public static void HeatModePushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.HeatModePushed();
        return;
    }

    public static boolean IsIDigiModeAvailable()
    {
        int v1 = 0;
        String v0 = com.balboawatergroup.BalboaSpa.SpaController.GetDigiDeviceIdentifier();
        if (v0 != null) {
            android.util.Log.i("Balboa", "Found iDigi device ID, querying iDigi to see if it is online");
            if (com.balboawatergroup.BalboaSpa.SpaController.isDeviceOnline(v0)) {
                v1 = 1;
            }
        }
        return v1;
    }

    public static void Light1ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Light1ControlPushed();
        return;
    }

    public static void Light2ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Light2ControlPushed();
        return;
    }

    public static void MisterControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.MisterControlPushed();
        return;
    }

    public static void Pump1ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Pump1ControlPushed();
        return;
    }

    public static void Pump2ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Pump2ControlPushed();
        return;
    }

    public static void Pump3ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Pump3ControlPushed();
        return;
    }

    public static void Pump4ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Pump4ControlPushed();
        return;
    }

    public static void Pump5ControlPushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Pump5ControlPushed();
        return;
    }

    public static void SaveDigiDeviceIdentifier(byte[] p6)
    {
        if (com.balboawatergroup.BalboaSpa.SpaController.context != null) {
            String v0 = com.balboawatergroup.BalboaSpa.Utility.bytesToDigiIdentifier(p6);
            android.content.SharedPreferences$Editor v1 = com.balboawatergroup.BalboaSpa.SpaController.context.getSharedPreferences("MyPrefsFile", 0).edit();
            v1.putString("idigiDeviceIdentifier", v0);
            v1.commit();
        }
        return;
    }

    public static void SaveFilterCycle(com.balboawatergroup.BalboaSpa.FilterCycle p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SaveFilterCycle(p1);
        return;
    }

    public static void SendDevicePresentQuery()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SendDevicePresentQuery();
        return;
    }

    public static void SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SendPanelRequest(p1);
        return;
    }

    public static void SetDemoMode()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator = new com.balboawatergroup.BalboaSpa.DemoCommunicator();
        com.balboawatergroup.BalboaSpa.SpaController.CurrentMode = "Demo";
        return;
    }

    public static void SetIDigiMode(android.content.Context p2)
    {
        com.balboawatergroup.BalboaSpa.SpaController.context = p2;
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator = new com.balboawatergroup.BalboaSpa.iDigiCommunicator(com.balboawatergroup.BalboaSpa.SpaController.GetDigiDeviceIdentifier(), p2);
        com.balboawatergroup.BalboaSpa.SpaController.CurrentMode = "iDigi";
        return;
    }

    public static void SetTargetTemperature(float p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SetTargetTemperature(p1);
        return;
    }

    public static void SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SetTemperatureScale(p1);
        return;
    }

    public static void SetTime(int p1, int p2, boolean p3)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.SetTime(p1, p2, p3);
        return;
    }

    public static void SetWifiMode(android.content.Context p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.startConnectionManagerTimer();
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator = new com.balboawatergroup.BalboaSpa.WifiCommunicator(p1);
        com.balboawatergroup.BalboaSpa.SpaController.context = p1;
        com.balboawatergroup.BalboaSpa.SpaController.CurrentMode = "Wifi";
        return;
    }

    public static void StartThread()
    {
        if (com.balboawatergroup.BalboaSpa.SpaController.context != null) {
            com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.StartThread(com.balboawatergroup.BalboaSpa.SpaController.context);
            if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode == "Wifi") {
                com.balboawatergroup.BalboaSpa.SpaController.startConnectionManagerTimer();
            }
        }
        return;
    }

    public static void StopThread()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.StopThread();
        return;
    }

    public static void TempRangePushed()
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.TempRangePushed();
        return;
    }

    static synthetic android.content.Context access$000()
    {
        return com.balboawatergroup.BalboaSpa.SpaController.context;
    }

    private static boolean isDeviceOnline(String p1)
    {
        return 1;
    }

    public static void runOnUI(Runnable p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.UIHandler.post(p1);
        return;
    }

    public static void set24HourTime(boolean p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.spaCommunicator.Set24HourTime(p1);
        return;
    }

    public static void startConnectionManagerTimer()
    {
        com.balboawatergroup.BalboaSpa.SpaController.mConnectionManagerTimer = new java.util.Timer();
        com.balboawatergroup.BalboaSpa.SpaController.mConnectionManagerTask = new com.balboawatergroup.BalboaSpa.SpaController$2(new com.balboawatergroup.BalboaSpa.SpaController$1());
        com.balboawatergroup.BalboaSpa.SpaController.mConnectionManagerTimer.schedule(com.balboawatergroup.BalboaSpa.SpaController.mConnectionManagerTask, 5000);
        return;
    }
}
