package com.balboawatergroup.BalboaSpa;
 class SettingsActivity$5 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.SettingsActivity this$0;

    SettingsActivity$5(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$502(this.this$0, 2);
        if (!com.balboawatergroup.BalboaSpa.SettingsActivity.access$000(this.this$0).isChecked()) {
            com.balboawatergroup.BalboaSpa.SpaController.SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit);
        } else {
            com.balboawatergroup.BalboaSpa.SpaController.SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius);
        }
        if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode == "Demo") {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$700(this.this$0);
        }
        return;
    }
}
