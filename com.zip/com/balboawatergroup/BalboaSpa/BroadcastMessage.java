package com.balboawatergroup.BalboaSpa;
public final enum class BroadcastMessage extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.BroadcastMessage[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.BroadcastMessage FilterCyclesUpdated;

    static BroadcastMessage()
    {
        com.balboawatergroup.BalboaSpa.BroadcastMessage.FilterCyclesUpdated = new com.balboawatergroup.BalboaSpa.BroadcastMessage("FilterCyclesUpdated", 0);
        com.balboawatergroup.BalboaSpa.BroadcastMessage[] v0_3 = new com.balboawatergroup.BalboaSpa.BroadcastMessage[1];
        v0_3[0] = com.balboawatergroup.BalboaSpa.BroadcastMessage.FilterCyclesUpdated;
        com.balboawatergroup.BalboaSpa.BroadcastMessage.$VALUES = v0_3;
        return;
    }

    private BroadcastMessage(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.BroadcastMessage valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.BroadcastMessage) Enum.valueOf(com.balboawatergroup.BalboaSpa.BroadcastMessage, p1));
    }

    public static com.balboawatergroup.BalboaSpa.BroadcastMessage[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.BroadcastMessage[]) com.balboawatergroup.BalboaSpa.BroadcastMessage.$VALUES.clone());
    }
}
