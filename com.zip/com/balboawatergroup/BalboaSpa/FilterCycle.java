package com.balboawatergroup.BalboaSpa;
public class FilterCycle implements java.io.Serializable {
    private static final long serialVersionUID;
    public int FilterCycle1DurationHour;
    public int FilterCycle1DurationMinute;
    public int FilterCycle1StartsAtHour;
    public int FilterCycle1StartsAtMinute;
    public int FilterCycle2DurationHour;
    public int FilterCycle2DurationMinute;
    public boolean FilterCycle2Enabled;
    public int FilterCycle2StartsAtHour;
    public int FilterCycle2StartsAtMinute;

    public FilterCycle()
    {
        return;
    }
}
