package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$16 implements android.app.TimePickerDialog$OnTimeSetListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$16(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeSet(android.widget.TimePicker p3, int p4, int p5)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$802(this.this$0, p4);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$902(this.this$0, p5);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$100(this.this$0);
        this.this$0.removeDialog(994);
        return;
    }
}
