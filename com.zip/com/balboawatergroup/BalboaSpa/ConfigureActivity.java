package com.balboawatergroup.BalboaSpa;
public class ConfigureActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    private com.balboawatergroup.BalboaSpa.SpinnerAdapter adapter;
    private android.widget.Button btnSave;
    private android.widget.CheckBox cbWPS;
    private android.widget.EditText etKey;
    private android.widget.EditText etSSID;
    private android.widget.ImageView imgAccessibility;
    private android.widget.Spinner mySpinner;
    private android.widget.RadioButton rbOpen;
    private android.widget.RadioButton rbWEP;
    private android.widget.RadioButton rbWPA;

    public ConfigureActivity()
    {
        return;
    }

    private void ApplyLocks()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v0 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL) {
            if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT) {
                if (v0.AccessibilityType == com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE) {
                    this.imgAccessibility.setImageResource(2130837562);
                    this.imgAccessibility.setVisibility(0);
                    this.btnSave.setEnabled(0);
                    this.etSSID.setEnabled(0);
                    this.etKey.setEnabled(0);
                    this.cbWPS.setEnabled(0);
                }
            } else {
                this.imgAccessibility.setImageResource(2130837563);
                this.imgAccessibility.setVisibility(0);
                this.btnSave.setEnabled(0);
                this.etSSID.setEnabled(0);
                this.etKey.setEnabled(0);
                this.cbWPS.setEnabled(0);
            }
        } else {
            this.imgAccessibility.setVisibility(4);
            this.btnSave.setEnabled(1);
            this.etSSID.setEnabled(1);
            this.etKey.setEnabled(1);
            this.cbWPS.setEnabled(1);
        }
        return;
    }

    private void ShowConfiguredNetworks()
    {
        java.util.List v2 = ((android.net.wifi.WifiManager) this.getSystemService("wifi")).getConfiguredNetworks();
        if (v2 != null) {
            com.balboawatergroup.BalboaSpa.WifiNetwork[] v1 = new com.balboawatergroup.BalboaSpa.WifiNetwork[v2.size()];
            int v0 = 0;
            while (v0 < v2.size()) {
                v1[v0] = new com.balboawatergroup.BalboaSpa.WifiNetwork(v0, ((android.net.wifi.WifiConfiguration) v2.get(v0)).SSID.replace("\"", ""));
                if (this.isWPA(((android.net.wifi.WifiConfiguration) v2.get(v0)))) {
                    v1[v0].IsWPA = 1;
                }
                v0++;
            }
            this.mySpinner = ((android.widget.Spinner) this.findViewById(2131230730));
            this.adapter = new com.balboawatergroup.BalboaSpa.SpinnerAdapter(this, 17367048, v1);
            this.mySpinner.setAdapter(this.adapter);
            this.mySpinner.setOnItemSelectedListener(new com.balboawatergroup.BalboaSpa.ConfigureActivity$3(this));
        }
        return;
    }

    static synthetic void access$000(com.balboawatergroup.BalboaSpa.ConfigureActivity p0)
    {
        p0.saveConfiguration();
        return;
    }

    static synthetic com.balboawatergroup.BalboaSpa.SpinnerAdapter access$100(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        return p1.adapter;
    }

    static synthetic com.balboawatergroup.BalboaSpa.SpinnerAdapter access$102(com.balboawatergroup.BalboaSpa.ConfigureActivity p0, com.balboawatergroup.BalboaSpa.SpinnerAdapter p1)
    {
        p0.adapter = p1;
        return p1;
    }

    static synthetic android.widget.EditText access$200(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        return p1.etSSID;
    }

    static synthetic android.widget.RadioButton access$300(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        return p1.rbWPA;
    }

    static synthetic android.widget.Spinner access$400(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        return p1.mySpinner;
    }

    static synthetic android.widget.Spinner access$402(com.balboawatergroup.BalboaSpa.ConfigureActivity p0, android.widget.Spinner p1)
    {
        p0.mySpinner = p1;
        return p1;
    }

    private void getControls()
    {
        this.etSSID = ((android.widget.EditText) this.findViewById(2131230729));
        this.etKey = ((android.widget.EditText) this.findViewById(2131230731));
        this.rbOpen = ((android.widget.RadioButton) this.findViewById(2131230725));
        this.rbWEP = ((android.widget.RadioButton) this.findViewById(2131230727));
        this.rbWPA = ((android.widget.RadioButton) this.findViewById(2131230728));
        this.cbWPS = ((android.widget.CheckBox) this.findViewById(2131230726));
        this.btnSave = ((android.widget.Button) this.findViewById(2131230733));
        this.imgAccessibility = ((android.widget.ImageView) this.findViewById(2131230734));
        return;
    }

    private boolean isWPA(android.net.wifi.WifiConfiguration p3)
    {
        int v0 = 1;
        if ((p3.allowedKeyManagement == null) || (!p3.allowedKeyManagement.get(1))) {
            v0 = 0;
        }
        return v0;
    }

    private void saveConfiguration()
    {
        com.balboawatergroup.BalboaSpa.ConnectionMethod v0;
        if (!this.cbWPS.isChecked()) {
            v0 = com.balboawatergroup.BalboaSpa.ConnectionMethod.KnownNetwork;
        } else {
            v0 = com.balboawatergroup.BalboaSpa.ConnectionMethod.WPS;
        }
        com.balboawatergroup.BalboaSpa.SecurityType v1;
        if (!this.rbOpen.isChecked()) {
            if (!this.rbWEP.isChecked()) {
                v1 = com.balboawatergroup.BalboaSpa.SecurityType.WPA;
            } else {
                v1 = com.balboawatergroup.BalboaSpa.SecurityType.WEP;
            }
        } else {
            v1 = com.balboawatergroup.BalboaSpa.SecurityType.Open;
        }
        com.balboawatergroup.BalboaSpa.SpaController.ConnectToWifi(v0, v1, this.etSSID.getText().toString(), this.etKey.getText().toString());
        new android.app.AlertDialog$Builder(this).setTitle("Wifi Link").setMessage("You must now connect your mobile device to the WIFI network your spa just joined").setIcon(17301543).setPositiveButton("OK", new com.balboawatergroup.BalboaSpa.ConfigureActivity$2(this)).show();
        return;
    }

    public void onCreate(android.os.Bundle p2)
    {
        super.onCreate(p2);
        this.setContentView(2130903041);
        this.getControls();
        this.ShowConfiguredNetworks();
        this.ApplyLocks();
        return;
    }

    public void onWindowFocusChanged(boolean p1)
    {
        return;
    }

    public void saveClicked(android.view.View p4)
    {
        new android.app.AlertDialog$Builder(this).setTitle("Confirm").setMessage("Do you really want to change the WIFI settings on your spa?").setIcon(17301543).setPositiveButton(17039379, new com.balboawatergroup.BalboaSpa.ConfigureActivity$1(this)).setNegativeButton(17039369, 0).show();
        return;
    }

    public void scan(android.view.View p5)
    {
        com.balboawatergroup.BalboaSpa.ConfigureActivity$4 v1_1 = new com.balboawatergroup.BalboaSpa.ConfigureActivity$4(this, ((android.net.wifi.WifiManager) this.getSystemService("wifi")));
        android.content.IntentFilter v0_1 = new android.content.IntentFilter();
        v0_1.addAction("android.net.wifi.SCAN_RESULTS");
        this.registerReceiver(v1_1, v0_1);
        return;
    }
}
