package com.balboawatergroup.BalboaSpa;
public class InstructionsActivity extends android.app.Activity {
    private android.widget.Button button;
    private android.widget.CheckBox checkBox;
    private android.webkit.WebView webView;

    public InstructionsActivity()
    {
        return;
    }

    static synthetic android.widget.CheckBox access$000(com.balboawatergroup.BalboaSpa.InstructionsActivity p1)
    {
        return p1.checkBox;
    }

    public void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        this.setContentView(2130903045);
        this.webView = ((android.webkit.WebView) this.findViewById(2131230784));
        this.checkBox = ((android.widget.CheckBox) this.findViewById(2131230785));
        this.button = ((android.widget.Button) this.findViewById(2131230720));
        this.webView.loadData("<html><body style=\"font-family:sans-serif;font-size:15px;background-color:transparent;text-align:justify;color:#FFFFFF;\">Welcome to bwa&#0153;, Balboa Worldwide app that allows you to access your hot tub anytime, anywhere, anyplace.<br/><br/>For detailed installation and user guides visit <a style=\'color:#CFFFA4\' href=\'http://www.balboawater.com/bwa\'>www.balboawater.com/bwa</a> </br></br></body></html>", "text/html", 0);
        this.webView.setBackgroundColor(0);
        this.button.setOnClickListener(new com.balboawatergroup.BalboaSpa.InstructionsActivity$1(this));
        return;
    }
}
