package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$3 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$3(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        this.this$0.showDialog(995);
        return;
    }
}
