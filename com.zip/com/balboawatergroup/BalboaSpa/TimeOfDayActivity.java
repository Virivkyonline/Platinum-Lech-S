package com.balboawatergroup.BalboaSpa;
public class TimeOfDayActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    static final int TIME_DIALOG_ID = 999;
    private android.widget.Button btnChangeTime;
    private android.widget.Button btnDeviceTime;
    private int hour;
    private android.widget.ImageView imgAccessibility;
    private android.content.BroadcastReceiver mMessageReceiver;
    private int minute;
    private android.widget.ToggleButton tb24HourTime;
    private android.app.TimePickerDialog$OnTimeSetListener timePickerListener;
    private android.widget.TextView tvDisplayTime;

    public TimeOfDayActivity()
    {
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.TimeOfDayActivity$1(this);
        this.timePickerListener = new com.balboawatergroup.BalboaSpa.TimeOfDayActivity$5(this);
        return;
    }

    private void ApplyLocks()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v0 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL) {
            if (v0.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT) {
                if (v0.AccessibilityType == com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE) {
                    this.imgAccessibility.setImageResource(2130837562);
                    this.imgAccessibility.setVisibility(0);
                    this.btnChangeTime.setEnabled(0);
                    this.btnDeviceTime.setEnabled(0);
                }
            } else {
                this.imgAccessibility.setImageResource(2130837563);
                this.imgAccessibility.setVisibility(0);
                this.btnChangeTime.setEnabled(0);
                this.btnDeviceTime.setEnabled(0);
            }
        } else {
            this.imgAccessibility.setVisibility(4);
            this.btnChangeTime.setEnabled(1);
            this.btnDeviceTime.setEnabled(1);
        }
        return;
    }

    static synthetic void access$000(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p0)
    {
        p0.updateUI();
        return;
    }

    static synthetic void access$100(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p0)
    {
        p0.useDeviceTime();
        return;
    }

    static synthetic android.widget.ToggleButton access$200(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        return p1.tb24HourTime;
    }

    static synthetic int access$300(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        return p1.hour;
    }

    static synthetic int access$302(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p0, int p1)
    {
        p0.hour = p1;
        return p1;
    }

    static synthetic int access$400(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        return p1.minute;
    }

    static synthetic int access$402(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p0, int p1)
    {
        p0.minute = p1;
        return p1;
    }

    static synthetic void access$500(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p0, int p1, int p2)
    {
        p0.setDeviceTime(p1, p2);
        return;
    }

    private static String pad(int p2)
    {
        String v0_2;
        if (p2 < 10) {
            v0_2 = new StringBuilder().append("0").append(String.valueOf(p2)).toString();
        } else {
            v0_2 = String.valueOf(p2);
        }
        return v0_2;
    }

    private void setDeviceTime(int p2, int p3)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetTime(p2, p3, this.tb24HourTime.isChecked());
        return;
    }

    private void updateUI()
    {
        this.hour = com.balboawatergroup.BalboaSpa.SpaController.GetSpaTimeHour();
        this.minute = com.balboawatergroup.BalboaSpa.SpaController.GetSpaTimeMinute();
        String v0 = "";
        if (!com.balboawatergroup.BalboaSpa.SpaController.Get24HourTime()) {
            if (this.hour <= 12) {
                v0 = "AM";
            } else {
                v0 = "PM";
                this.hour = (this.hour - 12);
            }
        }
        this.tb24HourTime.setChecked(com.balboawatergroup.BalboaSpa.SpaController.Get24HourTime());
        this.tvDisplayTime.setText(new StringBuilder().append(com.balboawatergroup.BalboaSpa.TimeOfDayActivity.pad(this.hour)).append(":").append(com.balboawatergroup.BalboaSpa.TimeOfDayActivity.pad(this.minute)).append(v0));
        this.ApplyLocks();
        return;
    }

    private void useDeviceTime()
    {
        int v1;
        java.util.Calendar v0 = java.util.Calendar.getInstance();
        if (!this.tb24HourTime.isChecked()) {
            v1 = v0.get(11);
        } else {
            v1 = v0.get(11);
        }
        int v2 = v0.get(12);
        this.hour = v1;
        this.minute = v2;
        this.updateUI();
        this.setDeviceTime(v1, v2);
        return;
    }

    public void addListenersOnButtons()
    {
        this.btnChangeTime = ((android.widget.Button) this.findViewById(2131230807));
        this.btnChangeTime.setOnClickListener(new com.balboawatergroup.BalboaSpa.TimeOfDayActivity$2(this));
        this.btnDeviceTime = ((android.widget.Button) this.findViewById(2131230808));
        this.btnDeviceTime.setOnClickListener(new com.balboawatergroup.BalboaSpa.TimeOfDayActivity$3(this));
        this.tb24HourTime.setOnClickListener(new com.balboawatergroup.BalboaSpa.TimeOfDayActivity$4(this));
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        this.setContentView(2130903048);
        this.tb24HourTime = ((android.widget.ToggleButton) this.findViewById(2131230809));
        this.tvDisplayTime = ((android.widget.TextView) this.findViewById(2131230806));
        this.imgAccessibility = ((android.widget.ImageView) this.findViewById(2131230734));
        this.addListenersOnButtons();
        this.updateUI();
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter("spa-state-updated"));
        return;
    }

    protected android.app.Dialog onCreateDialog(int p7)
    {
        android.app.TimePickerDialog v0_1;
        switch (p7) {
            case 999:
                v0_1 = new android.app.TimePickerDialog(this, this.timePickerListener, com.balboawatergroup.BalboaSpa.SpaController.GetSpaTimeHour(), this.minute, this.tb24HourTime.isChecked());
                break;
            default:
                v0_1 = 0;
        }
        return v0_1;
    }

    protected void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this).unregisterReceiver(this.mMessageReceiver);
        super.onDestroy();
        return;
    }
}
