package com.balboawatergroup.BalboaSpa;
public class Utility {
    public static final String PREFS_NAME = "MyPrefsFile";

    public Utility()
    {
        return;
    }

    public static byte CalculateChecksum(byte[] p1, int p2, boolean p3)
    {
        return com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(p1, p2, p3, 1);
    }

    public static byte CalculateChecksum(byte[] p4, int p5, boolean p6, boolean p7)
    {
        byte v1_0;
        if (!p6) {
            v1_0 = ((byte) (com.balboawatergroup.BalboaSpa.bbCRC8.HdlcCrc8(p4, p5) ^ 255));
        } else {
            byte[] v0 = new byte[p5];
            System.arraycopy(p4, 1, v0, 0, p5);
            v1_0 = com.balboawatergroup.BalboaSpa.bbCRC8.HdlcCrc8(v0, p5);
            if (p7) {
                v1_0 = ((byte) (v1_0 ^ 255));
            }
        }
        return v1_0;
    }

    public static Boolean GetBooleanSettingValue(String p3, Boolean p4, android.content.Context p5)
    {
        return Boolean.valueOf(p5.getSharedPreferences("MyPrefsFile", 0).getBoolean(p3, p4.booleanValue()));
    }

    public static byte[] GetBytesForFilterCycle(com.balboawatergroup.BalboaSpa.FilterCycle p11)
    {
        int v2;
        if (!p11.FilterCycle2Enabled) {
            v2 = 0;
        } else {
            v2 = 128;
        }
        int v3 = p11.FilterCycle2StartsAtHour;
        byte[] v0 = new byte[15];
        v0[0] = 126;
        v0[1] = 13;
        v0[2] = 10;
        v0[3] = -65;
        v0[4] = 35;
        v0[5] = ((byte) p11.FilterCycle1StartsAtHour);
        v0[6] = ((byte) p11.FilterCycle1StartsAtMinute);
        v0[7] = ((byte) p11.FilterCycle1DurationHour);
        v0[8] = ((byte) p11.FilterCycle1DurationMinute);
        v0[9] = ((byte) (v2 | v3));
        v0[10] = ((byte) p11.FilterCycle2StartsAtMinute);
        v0[11] = ((byte) p11.FilterCycle2DurationHour);
        v0[12] = ((byte) p11.FilterCycle2DurationMinute);
        v0[13] = 0;
        v0[14] = 126;
        v0[13] = com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(v0, 12, 1);
        return v0;
    }

    public static void StoreBooleanSettingValue(String p4, Boolean p5, android.content.Context p6)
    {
        android.content.SharedPreferences$Editor v0 = p6.getSharedPreferences("MyPrefsFile", 0).edit();
        v0.putBoolean(p4, p5.booleanValue());
        v0.commit();
        return;
    }

    public static String bytesToDigiIdentifier(byte[] p7)
    {
        char[] v0 = new char[16];
        v0 = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70};
        char[] v1 = new char[((p7.length * 2) + 3)];
        int v3 = 0;
        int v2 = 0;
        while (v2 < p7.length) {
            int v4 = (p7[v2] & 255);
            v1[v3] = v0[(v4 >> 4)];
            v1[(v3 + 1)] = v0[(v4 & 15)];
            if ((v3 != 6) && ((v3 != 15) && (v3 != 24))) {
                v3 += 2;
            } else {
                v1[(v3 + 2)] = 45;
                v3 += 3;
            }
            v2++;
        }
        return new String(v1);
    }

    public static String bytesToHex(byte[] p6)
    {
        char[] v0 = new char[16];
        v0 = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70};
        char[] v1 = new char[(p6.length * 2)];
        int v2 = 0;
        while (v2 < p6.length) {
            int v3 = (p6[v2] & 255);
            v1[(v2 * 2)] = v0[(v3 >> 4)];
            v1[((v2 * 2) + 1)] = v0[(v3 & 15)];
            v2++;
        }
        return new String(v1);
    }

    public static String formatDouble(double p4)
    {
        String v0_0;
        if (p4 != ((double) ((int) p4))) {
            Object[] v1_1 = new Object[1];
            v1_1[0] = Double.valueOf(p4);
            v0_0 = String.format("%s", v1_1);
        } else {
            Object[] v1_0 = new Object[1];
            v1_0[0] = Integer.valueOf(((int) p4));
            v0_0 = String.format("%d", v1_0);
        }
        return v0_0;
    }
}
