package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$3$1$1 implements java.lang.Runnable {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3$1 this$2;

    ConnectDialogFragment$3$1$1(com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3$1 p1)
    {
        this.this$2 = p1;
        return;
    }

    public void run()
    {
        if (this.this$2.this$1.this$0.progress != null) {
            this.this$2.this$1.this$0.progress.dismiss();
        }
        return;
    }
}
