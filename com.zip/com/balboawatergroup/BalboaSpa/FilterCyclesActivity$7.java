package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$7 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$7(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p2)
    {
        this.this$0.finish();
        return;
    }
}
