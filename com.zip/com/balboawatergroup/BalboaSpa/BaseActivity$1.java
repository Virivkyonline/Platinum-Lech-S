package com.balboawatergroup.BalboaSpa;
 class BaseActivity$1 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.BaseActivity this$0;

    BaseActivity$1(com.balboawatergroup.BalboaSpa.BaseActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p5, android.content.Intent p6)
    {
        this.this$0.startActivity(new android.content.Intent(this.this$0, com.balboawatergroup.BalboaSpa.HomeActivity));
        return;
    }
}
