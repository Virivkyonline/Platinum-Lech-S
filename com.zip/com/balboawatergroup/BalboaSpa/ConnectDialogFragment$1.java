package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$1 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment this$0;

    ConnectDialogFragment$1(com.balboawatergroup.BalboaSpa.ConnectDialogFragment p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p5, int p6)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetDemoMode();
        try {
            ((com.balboawatergroup.BalboaSpa.BaseFragmentActivity) this.this$0.getActivity()).isConnectDialogCurrentlyBeingShown = Boolean.valueOf(0);
        } catch (Exception v1) {
            android.util.Log.e("Balboa", "exception accessing base fragment activity", v1);
        }
        return;
    }
}
