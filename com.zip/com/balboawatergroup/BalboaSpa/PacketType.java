package com.balboawatergroup.BalboaSpa;
public final enum class PacketType extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.PacketType[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType ConnectionEstablished;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType DeviceConfiguration;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType FilterCycleInfo;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType ModuleIdentification;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType PanelUpdate;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType SetupParameters;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType SystemInformation;
    public static final enum com.balboawatergroup.BalboaSpa.PacketType Unknown;
    public int id;

    static PacketType()
    {
        com.balboawatergroup.BalboaSpa.PacketType.PanelUpdate = new com.balboawatergroup.BalboaSpa.PacketType("PanelUpdate", 0, 1);
        com.balboawatergroup.BalboaSpa.PacketType.DeviceConfiguration = new com.balboawatergroup.BalboaSpa.PacketType("DeviceConfiguration", 1, 2);
        com.balboawatergroup.BalboaSpa.PacketType.SetupParameters = new com.balboawatergroup.BalboaSpa.PacketType("SetupParameters", 2, 3);
        com.balboawatergroup.BalboaSpa.PacketType.SystemInformation = new com.balboawatergroup.BalboaSpa.PacketType("SystemInformation", 3, 4);
        com.balboawatergroup.BalboaSpa.PacketType.Unknown = new com.balboawatergroup.BalboaSpa.PacketType("Unknown", 4, 5);
        com.balboawatergroup.BalboaSpa.PacketType.FilterCycleInfo = new com.balboawatergroup.BalboaSpa.PacketType("FilterCycleInfo", 5, 6);
        com.balboawatergroup.BalboaSpa.PacketType.ModuleIdentification = new com.balboawatergroup.BalboaSpa.PacketType("ModuleIdentification", 6, 7);
        com.balboawatergroup.BalboaSpa.PacketType.ConnectionEstablished = new com.balboawatergroup.BalboaSpa.PacketType("ConnectionEstablished", 7, 8);
        com.balboawatergroup.BalboaSpa.PacketType[] v0_15 = new com.balboawatergroup.BalboaSpa.PacketType[8];
        v0_15[0] = com.balboawatergroup.BalboaSpa.PacketType.PanelUpdate;
        v0_15[1] = com.balboawatergroup.BalboaSpa.PacketType.DeviceConfiguration;
        v0_15[2] = com.balboawatergroup.BalboaSpa.PacketType.SetupParameters;
        v0_15[3] = com.balboawatergroup.BalboaSpa.PacketType.SystemInformation;
        v0_15[4] = com.balboawatergroup.BalboaSpa.PacketType.Unknown;
        v0_15[5] = com.balboawatergroup.BalboaSpa.PacketType.FilterCycleInfo;
        v0_15[6] = com.balboawatergroup.BalboaSpa.PacketType.ModuleIdentification;
        v0_15[7] = com.balboawatergroup.BalboaSpa.PacketType.ConnectionEstablished;
        com.balboawatergroup.BalboaSpa.PacketType.$VALUES = v0_15;
        return;
    }

    private PacketType(String p1, int p2, int p3)
    {
        super(p1, p2);
        super.id = p3;
        return;
    }

    public static com.balboawatergroup.BalboaSpa.PacketType valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.PacketType) Enum.valueOf(com.balboawatergroup.BalboaSpa.PacketType, p1));
    }

    public static com.balboawatergroup.BalboaSpa.PacketType[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.PacketType[]) com.balboawatergroup.BalboaSpa.PacketType.$VALUES.clone());
    }
}
