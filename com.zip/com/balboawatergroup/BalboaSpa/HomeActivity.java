package com.balboawatergroup.BalboaSpa;
public class HomeActivity extends com.balboawatergroup.BalboaSpa.BaseFragmentActivity {
    com.balboawatergroup.BalboaSpa.ConnectDialogFragment connectDialogFragment;
    private int connectingMessageStep;
    com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment digiMessageDialogFragment;
    private boolean hasRequestedConfig;
    private boolean hasRequestedFilters;
    private boolean hasShownConnectedMessage;
    android.widget.ImageView imgCloud;
    private boolean isLockedOut;
    private android.content.BroadcastReceiver mDigiConnected;
    private android.content.BroadcastReceiver mDigiDisconnected;
    private android.content.BroadcastReceiver mDigiMessage;
    private android.content.BroadcastReceiver mMessageReceiver;
    private android.os.Handler reconnectCallback;
    android.graphics.drawable.AnimationDrawable spaAnimation;
    android.widget.ImageView spaImage;
    android.widget.TextView tvConnectionState;
    android.widget.TextView tvCurrentTemp;
    android.widget.TextView tvFilter;
    android.widget.TextView tvHeatMode;
    android.widget.TextView tvTempRange;
    private android.os.Handler uiCallback;

    public HomeActivity()
    {
        this.connectingMessageStep = 0;
        this.hasShownConnectedMessage = 0;
        this.hasRequestedConfig = 0;
        this.hasRequestedFilters = 0;
        this.uiCallback = new com.balboawatergroup.BalboaSpa.HomeActivity$3(this);
        this.reconnectCallback = new com.balboawatergroup.BalboaSpa.HomeActivity$4(this);
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.HomeActivity$7(this);
        this.mDigiConnected = new com.balboawatergroup.BalboaSpa.HomeActivity$8(this);
        this.mDigiDisconnected = new com.balboawatergroup.BalboaSpa.HomeActivity$9(this);
        this.mDigiMessage = new com.balboawatergroup.BalboaSpa.HomeActivity$10(this);
        return;
    }

    static synthetic android.os.Handler access$000(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        return p1.uiCallback;
    }

    static synthetic android.os.Handler access$100(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        return p1.reconnectCallback;
    }

    static synthetic boolean access$200(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        return p1.hasShownConnectedMessage;
    }

    static synthetic boolean access$202(com.balboawatergroup.BalboaSpa.HomeActivity p0, boolean p1)
    {
        p0.hasShownConnectedMessage = p1;
        return p1;
    }

    static synthetic int access$300(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        return p1.connectingMessageStep;
    }

    static synthetic int access$302(com.balboawatergroup.BalboaSpa.HomeActivity p0, int p1)
    {
        p0.connectingMessageStep = p1;
        return p1;
    }

    static synthetic int access$308(com.balboawatergroup.BalboaSpa.HomeActivity p2)
    {
        int v0 = p2.connectingMessageStep;
        p2.connectingMessageStep = (v0 + 1);
        return v0;
    }

    static synthetic void access$400(com.balboawatergroup.BalboaSpa.HomeActivity p0)
    {
        p0.showReconnectDialog();
        return;
    }

    static synthetic void access$500(com.balboawatergroup.BalboaSpa.HomeActivity p0)
    {
        p0.refreshTemperatureDisplay();
        return;
    }

    private void checkForCrashes()
    {
        net.hockeyapp.android.CrashManager.register(this, "55d2aaa818833a0002486fcdba27af55");
        return;
    }

    private void checkForUpdates()
    {
        net.hockeyapp.android.UpdateManager.register(this, "55d2aaa818833a0002486fcdba27af55");
        return;
    }

    private void refreshTemperatureDisplay()
    {
        if (com.balboawatergroup.BalboaSpa.SpaController.GetWifiSocketState() == com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
            if (this.hasRequestedConfig) {
                if (!this.hasRequestedFilters) {
                    com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles);
                    this.hasRequestedFilters = 1;
                }
            } else {
                com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration);
                new java.util.Timer().schedule(new com.balboawatergroup.BalboaSpa.HomeActivity$5(this, new android.os.Handler()), 1000);
                new java.util.Timer().schedule(new com.balboawatergroup.BalboaSpa.HomeActivity$6(this, new android.os.Handler()), 500);
                this.hasRequestedConfig = 1;
            }
        }
        String v5;
        com.balboawatergroup.BalboaSpa.SpaControlState v2 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        String v6 = "";
        if (v2.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit) {
            v5 = "C";
        } else {
            v5 = "F";
        }
        if ((v2.ActualTemperature != -1082130432) && (((double) v2.ActualTemperature) != -4620693217682128896)) {
            android.widget.TextView v7_47 = this.tvCurrentTemp;
            Object[] v9_2 = new Object[2];
            v9_2[0] = com.balboawatergroup.BalboaSpa.Utility.formatDouble(((double) v2.ActualTemperature));
            v9_2[1] = v5;
            v7_47.setText(String.format("%s\u00b0%s", v9_2));
        } else {
            this.tvCurrentTemp.setText("---");
        }
        if (v2.HeatMode != com.balboawatergroup.BalboaSpa.HeatMode.Ready) {
            if (v2.HeatMode != com.balboawatergroup.BalboaSpa.HeatMode.ReadyInRest) {
                if (v2.HeatMode != com.balboawatergroup.BalboaSpa.HeatMode.Rest) {
                    if (v2.HeatMode == com.balboawatergroup.BalboaSpa.HeatMode.None) {
                        this.tvHeatMode.setText("None");
                    }
                } else {
                    this.tvHeatMode.setText("Rest");
                }
            } else {
                this.tvHeatMode.setText("Ready In Rest");
            }
        } else {
            this.tvHeatMode.setText("Ready");
        }
        if (v2.TemperateRange != com.balboawatergroup.BalboaSpa.TemperatureRange.High) {
            if (v2.TemperateRange == com.balboawatergroup.BalboaSpa.TemperatureRange.Low) {
                this.tvTempRange.setText("Low Range");
            }
        } else {
            this.tvTempRange.setText("High Range");
        }
        if ((v2.WifiState == null) || (v2.WifiState == com.balboawatergroup.BalboaSpa.SpaWifiState.Ok)) {
            this.isLockedOut = 0;
        } else {
            this.isLockedOut = 1;
            switch (com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$SpaWifiState[v2.WifiState.ordinal()]) {
                case 1:
                    this.tvHeatMode.setText("Wifi malfunction");
                    break;
                case 2:
                    this.tvHeatMode.setText("Initializing, please wait");
                    break;
                case 3:
                    this.tvHeatMode.setText("Priming, please wait");
                    break;
                case 4:
                    this.tvHeatMode.setText("System Hold");
                    break;
                case 5:
                    this.tvHeatMode.setText("Panel is being used to make changes");
                    break;
                default:
                    if (v2.PumpStateStatus == com.balboawatergroup.BalboaSpa.PumpState.Low) {
                        this.spaImage.setBackgroundResource(2130837540);
                        this.spaAnimation = ((android.graphics.drawable.AnimationDrawable) this.spaImage.getBackground());
                        this.spaAnimation.start();
                        if (v2.FilterMode != null) {
                            switch (com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$FilterMode[v2.FilterMode.ordinal()]) {
                                case 1:
                                    this.tvFilter.setVisibility(8);
                                    break;
                                case 2:
                                    this.tvFilter.setVisibility(0);
                                    this.tvFilter.setText("Filter 1");
                                    break;
                                case 3:
                                    this.tvFilter.setVisibility(0);
                                    this.tvFilter.setText("Filter 1");
                                    break;
                                case 4:
                                    this.tvFilter.setVisibility(0);
                                    this.tvFilter.setText("Filter 2");
                                    break;
                            }
                        }
                        return;
                    } else {
                        if (v2.PumpStateStatus != com.balboawatergroup.BalboaSpa.PumpState.High) {
                            if ((v2.PumpStateStatus != com.balboawatergroup.BalboaSpa.PumpState.LowHeat) && (v2.PumpStateStatus != com.balboawatergroup.BalboaSpa.PumpState.HighHeat)) {
                                this.spaImage.setBackgroundResource(2130837561);
                            } else {
                                this.spaImage.setBackgroundResource(2130837559);
                                this.spaAnimation = ((android.graphics.drawable.AnimationDrawable) this.spaImage.getBackground());
                                this.spaAnimation.start();
                            }
                        } else {
                        }
                    }
            }
        }
        if ((v2.PumpStateStatus != com.balboawatergroup.BalboaSpa.PumpState.Low) && (v2.PumpStateStatus != com.balboawatergroup.BalboaSpa.PumpState.High)) {
        }
    }

    private void showReconnectDialog()
    {
        try {
            if (!((com.balboawatergroup.BalboaSpa.BalboaApplication) this.getApplication()).wasInBackground) {
                this.connectDialogFragment.goAway();
                this.connectDialogFragment = new com.balboawatergroup.BalboaSpa.ConnectDialogFragment();
                this.isConnectDialogCurrentlyBeingShown = Boolean.valueOf(1);
                this.connectDialogFragment.show(this.getSupportFragmentManager(), "ConnectDialogFragment");
            }
        } catch (Exception v0) {
            android.util.Log.e("Balboa", "Exception in reconnect dialog", v0);
        }
        return;
    }

    public void onCreate(android.os.Bundle p8)
    {
        super.onCreate(p8);
        this.setContentView(2130903046);
        this.connectingMessageStep = 0;
        this.spaImage = ((android.widget.ImageView) this.findViewById(2131230721));
        this.tvCurrentTemp = ((android.widget.TextView) this.findViewById(2131230788));
        this.tvHeatMode = ((android.widget.TextView) this.findViewById(2131230789));
        this.tvTempRange = ((android.widget.TextView) this.findViewById(2131230790));
        this.tvConnectionState = ((android.widget.TextView) this.findViewById(2131230791));
        this.tvFilter = ((android.widget.TextView) this.findViewById(2131230793));
        this.spaImage.setBackgroundResource(2130837540);
        this.spaAnimation = ((android.graphics.drawable.AnimationDrawable) this.spaImage.getBackground());
        this.imgCloud = ((android.widget.ImageView) this.findViewById(2131230792));
        this.isLockedOut = 0;
        if (com.balboawatergroup.BalboaSpa.Utility.GetBooleanSettingValue("showInstructions", Boolean.valueOf(1), this.getApplicationContext()).booleanValue()) {
            this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.InstructionsActivity));
        }
        com.balboawatergroup.BalboaSpa.SpaController.SetDemoMode();
        this.connectDialogFragment = new com.balboawatergroup.BalboaSpa.ConnectDialogFragment();
        this.isConnectDialogCurrentlyBeingShown = Boolean.valueOf(1);
        this.connectDialogFragment.show(this.getSupportFragmentManager(), "ConnectDialogFragment");
        this.refreshTemperatureDisplay();
        this.imgCloud.setVisibility(4);
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter("spa-state-updated"));
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mDigiConnected, new android.content.IntentFilter("digi-connected"));
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mDigiDisconnected, new android.content.IntentFilter("digi-disconnected"));
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mDigiMessage, new android.content.IntentFilter("digi-message"));
        new com.balboawatergroup.BalboaSpa.HomeActivity$1(this).start();
        new com.balboawatergroup.BalboaSpa.HomeActivity$2(this).start();
        return;
    }

    protected void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this).unregisterReceiver(this.mMessageReceiver);
        super.onDestroy();
        return;
    }

    public void onPause()
    {
        super.onPause();
        return;
    }

    public void onResume()
    {
        super.onResume();
        this.checkForCrashes();
        this.checkForUpdates();
        return;
    }

    protected void onStop()
    {
        super.onStop();
        return;
    }

    public void onWindowFocusChanged(boolean p2)
    {
        this.refreshTemperatureDisplay();
        try {
            this.spaAnimation = ((android.graphics.drawable.AnimationDrawable) this.spaImage.getBackground());
            this.spaAnimation.start();
        } catch (Exception v0) {
        }
        return;
    }

    public void showControls(android.view.View p3)
    {
        if ((!this.isLockedOut) && (com.balboawatergroup.BalboaSpa.SpaController.HasCurrentDeviceConfig())) {
            com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration);
            this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.ControlsActivity));
        }
        return;
    }

    public void showInfo(android.view.View p3)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SendDevicePresentQuery();
        this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.DisplayMessageActivity));
        return;
    }

    public void showSettings(android.view.View p3)
    {
        if (!this.isLockedOut) {
            com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles);
            this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.SettingsActivity));
        }
        return;
    }
}
