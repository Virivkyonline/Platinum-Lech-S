package com.balboawatergroup.BalboaSpa;
public class ControlsActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    private android.widget.ImageButton ibAux1;
    private android.widget.ImageButton ibAux2;
    private android.widget.ImageButton ibBlower;
    private android.widget.ImageButton ibCircPump;
    private android.widget.ImageButton ibLight1;
    private android.widget.ImageButton ibLight2;
    private android.widget.ImageButton ibMister;
    private android.widget.ImageButton ibPump1;
    private android.widget.ImageButton ibPump2;
    private android.widget.ImageButton ibPump3;
    private android.widget.ImageButton ibPump4;
    private android.widget.ImageButton ibPump5;
    private android.content.BroadcastReceiver mMessageReceiver;
    private int panelUpdatesToIgnore;
    private android.widget.RelativeLayout rlAux1;
    private android.widget.RelativeLayout rlAux2;
    private android.widget.RelativeLayout rlBlower;
    private android.widget.RelativeLayout rlCircPump;
    private android.widget.RelativeLayout rlLight1;
    private android.widget.RelativeLayout rlLight2;
    private android.widget.RelativeLayout rlMister;
    private android.widget.RelativeLayout rlPump1;
    private android.widget.RelativeLayout rlPump2;
    private android.widget.RelativeLayout rlPump3;
    private android.widget.RelativeLayout rlPump4;
    private android.widget.RelativeLayout rlPump5;
    private android.graphics.drawable.AnimationDrawable spaAnimation;
    private android.widget.TextView tvAux1;
    private android.widget.TextView tvAux2;
    private android.widget.TextView tvBlower;
    private android.widget.TextView tvCircPump;
    private android.widget.TextView tvLight1;
    private android.widget.TextView tvLight2;
    private android.widget.TextView tvMister;
    private android.widget.TextView tvPump1;
    private android.widget.TextView tvPump2;
    private android.widget.TextView tvPump3;
    private android.widget.TextView tvPump4;
    private android.widget.TextView tvPump5;

    public ControlsActivity()
    {
        this.mMessageReceiver = new com.balboawatergroup.BalboaSpa.ControlsActivity$1(this);
        return;
    }

    private void SetAuxImage(android.widget.ImageButton p2, boolean p3)
    {
        try {
            p2.clearAnimation();
        } catch (int v0) {
        }
        if (!p3) {
            p2.setImageResource(2130837508);
        } else {
            p2.setImageResource(2130837509);
        }
        return;
    }

    private void SetBlowerImage(android.widget.ImageButton p3, com.balboawatergroup.BalboaSpa.BlowerState p4)
    {
        try {
            p3.clearAnimation();
        } catch (int v0) {
        }
        if (p4 != null) {
            switch (com.balboawatergroup.BalboaSpa.ControlsActivity$2.$SwitchMap$com$balboawatergroup$BalboaSpa$BlowerState[p4.ordinal()]) {
                case 1:
                    p3.setImageResource(2130837513);
                    break;
                case 2:
                    p3.setImageResource(2130837511);
                    break;
                case 3:
                    p3.setImageResource(2130837512);
                    break;
                case 4:
                    p3.setImageResource(2130837510);
                    break;
            }
        }
        return;
    }

    private void SetCircPumpImage(android.widget.ImageButton p3, com.balboawatergroup.BalboaSpa.PumpState p4)
    {
        try {
            p3.clearAnimation();
        } catch (int v0) {
        }
        if (p4 != null) {
            switch (com.balboawatergroup.BalboaSpa.ControlsActivity$2.$SwitchMap$com$balboawatergroup$BalboaSpa$PumpState[p4.ordinal()]) {
                case 1:
                    p3.setImageResource(2130837557);
                    break;
                case 2:
                    p3.setImageResource(2130837560);
                    break;
                default:
                    p3.setImageResource(2130837558);
            }
            this.startCircAnimation();
        }
        return;
    }

    private void SetEnabledOnAllButtons(boolean p2)
    {
        this.ibPump1.setEnabled(p2);
        this.ibPump2.setEnabled(p2);
        this.ibPump3.setEnabled(p2);
        this.ibPump4.setEnabled(p2);
        this.ibPump5.setEnabled(p2);
        this.ibBlower.setEnabled(p2);
        this.ibLight1.setEnabled(p2);
        this.ibLight2.setEnabled(p2);
        this.ibMister.setEnabled(p2);
        this.ibAux1.setEnabled(p2);
        this.ibAux2.setEnabled(p2);
        return;
    }

    private void SetLightImage(android.widget.ImageButton p2, boolean p3)
    {
        try {
            p2.clearAnimation();
        } catch (int v0) {
        }
        if (!p3) {
            p2.setImageResource(2130837516);
        } else {
            p2.setImageResource(2130837517);
        }
        return;
    }

    private void SetMisterImage(android.widget.ImageButton p2, boolean p3)
    {
        try {
            p2.clearAnimation();
        } catch (int v0) {
        }
        if (!p3) {
            p2.setImageResource(2130837518);
        } else {
            p2.setImageResource(2130837519);
        }
        return;
    }

    private void SetPumpImage(android.widget.ImageButton p3, com.balboawatergroup.BalboaSpa.PumpState p4)
    {
        try {
            p3.clearAnimation();
        } catch (int v0) {
        }
        if (p4 != null) {
            switch (com.balboawatergroup.BalboaSpa.ControlsActivity$2.$SwitchMap$com$balboawatergroup$BalboaSpa$PumpState[p4.ordinal()]) {
                case 1:
                    p3.setImageResource(2130837522);
                    break;
                case 2:
                    p3.setImageResource(2130837523);
                    break;
                case 3:
                    p3.setImageResource(2130837524);
                    break;
                case 4:
                    p3.setImageResource(2130837520);
                    break;
                case 5:
                    p3.setImageResource(2130837521);
                    break;
            }
        }
        return;
    }

    static synthetic int access$000(com.balboawatergroup.BalboaSpa.ControlsActivity p1)
    {
        return p1.panelUpdatesToIgnore;
    }

    static synthetic int access$010(com.balboawatergroup.BalboaSpa.ControlsActivity p2)
    {
        int v0 = p2.panelUpdatesToIgnore;
        p2.panelUpdatesToIgnore = (v0 - 1);
        return v0;
    }

    private void getControls()
    {
        this.ibPump1 = ((android.widget.ImageButton) this.findViewById(2131230740));
        this.ibPump2 = ((android.widget.ImageButton) this.findViewById(2131230743));
        this.ibPump3 = ((android.widget.ImageButton) this.findViewById(2131230746));
        this.ibPump4 = ((android.widget.ImageButton) this.findViewById(2131230749));
        this.ibPump5 = ((android.widget.ImageButton) this.findViewById(2131230752));
        this.ibCircPump = ((android.widget.ImageButton) this.findViewById(2131230736));
        this.ibBlower = ((android.widget.ImageButton) this.findViewById(2131230754));
        this.ibLight1 = ((android.widget.ImageButton) this.findViewById(2131230757));
        this.ibLight2 = ((android.widget.ImageButton) this.findViewById(2131230767));
        this.ibMister = ((android.widget.ImageButton) this.findViewById(2131230765));
        this.ibAux1 = ((android.widget.ImageButton) this.findViewById(2131230761));
        this.ibAux2 = ((android.widget.ImageButton) this.findViewById(2131230760));
        this.tvCircPump = ((android.widget.TextView) this.findViewById(2131230737));
        this.tvPump1 = ((android.widget.TextView) this.findViewById(2131230739));
        this.tvPump2 = ((android.widget.TextView) this.findViewById(2131230742));
        this.tvPump3 = ((android.widget.TextView) this.findViewById(2131230745));
        this.tvPump4 = ((android.widget.TextView) this.findViewById(2131230748));
        this.tvPump5 = ((android.widget.TextView) this.findViewById(2131230751));
        this.tvBlower = ((android.widget.TextView) this.findViewById(2131230755));
        this.tvLight1 = ((android.widget.TextView) this.findViewById(2131230758));
        this.tvLight2 = ((android.widget.TextView) this.findViewById(2131230770));
        this.tvAux1 = ((android.widget.TextView) this.findViewById(2131230764));
        this.tvAux2 = ((android.widget.TextView) this.findViewById(2131230762));
        this.tvMister = ((android.widget.TextView) this.findViewById(2131230768));
        this.rlPump1 = ((android.widget.RelativeLayout) this.findViewById(2131230738));
        this.rlPump2 = ((android.widget.RelativeLayout) this.findViewById(2131230741));
        this.rlPump3 = ((android.widget.RelativeLayout) this.findViewById(2131230744));
        this.rlPump4 = ((android.widget.RelativeLayout) this.findViewById(2131230747));
        this.rlPump5 = ((android.widget.RelativeLayout) this.findViewById(2131230750));
        this.rlCircPump = ((android.widget.RelativeLayout) this.findViewById(2131230735));
        this.rlBlower = ((android.widget.RelativeLayout) this.findViewById(2131230753));
        this.rlLight1 = ((android.widget.RelativeLayout) this.findViewById(2131230756));
        this.rlLight2 = ((android.widget.RelativeLayout) this.findViewById(2131230769));
        this.rlMister = ((android.widget.RelativeLayout) this.findViewById(2131230766));
        this.rlAux1 = ((android.widget.RelativeLayout) this.findViewById(2131230763));
        this.rlAux2 = ((android.widget.RelativeLayout) this.findViewById(2131230759));
        return;
    }

    private void startCircAnimation()
    {
        try {
            this.spaAnimation = ((android.graphics.drawable.AnimationDrawable) this.ibCircPump.getDrawable());
            this.spaAnimation.start();
        } catch (Exception v0) {
        }
        return;
    }

    public void buttonClicked(android.view.View p4)
    {
        ((android.widget.ImageButton) p4).setImageResource(2130837564);
        ((android.widget.ImageButton) p4).startAnimation(android.view.animation.AnimationUtils.loadAnimation(this, 2130837565));
        this.panelUpdatesToIgnore = 2;
        switch (p4.getId()) {
            case 2131230740:
                com.balboawatergroup.BalboaSpa.SpaController.Pump1ControlPushed();
                break;
            case 2131230743:
                com.balboawatergroup.BalboaSpa.SpaController.Pump2ControlPushed();
                break;
            case 2131230746:
                com.balboawatergroup.BalboaSpa.SpaController.Pump3ControlPushed();
                break;
            case 2131230749:
                com.balboawatergroup.BalboaSpa.SpaController.Pump4ControlPushed();
                break;
            case 2131230752:
                com.balboawatergroup.BalboaSpa.SpaController.Pump5ControlPushed();
                break;
            case 2131230754:
                com.balboawatergroup.BalboaSpa.SpaController.BlowerControlPushed();
                break;
            case 2131230757:
                com.balboawatergroup.BalboaSpa.SpaController.Light1ControlPushed();
                break;
            case 2131230760:
                com.balboawatergroup.BalboaSpa.SpaController.Aux2ControlPushed();
                break;
            case 2131230761:
                com.balboawatergroup.BalboaSpa.SpaController.Aux1ControlPushed();
                break;
            case 2131230765:
                com.balboawatergroup.BalboaSpa.SpaController.MisterControlPushed();
                break;
            case 2131230767:
                com.balboawatergroup.BalboaSpa.SpaController.Light2ControlPushed();
                break;
        }
        if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode == "Demo") {
            this.refreshControlIcons();
        }
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        this.panelUpdatesToIgnore = 0;
        super.onCreate(p5);
        this.setContentView(2130903042);
        this.getControls();
        this.refreshControlIcons();
        com.balboawatergroup.BalboaSpa.SpaController.SendDevicePresentQuery();
        android.support.v4.content.LocalBroadcastManager.getInstance(this).registerReceiver(this.mMessageReceiver, new android.content.IntentFilter("spa-state-updated"));
        return;
    }

    protected void onDestroy()
    {
        android.support.v4.content.LocalBroadcastManager.getInstance(this).unregisterReceiver(this.mMessageReceiver);
        super.onDestroy();
        return;
    }

    public void onWindowFocusChanged(boolean p1)
    {
        this.startCircAnimation();
        return;
    }

    public void refreshControlIcons()
    {
        Boolean v3 = Boolean.valueOf(0);
        com.balboawatergroup.BalboaSpa.SpaSystemInformation v1 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaSystemInformation();
        if (v1 != null) {
            v3 = Boolean.valueOf(v1.isOldVersion);
        }
        com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration v0;
        if (!v3.booleanValue()) {
            v0 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaDeviceConfiguration();
        } else {
            v0 = com.balboawatergroup.BalboaSpa.SpaController.GetOldVersionConfiguration();
        }
        if (v0 != null) {
            if (!v0.HasLight2) {
                this.rlLight2.setVisibility(8);
            }
            if (!v0.HasAux1) {
                this.rlAux1.setVisibility(8);
            }
            if (!v0.HasAux2) {
                this.rlAux2.setVisibility(8);
            }
            if (!v0.HasBlower) {
                this.rlBlower.setVisibility(8);
            }
            if (!v0.HasMister) {
                this.rlMister.setVisibility(8);
            }
            if (!v0.HasLight1) {
                this.rlLight1.setVisibility(8);
            }
            if (!v0.HasPump1) {
                this.rlPump1.setVisibility(8);
            }
            if (!v0.HasPump0) {
                this.rlCircPump.setVisibility(8);
            }
            if (!v0.HasPump2) {
                this.rlPump2.setVisibility(8);
            }
            if (!v0.HasPump3) {
                this.rlPump3.setVisibility(8);
            }
            if (!v0.HasPump4) {
                this.rlPump4.setVisibility(8);
            }
            if (!v0.HasPump5) {
                this.rlPump5.setVisibility(8);
            }
        }
        com.balboawatergroup.BalboaSpa.SpaControlState v2 = com.balboawatergroup.BalboaSpa.SpaController.GetSpaControlState();
        if (v2 != null) {
            this.SetPumpImage(this.ibPump1, v2.Pump1State);
            this.SetPumpImage(this.ibPump2, v2.Pump2State);
            if ((v2.Pump2State != null) && (v2.Pump2State == com.balboawatergroup.BalboaSpa.PumpState.Off)) {
                android.util.Log.i("Balboa", "pump2 off");
            }
            this.SetPumpImage(this.ibPump3, v2.Pump3State);
            this.SetPumpImage(this.ibPump4, v2.Pump4State);
            this.SetPumpImage(this.ibPump5, v2.Pump5State);
            this.SetCircPumpImage(this.ibCircPump, v2.PumpStateStatus);
            this.SetBlowerImage(this.ibBlower, v2.BlowerState);
            this.SetLightImage(this.ibLight1, v2.Light1On);
            this.SetLightImage(this.ibLight2, v2.Light2On);
            this.SetMisterImage(this.ibMister, v2.MisterOn);
            this.SetAuxImage(this.ibAux1, v2.Aux1On);
            this.SetAuxImage(this.ibAux2, v2.Aux2On);
            if (v2.AccessibilityType != null) {
                if (v2.AccessibilityType != com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL) {
                    if (v2.AccessibilityType == com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE) {
                        this.SetEnabledOnAllButtons(0);
                    }
                } else {
                    this.SetEnabledOnAllButtons(1);
                }
            }
        }
        return;
    }
}
