package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$8 extends android.app.TimePickerDialog {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$8(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p7, android.content.Context p8, android.app.TimePickerDialog$OnTimeSetListener p9, int p10, int p11, boolean p12)
    {
        this.this$0 = p7;
        super(p8, p9, p10, p11, p12);
        return;
    }

    public void onTimeChanged(android.widget.TimePicker p2, int p3, int p4)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$300(this.this$0, p2, p3, p4);
        return;
    }
}
