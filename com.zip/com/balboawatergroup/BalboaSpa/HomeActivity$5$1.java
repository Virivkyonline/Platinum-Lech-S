package com.balboawatergroup.BalboaSpa;
 class HomeActivity$5$1 implements java.lang.Runnable {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity$5 this$1;

    HomeActivity$5$1(com.balboawatergroup.BalboaSpa.HomeActivity$5 p1)
    {
        this.this$1 = p1;
        return;
    }

    public void run()
    {
        com.balboawatergroup.BalboaSpa.SpaController.SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration);
        return;
    }
}
