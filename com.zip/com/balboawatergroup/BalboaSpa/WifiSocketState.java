package com.balboawatergroup.BalboaSpa;
public final enum class WifiSocketState extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.WifiSocketState[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.WifiSocketState Connected;
    public static final enum com.balboawatergroup.BalboaSpa.WifiSocketState Connecting;
    public static final enum com.balboawatergroup.BalboaSpa.WifiSocketState NotApplicable;
    public static final enum com.balboawatergroup.BalboaSpa.WifiSocketState NotConnected;

    static WifiSocketState()
    {
        com.balboawatergroup.BalboaSpa.WifiSocketState.Connected = new com.balboawatergroup.BalboaSpa.WifiSocketState("Connected", 0);
        com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected = new com.balboawatergroup.BalboaSpa.WifiSocketState("NotConnected", 1);
        com.balboawatergroup.BalboaSpa.WifiSocketState.NotApplicable = new com.balboawatergroup.BalboaSpa.WifiSocketState("NotApplicable", 2);
        com.balboawatergroup.BalboaSpa.WifiSocketState.Connecting = new com.balboawatergroup.BalboaSpa.WifiSocketState("Connecting", 3);
        com.balboawatergroup.BalboaSpa.WifiSocketState[] v0_6 = new com.balboawatergroup.BalboaSpa.WifiSocketState[4];
        v0_6[0] = com.balboawatergroup.BalboaSpa.WifiSocketState.Connected;
        v0_6[1] = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
        v0_6[2] = com.balboawatergroup.BalboaSpa.WifiSocketState.NotApplicable;
        v0_6[3] = com.balboawatergroup.BalboaSpa.WifiSocketState.Connecting;
        com.balboawatergroup.BalboaSpa.WifiSocketState.$VALUES = v0_6;
        return;
    }

    private WifiSocketState(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.WifiSocketState valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.WifiSocketState) Enum.valueOf(com.balboawatergroup.BalboaSpa.WifiSocketState, p1));
    }

    public static com.balboawatergroup.BalboaSpa.WifiSocketState[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.WifiSocketState[]) com.balboawatergroup.BalboaSpa.WifiSocketState.$VALUES.clone());
    }
}
