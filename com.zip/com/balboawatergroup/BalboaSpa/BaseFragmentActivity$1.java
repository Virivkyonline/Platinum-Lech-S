package com.balboawatergroup.BalboaSpa;
 class BaseFragmentActivity$1 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.BaseFragmentActivity this$0;

    BaseFragmentActivity$1(com.balboawatergroup.BalboaSpa.BaseFragmentActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p2, android.content.Intent p3)
    {
        if (this.this$0.progress != null) {
            this.this$0.progress.dismiss();
        }
        return;
    }
}
