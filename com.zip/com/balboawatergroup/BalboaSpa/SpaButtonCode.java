package com.balboawatergroup.BalboaSpa;
public final enum class SpaButtonCode extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.SpaButtonCode[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Aux1;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Aux2;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Blower;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode HeatMode;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Light1;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Light2;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Mister;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump1;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump2;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump3;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump4;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump5;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode Pump6;
    public static final enum com.balboawatergroup.BalboaSpa.SpaButtonCode TempRange;
    public int code;

    static SpaButtonCode()
    {
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump1 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump1", 0, 4);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump2 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump2", 1, 5);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump3 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump3", 2, 6);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump4 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump4", 3, 7);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump5 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump5", 4, 8);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump6 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Pump6", 5, 9);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Light1 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Light1", 6, 17);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Light2 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Light2", 7, 18);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Mister = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Mister", 8, 14);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux1 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Aux1", 9, 22);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux2 = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Aux2", 10, 23);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.Blower = new com.balboawatergroup.BalboaSpa.SpaButtonCode("Blower", 11, 12);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.TempRange = new com.balboawatergroup.BalboaSpa.SpaButtonCode("TempRange", 12, 80);
        com.balboawatergroup.BalboaSpa.SpaButtonCode.HeatMode = new com.balboawatergroup.BalboaSpa.SpaButtonCode("HeatMode", 13, 81);
        com.balboawatergroup.BalboaSpa.SpaButtonCode[] v0_29 = new com.balboawatergroup.BalboaSpa.SpaButtonCode[14];
        v0_29[0] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump1;
        v0_29[1] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump2;
        v0_29[2] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump3;
        v0_29[3] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump4;
        v0_29[4] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump5;
        v0_29[5] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Pump6;
        v0_29[6] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Light1;
        v0_29[7] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Light2;
        v0_29[8] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Mister;
        v0_29[9] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux1;
        v0_29[10] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Aux2;
        v0_29[11] = com.balboawatergroup.BalboaSpa.SpaButtonCode.Blower;
        v0_29[12] = com.balboawatergroup.BalboaSpa.SpaButtonCode.TempRange;
        v0_29[13] = com.balboawatergroup.BalboaSpa.SpaButtonCode.HeatMode;
        com.balboawatergroup.BalboaSpa.SpaButtonCode.$VALUES = v0_29;
        return;
    }

    private SpaButtonCode(String p1, int p2, int p3)
    {
        super(p1, p2);
        super.code = p3;
        return;
    }

    public static com.balboawatergroup.BalboaSpa.SpaButtonCode valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.SpaButtonCode) Enum.valueOf(com.balboawatergroup.BalboaSpa.SpaButtonCode, p1));
    }

    public static com.balboawatergroup.BalboaSpa.SpaButtonCode[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.SpaButtonCode[]) com.balboawatergroup.BalboaSpa.SpaButtonCode.$VALUES.clone());
    }
}
