package com.balboawatergroup.BalboaSpa;
public interface ISpaCommunicator {

    public abstract void Aux1ControlPushed();

    public abstract void Aux2ControlPushed();

    public abstract void BlowerControlPushed();

    public abstract void ConnectToWifi();

    public abstract com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetCurrentConfiguration();

    public abstract com.balboawatergroup.BalboaSpa.SpaControlState GetCurrentState();

    public abstract com.balboawatergroup.BalboaSpa.SpaSystemInformation GetCurrentSystemInformation();

    public abstract com.balboawatergroup.BalboaSpa.FilterCycle GetFilterCycle();

    public abstract com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState();

    public abstract boolean HasCurrentDeviceConfig();

    public abstract void HeatModePushed();

    public abstract void Light1ControlPushed();

    public abstract void Light2ControlPushed();

    public abstract void MisterControlPushed();

    public abstract void Pump1ControlPushed();

    public abstract void Pump2ControlPushed();

    public abstract void Pump3ControlPushed();

    public abstract void Pump4ControlPushed();

    public abstract void Pump5ControlPushed();

    public abstract void SaveFilterCycle();

    public abstract void SendDevicePresentQuery();

    public abstract void SendPanelRequest();

    public abstract void Set24HourTime();

    public abstract void SetTargetTemperature();

    public abstract void SetTemperatureScale();

    public abstract void SetTime();

    public abstract void StartThread();

    public abstract void StopThread();

    public abstract void TempRangePushed();
}
