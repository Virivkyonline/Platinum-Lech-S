package com.balboawatergroup.BalboaSpa;
public class SocketListenerThread extends java.lang.Thread {
    private static final String PREFS_NAME = "MyPrefsFile";
    private int DISCOVERY_PORT;
    private String HOST_IP;
    private String HOST_IP_ADHOC;
    private String HOST_IP_SOFT_AP;
    private String HOST_NAME;
    private int MAIN_PORT;
    public java.net.Socket clientSocket;
    private final android.content.Context context;
    public com.balboawatergroup.BalboaSpa.WifiSocketState currentState;
    private boolean foundAddress;
    android.os.Handler handler;
    public Boolean hasConnectionBeenEstablished;
    public java.io.DataInputStream inToServer;
    private byte[] inputBuffer;
    public Boolean isInitialized;
    private boolean isOutputPending;
    private javax.jmdns.JmDNS jmdns;
    private javax.jmdns.ServiceListener listener;
    android.net.wifi.WifiManager$MulticastLock lock;
    private android.os.Handler myThreadHandler;
    public java.io.DataOutputStream outToServer;
    private byte[] outputBuffer;
    private int outputCommandLength;
    private android.os.Handler parentHandler;
    private javax.jmdns.ServiceInfo serviceInfo;
    private String serviceName;
    public volatile boolean stopped;
    private String type;

    public SocketListenerThread(android.os.Handler p4, android.content.Context p5)
    {
        this.isInitialized = Boolean.valueOf(0);
        this.hasConnectionBeenEstablished = Boolean.valueOf(0);
        this.HOST_IP = "169.254.1.1";
        this.HOST_IP_ADHOC = "169.254.1.1";
        this.HOST_IP_SOFT_AP = "192.168.1.3";
        this.MAIN_PORT = 4257;
        this.DISCOVERY_PORT = 30303;
        this.HOST_NAME = "BWGSpa.local";
        this.outputCommandLength = 0;
        this.myThreadHandler = new com.balboawatergroup.BalboaSpa.SocketListenerThread$1(this);
        this.handler = new android.os.Handler();
        this.type = "_http._tcp.local.";
        this.serviceName = "DemoWebServer";
        this.jmdns = 0;
        this.listener = 0;
        this.parentHandler = p4;
        this.context = p5;
        this.currentState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
        return;
    }

    private void ConnectSocket(String p6)
    {
        if (!this.stopped) {
            try {
                int v3_3 = new Object[1];
                v3_3[0] = p6;
                android.util.Log.i("Balboa", String.format("Connecting socket on IP Address %s", v3_3));
                this.closeSocket();
                this.clientSocket = new java.net.Socket();
                this.clientSocket.connect(new java.net.InetSocketAddress(p6, this.MAIN_PORT), 5000);
                try {
                    if (this.clientSocket != null) {
                        if (!this.clientSocket.isConnected()) {
                            android.util.Log.i("Balboa", "Cannot assign Streams, Socket is closed");
                        } else {
                            this.outToServer = new java.io.DataOutputStream(this.clientSocket.getOutputStream());
                            this.inToServer = new java.io.DataInputStream(this.clientSocket.getInputStream());
                            this.currentState = com.balboawatergroup.BalboaSpa.WifiSocketState.Connected;
                            this.isInitialized = Boolean.valueOf(1);
                            android.util.Log.i("Balboa", "Socket created, Streams assigned");
                        }
                    }
                } catch (java.io.IOException v0_1) {
                    android.util.Log.i("Balboa", "Cannot assign Streams, Socket not connected");
                    v0_1.printStackTrace();
                }
            } catch (java.io.IOException v0_0) {
                android.util.Log.e("Balboa", "Cannot create Socket", v0_0);
            } catch (String v1_6) {
                throw v1_6;
            }
        }
        return;
    }

    private void LookupIPByDNS()
    {
        this.foundAddress = 0;
        try {
            this.setUp();
            String v2 = "";
        } catch (Exception v1) {
            android.util.Log.e("Balboa", "Exception looking up IP from name", v1);
            android.util.Log.i("Balboa", "Cannot lookup host from name");
            return;
        }
        if (this.foundAddress) {
            return;
        } else {
            java.net.InetAddress[] v0 = java.net.InetAddress.getAllByName(this.HOST_NAME);
            if (v0.length > 0) {
                v2 = v0[0].getHostAddress();
            }
            if ((v2 == null) || ((v2 == "") || (v2.startsWith("0.")))) {
                return;
            } else {
                this.foundAddress = 1;
                this.HOST_IP = v2;
                return;
            }
        }
    }

    private void LookupIPByNETBIOS()
    {
        try {
            String v2 = jcifs.netbios.NbtAddress.getByName(this.HOST_NAME).getInetAddress().getHostAddress();
        } catch (Exception v1) {
            android.util.Log.e("Balboa", "Exception looking up IP from NbtAddress", v1);
            android.util.Log.i("Balboa", "Cannot lookup host from name");
            return;
        }
        if ((v2 == "") || ((v2 == null) || (v2.startsWith("0.")))) {
            return;
        } else {
            this.HOST_IP = v2;
            return;
        }
    }

    private void LookupIPByUDPBroadcast()
    {
        try {
            android.util.Log.i("Balboa", "Looking up IP from UDP broadcast");
            android.net.wifi.WifiManager$MulticastLock v3 = ((android.net.wifi.WifiManager) this.context.getSystemService("wifi")).createMulticastLock("dk.aboaya.pingpong");
            v3.acquire();
            java.net.DatagramSocket v6_1 = new java.net.DatagramSocket(0);
            v6_1.setReuseAddress(1);
            v6_1.setBroadcast(1);
            v6_1.bind(new java.net.InetSocketAddress(5353));
            v6_1.setSoTimeout(5000);
            v6_1.send(new java.net.DatagramPacket("Discovery: Who is out there?".getBytes(), "Discovery: Who is out there?".length(), this.getBroadcastAddress(), this.DISCOVERY_PORT));
            byte[] v0 = new byte[1024];
            java.net.DatagramPacket v5_1 = new java.net.DatagramPacket(v0, v0.length);
            v6_1.receive(v5_1);
            v3.release();
            v6_1.close();
            this.HOST_IP = v5_1.getAddress().getHostAddress();
            this.foundAddress = 1;
            this.storeIP(this.HOST_IP);
            Object[] v10_2 = new Object[1];
            v10_2[0] = this.HOST_IP;
            android.util.Log.i("Balboa", String.format("Found IP Address from UDP Broadcast: %s", v10_2));
        } catch (Exception v2) {
            android.util.Log.e("Balboa", "Exception looking up IP from UDP Broadcast", v2);
            android.util.Log.i("Balboa", "Cannot lookup host from name");
        }
        return;
    }

    private void SendNetworkPacket(byte[] p5)
    {
        if (!this.isInitialized.booleanValue()) {
            this.initializeSocket();
        }
        try {
            this.outToServer.write(p5, 0, this.outputCommandLength);
            this.outToServer.flush();
        } catch (java.io.IOException v0) {
            android.util.Log.i("Balboa", "Cannot send data");
        }
        return;
    }

    static synthetic byte[] access$002(com.balboawatergroup.BalboaSpa.SocketListenerThread p0, byte[] p1)
    {
        p0.outputBuffer = p1;
        return p1;
    }

    static synthetic int access$102(com.balboawatergroup.BalboaSpa.SocketListenerThread p0, int p1)
    {
        p0.outputCommandLength = p1;
        return p1;
    }

    static synthetic boolean access$202(com.balboawatergroup.BalboaSpa.SocketListenerThread p0, boolean p1)
    {
        p0.isOutputPending = p1;
        return p1;
    }

    static synthetic String access$300(com.balboawatergroup.BalboaSpa.SocketListenerThread p1)
    {
        return p1.serviceName;
    }

    static synthetic String access$402(com.balboawatergroup.BalboaSpa.SocketListenerThread p0, String p1)
    {
        p0.HOST_IP = p1;
        return p1;
    }

    static synthetic boolean access$502(com.balboawatergroup.BalboaSpa.SocketListenerThread p0, boolean p1)
    {
        p0.foundAddress = p1;
        return p1;
    }

    static synthetic javax.jmdns.JmDNS access$600(com.balboawatergroup.BalboaSpa.SocketListenerThread p1)
    {
        return p1.jmdns;
    }

    private boolean checkAddress(byte[] p5)
    {
        int v1 = 0;
        if (p5.length >= 4) {
            byte v0 = p5[2];
            if ((v0 == 10) || (v0 == -1)) {
                v1 = 1;
            }
        }
        return v1;
    }

    private boolean checkChecksum(byte[] p5)
    {
        int v1 = 1;
        if (com.balboawatergroup.BalboaSpa.Utility.CalculateChecksum(p5, (p5.length - 2), 1, 0) != -13) {
            v1 = 0;
        }
        return v1;
    }

    private boolean checkForIncomingData()
    {
        int v1 = 0;
        try {
            if (this.inToServer.read(this.inputBuffer) <= 0) {
                int v4_1 = 0;
                while (v4_1 < this.inputBuffer.length) {
                    this.inputBuffer[v4_1] = 0;
                    v4_1++;
                }
            } else {
                v1 = 1;
                if (!this.hasConnectionBeenEstablished.booleanValue()) {
                    this.hasConnectionBeenEstablished = Boolean.valueOf(1);
                    this.sendMessageToParent(com.balboawatergroup.BalboaSpa.PacketType.ConnectionEstablished, 0, 0);
                }
                int v3 = -1;
                int v5 = -1;
                int v4_0 = 0;
                while (v4_0 < this.inputBuffer.length) {
                    byte v0 = this.inputBuffer[v4_0];
                    if ((v3 != -1) || (v0 != 126)) {
                        if ((v5 == -1) && (v0 == 126)) {
                            v5 = v4_0;
                            int v6 = ((v5 - v3) + 1);
                            byte[] v9 = new byte[v6];
                            System.arraycopy(this.inputBuffer, v3, v9, 0, v6);
                            if ((this.checkHeaderAndFooter(v9)) && ((this.checkAddress(v9)) && ((this.checkPF(v9)) && (this.checkChecksum(v9))))) {
                                com.balboawatergroup.BalboaSpa.PacketType v7 = this.getPacketType(v9);
                                switch (com.balboawatergroup.BalboaSpa.SocketListenerThread$3.$SwitchMap$com$balboawatergroup$BalboaSpa$PacketType[v7.ordinal()]) {
                                    case 1:
                                        this.sendMessageToParent(v7, com.balboawatergroup.BalboaSpa.PacketParser.ParsePanelUpdate(v9), 0);
                                        break;
                                    case 2:
                                        this.sendMessageToParent(v7, com.balboawatergroup.BalboaSpa.PacketParser.ParseDeviceConfiguration(v9), 0);
                                    case 3:
                                        break;
                                    case 4:
                                        this.sendMessageToParent(v7, com.balboawatergroup.BalboaSpa.PacketParser.ParseSystemInformation(v9), 0);
                                        break;
                                    case 5:
                                        this.sendMessageToParent(v7, com.balboawatergroup.BalboaSpa.PacketParser.ParseFilterCycle(v9), 0);
                                        break;
                                    case 6:
                                        this.sendMessageToParent(v7, com.balboawatergroup.BalboaSpa.PacketParser.ParseModuleIdentication(v9), 0);
                                        break;
                                    default:
                                }
                            }
                        }
                    } else {
                        v3 = v4_0;
                    }
                    v4_0++;
                }
            }
        } catch (java.io.IOException v2) {
            android.util.Log.i("Balboa", "Error reading data");
        }
        return v1;
    }

    private void checkForOutgoingData()
    {
        if (this.isOutputPending) {
            this.SendNetworkPacket(this.outputBuffer);
            this.isOutputPending = 0;
        }
        return;
    }

    private boolean checkHeaderAndFooter(byte[] p6)
    {
        int v2 = 0;
        if ((p6 != null) && ((p6.length != 0) && ((p6[0] == 126) && (p6[(p6.length - 1)] == 126)))) {
            v2 = 1;
        }
        return v2;
    }

    private boolean checkPF(byte[] p3)
    {
        int v1_3;
        byte v0 = p3[3];
        if ((v0 == -81) || (v0 == -65)) {
            v1_3 = 1;
        } else {
            v1_3 = 0;
        }
        return v1_3;
    }

    private void closeSocket()
    {
        try {
            android.util.Log.i("Balboa", "Closing Socket");
        } catch (java.io.IOException v0) {
            android.util.Log.e("Balboa", new StringBuilder().append("Error closing socket - ").append(v0).toString());
            return;
        }
        if (this.outToServer != null) {
            this.outToServer.close();
        }
        if (this.inToServer != null) {
            this.inToServer.close();
        }
        if (this.clientSocket == null) {
            return;
        } else {
            this.clientSocket.close();
            return;
        }
    }

    private java.net.InetAddress getBroadcastAddress()
    {
        return java.net.InetAddress.getByName("255.255.255.255");
    }

    private com.balboawatergroup.BalboaSpa.PacketType getPacketType(byte[] p2)
    {
        com.balboawatergroup.BalboaSpa.PacketType v0_2;
        switch (p2[4]) {
            case -108:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.ModuleIdentification;
                break;
            case 19:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.PanelUpdate;
                break;
            case 35:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.FilterCycleInfo;
                break;
            case 36:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.SystemInformation;
                break;
            case 37:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.SetupParameters;
                break;
            case 46:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.DeviceConfiguration;
                break;
            default:
                v0_2 = com.balboawatergroup.BalboaSpa.PacketType.Unknown;
        }
        return v0_2;
    }

    private String getStoredIP()
    {
        String v1 = 0;
        if (this.context != null) {
            v1 = this.context.getSharedPreferences("MyPrefsFile", 0).getString("SpaIP", 0);
        }
        return v1;
    }

    private void initializeSocket()
    {
        android.util.Log.i("Balboa", "initializeSocket begin");
        this.currentState = com.balboawatergroup.BalboaSpa.WifiSocketState.Connecting;
        String v1_14 = new byte[255];
        this.inputBuffer = v1_14;
        String v1_15 = new byte[255];
        this.outputBuffer = v1_15;
        this.foundAddress = 0;
        String v0 = this.getStoredIP();
        if (v0 != null) {
            this.ConnectSocket(v0);
        }
        if (this.currentState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
            this.LookupIPByUDPBroadcast();
            this.ConnectSocket(this.HOST_IP);
        }
        if (!this.foundAddress) {
            if (this.currentState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
                this.ConnectSocket(this.HOST_IP_SOFT_AP);
            }
            if (this.currentState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
                this.ConnectSocket(this.HOST_IP_ADHOC);
            }
        }
        if (this.currentState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
            this.LookupIPByUDPBroadcast();
            if (!this.foundAddress) {
                this.LookupIPByDNS();
                if (!this.foundAddress) {
                    this.LookupIPByNETBIOS();
                }
            }
            this.ConnectSocket(this.HOST_IP);
        }
        return;
    }

    private void sendMessageToParent(com.balboawatergroup.BalboaSpa.PacketType p5, java.io.Serializable p6, int p7)
    {
        android.os.Message v1_1 = new android.os.Message();
        android.os.Bundle v0_1 = new android.os.Bundle();
        v1_1.what = p7;
        v0_1.putInt("packetType", p5.id);
        if (p6 != null) {
            v0_1.putSerializable("state", p6);
        }
        v1_1.setData(v0_1);
        this.parentHandler.sendMessage(v1_1);
        return;
    }

    private void setUp()
    {
        this.lock = ((android.net.wifi.WifiManager) this.context.getSystemService("wifi")).createMulticastLock("mylockthereturn");
        this.lock.setReferenceCounted(1);
        this.lock.acquire();
        try {
            this.jmdns = javax.jmdns.JmDNS.create();
            javax.jmdns.JmDNS v2_3 = this.jmdns;
            String v3_2 = this.type;
            com.balboawatergroup.BalboaSpa.SocketListenerThread$2 v4_1 = new com.balboawatergroup.BalboaSpa.SocketListenerThread$2(this);
            this.listener = v4_1;
            v2_3.addServiceListener(v3_2, v4_1);
        } catch (java.io.IOException v0) {
            v0.printStackTrace();
        }
        return;
    }

    private void storeIP(String p6)
    {
        android.content.SharedPreferences$Editor v0 = this.context.getSharedPreferences("MyPrefsFile", 0).edit();
        v0.putString("SpaIP", p6);
        v0.commit();
        return;
    }

    public android.os.Handler getHandler()
    {
        return this.myThreadHandler;
    }

    public void run()
    {
        try {
            if (this.isInitialized.booleanValue()) {
                int v1 = 0;
                while (!this.stopped) {
                    if (!this.isInitialized.booleanValue()) {
                        this.initializeSocket();
                        com.balboawatergroup.BalboaSpa.SocketListenerThread.sleep(1000);
                    } else {
                        if (!this.hasConnectionBeenEstablished.booleanValue()) {
                            android.util.Log.i("Balboa", "Still waiting for connection to establish");
                            this.checkForIncomingData();
                            com.balboawatergroup.BalboaSpa.SocketListenerThread.sleep(1000);
                        } else {
                            if (this.currentState != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) {
                                this.initializeSocket();
                            } else {
                                v1++;
                                this.checkForOutgoingData();
                                if (this.checkForIncomingData()) {
                                    v1 = 0;
                                }
                                if (v1 == 100) {
                                    this.currentState = com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected;
                                    v1 = 0;
                                }
                                com.balboawatergroup.BalboaSpa.SocketListenerThread.sleep(100);
                            }
                        }
                    }
                }
                android.util.Log.i("Balboa", "Socket thread stopping");
                if (this.clientSocket != null) {
                    this.closeSocket();
                }
            } else {
                this.initializeSocket();
            }
        } catch (InterruptedException v0) {
            android.util.Log.e("Balboa", new StringBuilder().append("Main socket thread loop exception - ").append(v0).toString());
            this.closeSocket();
        }
        return;
    }
}
