package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$2 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$2(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        this.this$0.showDialog(996);
        return;
    }
}
