package com.balboawatergroup.BalboaSpa;
public class SpinnerAdapter extends android.widget.ArrayAdapter {
    private android.content.Context context;
    private com.balboawatergroup.BalboaSpa.WifiNetwork[] values;

    public SpinnerAdapter(android.content.Context p1, int p2, com.balboawatergroup.BalboaSpa.WifiNetwork[] p3)
    {
        super(p1, p2, p3);
        super.context = p1;
        super.values = p3;
        return;
    }

    public int getCount()
    {
        return this.values.length;
    }

    public android.view.View getDropDownView(int p3, android.view.View p4, android.view.ViewGroup p5)
    {
        android.widget.TextView v0_1 = new android.widget.TextView(this.context);
        v0_1.setTextColor(-16777216);
        v0_1.setText(this.values[p3].getName());
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.WifiNetwork getItem(int p2)
    {
        return this.values[p2];
    }

    public bridge synthetic Object getItem(int p2)
    {
        return this.getItem(p2);
    }

    public long getItemId(int p3)
    {
        return ((long) p3);
    }

    public android.view.View getView(int p3, android.view.View p4, android.view.ViewGroup p5)
    {
        android.widget.TextView v0_1 = new android.widget.TextView(this.context);
        v0_1.setTextColor(-16777216);
        v0_1.setText(this.values[p3].getName());
        return v0_1;
    }
}
