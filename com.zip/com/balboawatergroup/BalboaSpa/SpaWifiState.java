package com.balboawatergroup.BalboaSpa;
public final enum class SpaWifiState extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.SpaWifiState[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState Hold;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState Ok;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState Panel;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState Prime;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState SpaNotCommunicating;
    public static final enum com.balboawatergroup.BalboaSpa.SpaWifiState Startup;

    static SpaWifiState()
    {
        com.balboawatergroup.BalboaSpa.SpaWifiState.Ok = new com.balboawatergroup.BalboaSpa.SpaWifiState("Ok", 0);
        com.balboawatergroup.BalboaSpa.SpaWifiState.SpaNotCommunicating = new com.balboawatergroup.BalboaSpa.SpaWifiState("SpaNotCommunicating", 1);
        com.balboawatergroup.BalboaSpa.SpaWifiState.Startup = new com.balboawatergroup.BalboaSpa.SpaWifiState("Startup", 2);
        com.balboawatergroup.BalboaSpa.SpaWifiState.Prime = new com.balboawatergroup.BalboaSpa.SpaWifiState("Prime", 3);
        com.balboawatergroup.BalboaSpa.SpaWifiState.Hold = new com.balboawatergroup.BalboaSpa.SpaWifiState("Hold", 4);
        com.balboawatergroup.BalboaSpa.SpaWifiState.Panel = new com.balboawatergroup.BalboaSpa.SpaWifiState("Panel", 5);
        com.balboawatergroup.BalboaSpa.SpaWifiState[] v0_10 = new com.balboawatergroup.BalboaSpa.SpaWifiState[6];
        v0_10[0] = com.balboawatergroup.BalboaSpa.SpaWifiState.Ok;
        v0_10[1] = com.balboawatergroup.BalboaSpa.SpaWifiState.SpaNotCommunicating;
        v0_10[2] = com.balboawatergroup.BalboaSpa.SpaWifiState.Startup;
        v0_10[3] = com.balboawatergroup.BalboaSpa.SpaWifiState.Prime;
        v0_10[4] = com.balboawatergroup.BalboaSpa.SpaWifiState.Hold;
        v0_10[5] = com.balboawatergroup.BalboaSpa.SpaWifiState.Panel;
        com.balboawatergroup.BalboaSpa.SpaWifiState.$VALUES = v0_10;
        return;
    }

    private SpaWifiState(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.SpaWifiState valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.SpaWifiState) Enum.valueOf(com.balboawatergroup.BalboaSpa.SpaWifiState, p1));
    }

    public static com.balboawatergroup.BalboaSpa.SpaWifiState[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.SpaWifiState[]) com.balboawatergroup.BalboaSpa.SpaWifiState.$VALUES.clone());
    }
}
