package com.balboawatergroup.BalboaSpa;
 class ConfigureActivity$1 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConfigureActivity this$0;

    ConfigureActivity$1(com.balboawatergroup.BalboaSpa.ConfigureActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p2, int p3)
    {
        com.balboawatergroup.BalboaSpa.ConfigureActivity.access$000(this.this$0);
        return;
    }
}
