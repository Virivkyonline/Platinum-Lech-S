package com.balboawatergroup.BalboaSpa;
final class SpaController$2 extends java.util.TimerTask {
    final synthetic Runnable val$startIDigiModeRunnable;

    SpaController$2(Runnable p1)
    {
        this.val$startIDigiModeRunnable = p1;
        return;
    }

    public void run()
    {
        android.util.Log.i("Balboa", "Checking connection state");
        if ((com.balboawatergroup.BalboaSpa.SpaController.CurrentMode == "Wifi") && ((com.balboawatergroup.BalboaSpa.SpaController.GetWifiSocketState() != com.balboawatergroup.BalboaSpa.WifiSocketState.Connected) && (com.balboawatergroup.BalboaSpa.SpaController.IsIDigiModeAvailable()))) {
            android.util.Log.i("Balboa", "Switching to iDigi mode");
            try {
                com.balboawatergroup.BalboaSpa.ThreadedSocketController.StopThread();
            } catch (Exception v0) {
                android.util.Log.e("Balboa", "Error stopping socket thread when switching to iDigi mode", v0);
            }
            com.balboawatergroup.BalboaSpa.SpaController.runOnUI(this.val$startIDigiModeRunnable);
        }
        return;
    }
}
