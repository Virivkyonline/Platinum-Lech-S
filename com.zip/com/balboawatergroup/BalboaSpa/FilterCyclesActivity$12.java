package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$12 implements android.widget.TimePicker$OnTimeChangedListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$12(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeChanged(android.widget.TimePicker p2, int p3, int p4)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$300(this.this$0, p2, p3, p4);
        return;
    }
}
