package com.balboawatergroup.BalboaSpa;
 class HomeActivity$2 extends java.lang.Thread {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$2(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void run()
    {
        try {
            while(true) {
                Thread.sleep(30000);
                com.balboawatergroup.BalboaSpa.HomeActivity.access$100(this.this$0).sendEmptyMessage(0);
                android.util.Log.e("Balboa", "InterruptedException", InterruptedException v0);
            }
        } catch (InterruptedException v0) {
        }
    }
}
