package com.balboawatergroup.BalboaSpa;
 class SettingsActivity$3 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.SettingsActivity this$0;

    SettingsActivity$3(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p3)
    {
        com.balboawatergroup.BalboaSpa.SettingsActivity.access$502(this.this$0, 2);
        com.balboawatergroup.BalboaSpa.SpaController.TempRangePushed();
        if (com.balboawatergroup.BalboaSpa.SpaController.CurrentMode == "Demo") {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$700(this.this$0);
        }
        return;
    }
}
