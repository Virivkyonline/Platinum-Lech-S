package com.balboawatergroup.BalboaSpa;
 class TimeOfDayActivity$5 implements android.app.TimePickerDialog$OnTimeSetListener {
    final synthetic com.balboawatergroup.BalboaSpa.TimeOfDayActivity this$0;

    TimeOfDayActivity$5(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeSet(android.widget.TimePicker p4, int p5, int p6)
    {
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$302(this.this$0, p5);
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$402(this.this$0, p6);
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$500(this.this$0, com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$300(this.this$0), com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$400(this.this$0));
        this.this$0.removeDialog(999);
        return;
    }
}
