package com.balboawatergroup.BalboaSpa;
public final enum class PumpState extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.PumpState[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.PumpState High;
    public static final enum com.balboawatergroup.BalboaSpa.PumpState HighHeat;
    public static final enum com.balboawatergroup.BalboaSpa.PumpState Low;
    public static final enum com.balboawatergroup.BalboaSpa.PumpState LowHeat;
    public static final enum com.balboawatergroup.BalboaSpa.PumpState Off;

    static PumpState()
    {
        com.balboawatergroup.BalboaSpa.PumpState.Off = new com.balboawatergroup.BalboaSpa.PumpState("Off", 0);
        com.balboawatergroup.BalboaSpa.PumpState.Low = new com.balboawatergroup.BalboaSpa.PumpState("Low", 1);
        com.balboawatergroup.BalboaSpa.PumpState.High = new com.balboawatergroup.BalboaSpa.PumpState("High", 2);
        com.balboawatergroup.BalboaSpa.PumpState.LowHeat = new com.balboawatergroup.BalboaSpa.PumpState("LowHeat", 3);
        com.balboawatergroup.BalboaSpa.PumpState.HighHeat = new com.balboawatergroup.BalboaSpa.PumpState("HighHeat", 4);
        com.balboawatergroup.BalboaSpa.PumpState[] v0_8 = new com.balboawatergroup.BalboaSpa.PumpState[5];
        v0_8[0] = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v0_8[1] = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v0_8[2] = com.balboawatergroup.BalboaSpa.PumpState.High;
        v0_8[3] = com.balboawatergroup.BalboaSpa.PumpState.LowHeat;
        v0_8[4] = com.balboawatergroup.BalboaSpa.PumpState.HighHeat;
        com.balboawatergroup.BalboaSpa.PumpState.$VALUES = v0_8;
        return;
    }

    private PumpState(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.PumpState valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.PumpState) Enum.valueOf(com.balboawatergroup.BalboaSpa.PumpState, p1));
    }

    public static com.balboawatergroup.BalboaSpa.PumpState[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.PumpState[]) com.balboawatergroup.BalboaSpa.PumpState.$VALUES.clone());
    }

    public com.balboawatergroup.BalboaSpa.PumpState successor()
    {
        return com.balboawatergroup.BalboaSpa.PumpState.values()[((this.ordinal() + 1) % com.balboawatergroup.BalboaSpa.PumpState.values().length)];
    }
}
