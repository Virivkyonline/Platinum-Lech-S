package com.balboawatergroup.BalboaSpa;
public class DigiUserMessage {
    public Boolean lockout;
    public String text;
    public String url;

    public DigiUserMessage()
    {
        return;
    }
}
