package com.balboawatergroup.BalboaSpa;
public class DemoCommunicator implements com.balboawatergroup.BalboaSpa.ISpaCommunicator {
    private static com.balboawatergroup.BalboaSpa.FilterCycle currentFilterCycle;
    private static com.balboawatergroup.BalboaSpa.SpaControlState currentState;

    public DemoCommunicator()
    {
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState = this.GetIntialDemoState();
        return;
    }

    private static com.balboawatergroup.BalboaSpa.FilterCycle GetInitialDemoFilterCycle()
    {
        com.balboawatergroup.BalboaSpa.FilterCycle v0_1 = new com.balboawatergroup.BalboaSpa.FilterCycle();
        v0_1.FilterCycle1StartsAtHour = 2;
        v0_1.FilterCycle1StartsAtMinute = 35;
        v0_1.FilterCycle2StartsAtHour = 5;
        v0_1.FilterCycle2StartsAtMinute = 25;
        v0_1.FilterCycle1DurationHour = 1;
        v0_1.FilterCycle1DurationMinute = 15;
        v0_1.FilterCycle2DurationHour = 2;
        v0_1.FilterCycle2DurationMinute = 45;
        v0_1.FilterCycle2Enabled = 1;
        return v0_1;
    }

    private com.balboawatergroup.BalboaSpa.SpaControlState GetIntialDemoState()
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v1_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        v1_1.Aux1On = 1;
        v1_1.Aux2On = 0;
        v1_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Off;
        v1_1.Light1On = 1;
        v1_1.Light2On = 0;
        v1_1.MisterOn = 0;
        v1_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v1_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v1_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.High;
        v1_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        v1_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.Off;
        v1_1.Is24HourTime = 0;
        java.util.Calendar.getInstance();
        if (!v1_1.Is24HourTime) {
            v1_1.CurrentTimeHour = 10;
        } else {
            v1_1.CurrentTimeHour = 11;
        }
        v1_1.TargetTemperature = 1120665600;
        v1_1.ActualTemperature = 1120665600;
        v1_1.TemperatureScale = com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit;
        return v1_1;
    }

    public void Aux1ControlPushed()
    {
        int v0_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v1 = this.GetCurrentState();
        if (this.GetCurrentState().Aux1On) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        v1.Aux1On = v0_2;
        return;
    }

    public void Aux2ControlPushed()
    {
        int v0_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v1 = this.GetCurrentState();
        if (this.GetCurrentState().Aux2On) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        v1.Aux2On = v0_2;
        return;
    }

    public void BlowerControlPushed()
    {
        this.GetCurrentState().BlowerState = this.GetCurrentState().BlowerState.successor();
        return;
    }

    public void ConnectToWifi(com.balboawatergroup.BalboaSpa.ConnectionMethod p1, com.balboawatergroup.BalboaSpa.SecurityType p2, String p3, String p4)
    {
        return;
    }

    public com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration GetCurrentConfiguration()
    {
        return 0;
    }

    public com.balboawatergroup.BalboaSpa.SpaControlState GetCurrentState()
    {
        if (com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState == null) {
            com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState = this.GetIntialDemoState();
        }
        return com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState;
    }

    public com.balboawatergroup.BalboaSpa.SpaSystemInformation GetCurrentSystemInformation()
    {
        com.balboawatergroup.BalboaSpa.SpaSystemInformation v0_1 = new com.balboawatergroup.BalboaSpa.SpaSystemInformation();
        v0_1.isOldVersion = 0;
        return v0_1;
    }

    public com.balboawatergroup.BalboaSpa.FilterCycle GetFilterCycle()
    {
        if (com.balboawatergroup.BalboaSpa.DemoCommunicator.currentFilterCycle == null) {
            com.balboawatergroup.BalboaSpa.DemoCommunicator.currentFilterCycle = com.balboawatergroup.BalboaSpa.DemoCommunicator.GetInitialDemoFilterCycle();
        }
        return com.balboawatergroup.BalboaSpa.DemoCommunicator.currentFilterCycle;
    }

    public com.balboawatergroup.BalboaSpa.WifiSocketState GetWifiSocketState()
    {
        return com.balboawatergroup.BalboaSpa.WifiSocketState.NotApplicable;
    }

    public boolean HasCurrentDeviceConfig()
    {
        return 1;
    }

    public void HeatModePushed()
    {
        if (this.GetCurrentState().HeatMode != com.balboawatergroup.BalboaSpa.HeatMode.Ready) {
            this.GetCurrentState().HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.Ready;
        } else {
            this.GetCurrentState().HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.Rest;
        }
        return;
    }

    public void Light1ControlPushed()
    {
        int v0_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v1 = this.GetCurrentState();
        if (this.GetCurrentState().Light1On) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        v1.Light1On = v0_2;
        return;
    }

    public void Light2ControlPushed()
    {
        int v0_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v1 = this.GetCurrentState();
        if (this.GetCurrentState().Light2On) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        v1.Light2On = v0_2;
        return;
    }

    public void MisterControlPushed()
    {
        int v0_2;
        com.balboawatergroup.BalboaSpa.SpaControlState v1 = this.GetCurrentState();
        if (this.GetCurrentState().MisterOn) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        v1.MisterOn = v0_2;
        return;
    }

    public void Pump1ControlPushed()
    {
        this.GetCurrentState().Pump1State = this.GetCurrentState().Pump1State.successor();
        return;
    }

    public void Pump2ControlPushed()
    {
        this.GetCurrentState().Pump2State = this.GetCurrentState().Pump2State.successor();
        return;
    }

    public void Pump3ControlPushed()
    {
        this.GetCurrentState().Pump3State = this.GetCurrentState().Pump3State.successor();
        return;
    }

    public void Pump4ControlPushed()
    {
        this.GetCurrentState().Pump4State = this.GetCurrentState().Pump4State.successor();
        return;
    }

    public void Pump5ControlPushed()
    {
        this.GetCurrentState().Pump5State = this.GetCurrentState().Pump5State.successor();
        return;
    }

    public void SaveFilterCycle(com.balboawatergroup.BalboaSpa.FilterCycle p1)
    {
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentFilterCycle = p1;
        return;
    }

    public void SendDevicePresentQuery()
    {
        return;
    }

    public void SendPanelRequest(com.balboawatergroup.BalboaSpa.PanelRequestType p1)
    {
        return;
    }

    public void Set24HourTime(boolean p2)
    {
        this.GetCurrentState().Is24HourTime = p2;
        return;
    }

    public void SetTargetTemperature(float p2)
    {
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState.TargetTemperature = p2;
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState.ActualTemperature = p2;
        return;
    }

    public void SetTemperatureScale(com.balboawatergroup.BalboaSpa.TemperatureScale p2)
    {
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState.TemperatureScale = p2;
        return;
    }

    public void SetTime(int p2, int p3, boolean p4)
    {
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState.CurrentTimeHour = p2;
        com.balboawatergroup.BalboaSpa.DemoCommunicator.currentState.CurrentTimeMinute = p2;
        return;
    }

    public void StartThread(android.content.Context p1)
    {
        return;
    }

    public void StopThread()
    {
        return;
    }

    public void TempRangePushed()
    {
        if (this.GetCurrentState().TemperateRange != com.balboawatergroup.BalboaSpa.TemperatureRange.High) {
            this.GetCurrentState().TemperateRange = com.balboawatergroup.BalboaSpa.TemperatureRange.High;
        } else {
            this.GetCurrentState().TemperateRange = com.balboawatergroup.BalboaSpa.TemperatureRange.Low;
        }
        return;
    }
}
