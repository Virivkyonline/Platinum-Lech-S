package com.balboawatergroup.BalboaSpa;
 class iDigiCommunicator$2 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.iDigiCommunicator this$0;

    iDigiCommunicator$2(com.balboawatergroup.BalboaSpa.iDigiCommunicator p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p1, int p2)
    {
        return;
    }
}
