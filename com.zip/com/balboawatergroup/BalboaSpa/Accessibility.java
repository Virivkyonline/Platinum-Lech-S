package com.balboawatergroup.BalboaSpa;
public final enum class Accessibility extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.Accessibility[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.Accessibility ACCESSIBILITY_ALL;
    public static final enum com.balboawatergroup.BalboaSpa.Accessibility ACCESSIBILITY_NONE;
    public static final enum com.balboawatergroup.BalboaSpa.Accessibility ACCESSIBILITY_PUMP_LIGHT;

    static Accessibility()
    {
        com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT = new com.balboawatergroup.BalboaSpa.Accessibility("ACCESSIBILITY_PUMP_LIGHT", 0);
        com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE = new com.balboawatergroup.BalboaSpa.Accessibility("ACCESSIBILITY_NONE", 1);
        com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL = new com.balboawatergroup.BalboaSpa.Accessibility("ACCESSIBILITY_ALL", 2);
        com.balboawatergroup.BalboaSpa.Accessibility[] v0_3 = new com.balboawatergroup.BalboaSpa.Accessibility[3];
        v0_3[0] = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT;
        v0_3[1] = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE;
        v0_3[2] = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL;
        com.balboawatergroup.BalboaSpa.Accessibility.$VALUES = v0_3;
        return;
    }

    private Accessibility(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.Accessibility valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.Accessibility) Enum.valueOf(com.balboawatergroup.BalboaSpa.Accessibility, p1));
    }

    public static com.balboawatergroup.BalboaSpa.Accessibility[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.Accessibility[]) com.balboawatergroup.BalboaSpa.Accessibility.$VALUES.clone());
    }
}
