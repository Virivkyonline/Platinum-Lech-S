package com.balboawatergroup.BalboaSpa;
public final class BuildConfig {
    public static final boolean DEBUG;

    public BuildConfig()
    {
        return;
    }
}
