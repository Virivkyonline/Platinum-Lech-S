package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$17 implements android.app.TimePickerDialog$OnTimeSetListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$17(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeSet(android.widget.TimePicker p3, int p4, int p5)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$1002(this.this$0, p4);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$1102(this.this$0, p5);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$100(this.this$0);
        this.this$0.removeDialog(993);
        return;
    }
}
