package com.balboawatergroup.BalboaSpa;
 class HomeActivity$8 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$8(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        this.this$0.imgCloud.setVisibility(0);
        return;
    }
}
