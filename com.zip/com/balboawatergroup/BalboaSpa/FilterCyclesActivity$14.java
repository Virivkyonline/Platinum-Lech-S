package com.balboawatergroup.BalboaSpa;
 class FilterCyclesActivity$14 implements android.app.TimePickerDialog$OnTimeSetListener {
    final synthetic com.balboawatergroup.BalboaSpa.FilterCyclesActivity this$0;

    FilterCyclesActivity$14(com.balboawatergroup.BalboaSpa.FilterCyclesActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onTimeSet(android.widget.TimePicker p3, int p4, int p5)
    {
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$402(this.this$0, p4);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$502(this.this$0, p5);
        com.balboawatergroup.BalboaSpa.FilterCyclesActivity.access$100(this.this$0);
        this.this$0.removeDialog(996);
        return;
    }
}
