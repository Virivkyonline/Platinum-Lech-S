package com.balboawatergroup.BalboaSpa;
public final enum class SecurityType extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.SecurityType[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.SecurityType Open;
    public static final enum com.balboawatergroup.BalboaSpa.SecurityType WEP;
    public static final enum com.balboawatergroup.BalboaSpa.SecurityType WPA;
    public int id;

    static SecurityType()
    {
        com.balboawatergroup.BalboaSpa.SecurityType.Open = new com.balboawatergroup.BalboaSpa.SecurityType("Open", 0, 0);
        com.balboawatergroup.BalboaSpa.SecurityType.WEP = new com.balboawatergroup.BalboaSpa.SecurityType("WEP", 1, 2);
        com.balboawatergroup.BalboaSpa.SecurityType.WPA = new com.balboawatergroup.BalboaSpa.SecurityType("WPA", 2, 8);
        com.balboawatergroup.BalboaSpa.SecurityType[] v0_3 = new com.balboawatergroup.BalboaSpa.SecurityType[3];
        v0_3[0] = com.balboawatergroup.BalboaSpa.SecurityType.Open;
        v0_3[1] = com.balboawatergroup.BalboaSpa.SecurityType.WEP;
        v0_3[2] = com.balboawatergroup.BalboaSpa.SecurityType.WPA;
        com.balboawatergroup.BalboaSpa.SecurityType.$VALUES = v0_3;
        return;
    }

    private SecurityType(String p1, int p2, int p3)
    {
        super(p1, p2);
        super.id = p3;
        return;
    }

    public static com.balboawatergroup.BalboaSpa.SecurityType valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.SecurityType) Enum.valueOf(com.balboawatergroup.BalboaSpa.SecurityType, p1));
    }

    public static com.balboawatergroup.BalboaSpa.SecurityType[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.SecurityType[]) com.balboawatergroup.BalboaSpa.SecurityType.$VALUES.clone());
    }
}
