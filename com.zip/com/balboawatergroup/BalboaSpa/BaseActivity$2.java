package com.balboawatergroup.BalboaSpa;
 class BaseActivity$2 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.BaseActivity this$0;

    BaseActivity$2(com.balboawatergroup.BalboaSpa.BaseActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p2, android.content.Intent p3)
    {
        if (this.this$0.progress != null) {
            this.this$0.progress.dismiss();
        }
        return;
    }
}
