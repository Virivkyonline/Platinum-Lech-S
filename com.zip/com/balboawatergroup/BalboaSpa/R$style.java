package com.balboawatergroup.BalboaSpa;
public final class R$style {
    public static final int BlueButton = 2131165187;
    public static final int ClockFont = 2131165184;
    public static final int HeaderText = 2131165188;
    public static final int MediumBlueFont = 2131165185;
    public static final int smallFont = 2131165186;

    public R$style()
    {
        return;
    }
}
