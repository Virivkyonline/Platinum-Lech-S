package com.balboawatergroup.BalboaSpa;
 class HomeActivity$9 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$9(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        this.this$0.imgCloud.setVisibility(4);
        return;
    }
}
