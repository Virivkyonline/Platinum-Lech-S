package com.balboawatergroup.BalboaSpa;
public class Connectivity {

    public Connectivity()
    {
        return;
    }

    public static android.net.NetworkInfo getNetworkInfo(android.content.Context p2)
    {
        return ((android.net.ConnectivityManager) p2.getSystemService("connectivity")).getActiveNetworkInfo();
    }

    public static boolean isConnected(android.content.Context p2)
    {
        int v1_1;
        android.net.NetworkInfo v0 = com.balboawatergroup.BalboaSpa.Connectivity.getNetworkInfo(p2);
        if ((v0 == null) || (!v0.isConnected())) {
            v1_1 = 0;
        } else {
            v1_1 = 1;
        }
        return v1_1;
    }

    public static boolean isConnectedFast(android.content.Context p3)
    {
        int v1_1;
        android.net.NetworkInfo v0 = com.balboawatergroup.BalboaSpa.Connectivity.getNetworkInfo(p3);
        if ((v0 == null) || ((!v0.isConnected()) || (!com.balboawatergroup.BalboaSpa.Connectivity.isConnectionFast(v0.getType(), v0.getSubtype())))) {
            v1_1 = 0;
        } else {
            v1_1 = 1;
        }
        return v1_1;
    }

    public static boolean isConnectedMobile(android.content.Context p2)
    {
        int v1_0;
        android.net.NetworkInfo v0 = com.balboawatergroup.BalboaSpa.Connectivity.getNetworkInfo(p2);
        if ((v0 == null) || ((!v0.isConnected()) || (v0.getType() != 0))) {
            v1_0 = 0;
        } else {
            v1_0 = 1;
        }
        return v1_0;
    }

    public static boolean isConnectedWifi(android.content.Context p3)
    {
        int v1 = 1;
        android.net.NetworkInfo v0 = com.balboawatergroup.BalboaSpa.Connectivity.getNetworkInfo(p3);
        if ((v0 == null) || ((!v0.isConnected()) || (v0.getType() != 1))) {
            v1 = 0;
        }
        return v1;
    }

    public static boolean isConnectionFast(int p2, int p3)
    {
        int v0 = 1;
        if (p2 != 1) {
            if (p2 != 0) {
                v0 = 0;
            } else {
                switch (p3) {
                    case 1:
                        v0 = 0;
                        break;
                    case 2:
                        v0 = 0;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 4:
                        v0 = 0;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 7:
                        v0 = 0;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 11:
                        v0 = 0;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        break;
                    default:
                        v0 = 0;
                }
            }
        }
        return v0;
    }
}
