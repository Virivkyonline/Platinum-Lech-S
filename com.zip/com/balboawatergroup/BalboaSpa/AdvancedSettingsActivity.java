package com.balboawatergroup.BalboaSpa;
public class AdvancedSettingsActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    private android.widget.TextView tvCurrentMode;

    public AdvancedSettingsActivity()
    {
        return;
    }

    private void ShowCurrentMode()
    {
        this.tvCurrentMode.setText(com.balboawatergroup.BalboaSpa.SpaController.CurrentMode);
        return;
    }

    public void onCreate(android.os.Bundle p2)
    {
        super.onCreate(p2);
        this.setContentView(2130903040);
        this.tvCurrentMode = ((android.widget.TextView) this.findViewById(2131230723));
        this.ShowCurrentMode();
        return;
    }

    public void setDemoMode(android.view.View p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetDemoMode();
        this.ShowCurrentMode();
        return;
    }

    public void setIDigiMode(android.view.View p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetIDigiMode(this);
        this.ShowCurrentMode();
        return;
    }

    public void setWifiMode(android.view.View p1)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetWifiMode(this);
        this.ShowCurrentMode();
        return;
    }

    public void showConfigure(android.view.View p3)
    {
        this.startActivity(new android.content.Intent(this, com.balboawatergroup.BalboaSpa.ConfigureActivity));
        return;
    }
}
