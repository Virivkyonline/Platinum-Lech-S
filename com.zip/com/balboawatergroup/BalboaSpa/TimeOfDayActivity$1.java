package com.balboawatergroup.BalboaSpa;
 class TimeOfDayActivity$1 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.TimeOfDayActivity this$0;

    TimeOfDayActivity$1(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p2, android.content.Intent p3)
    {
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$000(this.this$0);
        return;
    }
}
