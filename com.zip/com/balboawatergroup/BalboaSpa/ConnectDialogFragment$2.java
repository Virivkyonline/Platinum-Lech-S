package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$2 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment this$0;

    ConnectDialogFragment$2(com.balboawatergroup.BalboaSpa.ConnectDialogFragment p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p7, int p8)
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetWifiMode(this.this$0.getActivity());
        this.this$0.progress = new android.app.ProgressDialog(this.this$0.getActivity());
        this.this$0.progress.setTitle("Loading");
        this.this$0.progress.setCancelable(0);
        this.this$0.progress.setMessage("Wait while connecting...");
        this.this$0.progress.show();
        try {
            ((com.balboawatergroup.BalboaSpa.BaseFragmentActivity) this.this$0.getActivity()).isConnectDialogCurrentlyBeingShown = Boolean.valueOf(0);
        } catch (Exception v1) {
            android.util.Log.e("Balboa", "exception accessing base fragment activity", v1);
        }
        return;
    }
}
