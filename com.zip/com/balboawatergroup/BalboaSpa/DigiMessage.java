package com.balboawatergroup.BalboaSpa;
public class DigiMessage {
    public String content;
    public String deviceID;
    public String target;

    public DigiMessage()
    {
        return;
    }
}
