package com.balboawatergroup.BalboaSpa;
 class HomeActivity$10 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.HomeActivity this$0;

    HomeActivity$10(com.balboawatergroup.BalboaSpa.HomeActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p8, android.content.Intent p9)
    {
        String v2 = p9.getStringExtra("text");
        String v3 = p9.getStringExtra("url");
        String v1 = p9.getStringExtra("lockout");
        this.this$0.digiMessageDialogFragment = new com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment();
        android.os.Bundle v0_1 = new android.os.Bundle();
        v0_1.putString("text", v2);
        v0_1.putString("url", v3);
        v0_1.putString("lockout", v1);
        this.this$0.digiMessageDialogFragment.setArguments(v0_1);
        this.this$0.digiMessageDialogFragment.show(this.this$0.getSupportFragmentManager(), "DigiMessageDialogFragment");
        return;
    }
}
