package com.balboawatergroup.BalboaSpa;
public final enum class FilterMode extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.FilterMode[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.FilterMode FILTER_1;
    public static final enum com.balboawatergroup.BalboaSpa.FilterMode FILTER_1_2;
    public static final enum com.balboawatergroup.BalboaSpa.FilterMode FILTER_2;
    public static final enum com.balboawatergroup.BalboaSpa.FilterMode FILTER_OFF;

    static FilterMode()
    {
        com.balboawatergroup.BalboaSpa.FilterMode.FILTER_OFF = new com.balboawatergroup.BalboaSpa.FilterMode("FILTER_OFF", 0);
        com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1 = new com.balboawatergroup.BalboaSpa.FilterMode("FILTER_1", 1);
        com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1_2 = new com.balboawatergroup.BalboaSpa.FilterMode("FILTER_1_2", 2);
        com.balboawatergroup.BalboaSpa.FilterMode.FILTER_2 = new com.balboawatergroup.BalboaSpa.FilterMode("FILTER_2", 3);
        com.balboawatergroup.BalboaSpa.FilterMode[] v0_6 = new com.balboawatergroup.BalboaSpa.FilterMode[4];
        v0_6[0] = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_OFF;
        v0_6[1] = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1;
        v0_6[2] = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1_2;
        v0_6[3] = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_2;
        com.balboawatergroup.BalboaSpa.FilterMode.$VALUES = v0_6;
        return;
    }

    private FilterMode(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.FilterMode valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.FilterMode) Enum.valueOf(com.balboawatergroup.BalboaSpa.FilterMode, p1));
    }

    public static com.balboawatergroup.BalboaSpa.FilterMode[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.FilterMode[]) com.balboawatergroup.BalboaSpa.FilterMode.$VALUES.clone());
    }
}
