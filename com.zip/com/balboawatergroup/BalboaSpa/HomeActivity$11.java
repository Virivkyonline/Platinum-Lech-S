package com.balboawatergroup.BalboaSpa;
synthetic class HomeActivity$11 {
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$FilterMode;
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$SpaWifiState;
    static final synthetic int[] $SwitchMap$com$balboawatergroup$BalboaSpa$WifiSocketState;

    static HomeActivity$11()
    {
        NoSuchFieldError v0_5 = new int[com.balboawatergroup.BalboaSpa.FilterMode.values().length];
        com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$FilterMode = v0_5;
        try {
            com.balboawatergroup.BalboaSpa.FilterMode.FILTER_OFF.ordinal()[int v1_20] = 1;
            try {
                com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1.ordinal()[int v1_3] = 2;
                try {
                    com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1_2.ordinal()[int v1_5] = 3;
                    try {
                        com.balboawatergroup.BalboaSpa.FilterMode.FILTER_2.ordinal()[int v1_7] = 4;
                    } catch (NoSuchFieldError v0) {
                    }
                    NoSuchFieldError v0_8 = new int[com.balboawatergroup.BalboaSpa.SpaWifiState.values().length];
                    com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$SpaWifiState = v0_8;
                    try {
                        com.balboawatergroup.BalboaSpa.SpaWifiState.SpaNotCommunicating.ordinal()[int v1_9] = 1;
                        try {
                            com.balboawatergroup.BalboaSpa.SpaWifiState.Startup.ordinal()[int v1_11] = 2;
                            try {
                                com.balboawatergroup.BalboaSpa.SpaWifiState.Prime.ordinal()[int v1_13] = 3;
                                try {
                                    com.balboawatergroup.BalboaSpa.SpaWifiState.Hold.ordinal()[int v1_16] = 4;
                                    try {
                                        com.balboawatergroup.BalboaSpa.SpaWifiState.Panel.ordinal()[int v1_18] = 5;
                                    } catch (NoSuchFieldError v0) {
                                    }
                                    NoSuchFieldError v0_17 = new int[com.balboawatergroup.BalboaSpa.WifiSocketState.values().length];
                                    com.balboawatergroup.BalboaSpa.HomeActivity$11.$SwitchMap$com$balboawatergroup$BalboaSpa$WifiSocketState = v0_17;
                                    try {
                                        com.balboawatergroup.BalboaSpa.WifiSocketState.Connected.ordinal()[int v1_21] = 1;
                                        try {
                                            com.balboawatergroup.BalboaSpa.WifiSocketState.NotConnected.ordinal()[int v1_23] = 2;
                                            try {
                                                com.balboawatergroup.BalboaSpa.WifiSocketState.NotApplicable.ordinal()[int v1_25] = 3;
                                                try {
                                                    com.balboawatergroup.BalboaSpa.WifiSocketState.Connecting.ordinal()[int v1_1] = 4;
                                                } catch (NoSuchFieldError v0) {
                                                }
                                                return;
                                            } catch (NoSuchFieldError v0) {
                                            }
                                        } catch (NoSuchFieldError v0) {
                                        }
                                    } catch (NoSuchFieldError v0) {
                                    }
                                } catch (NoSuchFieldError v0) {
                                }
                            } catch (NoSuchFieldError v0) {
                            }
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
