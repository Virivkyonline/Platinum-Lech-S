package com.balboawatergroup.BalboaSpa;
 class ControlsActivity$1 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.ControlsActivity this$0;

    ControlsActivity$1(com.balboawatergroup.BalboaSpa.ControlsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        p4.getStringExtra("message");
        if (com.balboawatergroup.BalboaSpa.ControlsActivity.access$000(this.this$0) != 0) {
            com.balboawatergroup.BalboaSpa.ControlsActivity.access$010(this.this$0);
        } else {
            this.this$0.refreshControlIcons();
        }
        return;
    }
}
