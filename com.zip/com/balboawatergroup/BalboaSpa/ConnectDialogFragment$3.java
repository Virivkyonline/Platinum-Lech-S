package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$3 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment this$0;

    ConnectDialogFragment$3(com.balboawatergroup.BalboaSpa.ConnectDialogFragment p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p6, android.content.Intent p7)
    {
        new java.util.Timer().schedule(new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$3$1(this, new android.os.Handler()), 5000);
        return;
    }
}
