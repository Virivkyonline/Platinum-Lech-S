package com.balboawatergroup.BalboaSpa;
 class SettingsActivity$2 extends android.content.BroadcastReceiver {
    final synthetic com.balboawatergroup.BalboaSpa.SettingsActivity this$0;

    SettingsActivity$2(com.balboawatergroup.BalboaSpa.SettingsActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onReceive(android.content.Context p2, android.content.Intent p3)
    {
        if (com.balboawatergroup.BalboaSpa.SettingsActivity.access$500(this.this$0) != 0) {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$510(this.this$0);
        } else {
            com.balboawatergroup.BalboaSpa.SettingsActivity.access$700(this.this$0);
        }
        return;
    }
}
