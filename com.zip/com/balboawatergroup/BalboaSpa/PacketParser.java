package com.balboawatergroup.BalboaSpa;
public class PacketParser {

    public PacketParser()
    {
        return;
    }

    public static com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration ParseDeviceConfiguration(byte[] p13)
    {
        com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration v5_1 = new com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration();
        byte v3 = p13[8];
        if ((v3 & 128) != 0) {
            v5_1.HasPump0 = 1;
        }
        byte v0 = p13[5];
        if ((v0 & 3) != 0) {
            v5_1.HasPump1 = 1;
        }
        if ((v0 & 12) != 0) {
            v5_1.HasPump2 = 1;
        }
        if ((v0 & 48) != 0) {
            v5_1.HasPump3 = 1;
        }
        if ((v0 & 192) != 0) {
            v5_1.HasPump4 = 1;
        }
        byte v1 = p13[6];
        if ((v1 & 3) != 0) {
            v5_1.HasPump5 = 1;
        }
        if ((v1 & 192) != 0) {
            v5_1.HasPump6 = 1;
        }
        byte v2 = p13[7];
        if ((v2 & 3) != 0) {
            v5_1.HasLight1 = 1;
        }
        if ((v2 & 192) != 0) {
            v5_1.HasLight2 = 1;
        }
        byte v4 = p13[9];
        if ((v4 & 1) != 0) {
            v5_1.HasAux1 = 1;
        }
        if ((v4 & 2) != 0) {
            v5_1.HasAux1 = 1;
        }
        if ((v3 & 3) != 0) {
            v5_1.HasBlower = 1;
        }
        if ((v4 & 16) != 0) {
            v5_1.HasMister = 1;
        }
        return v5_1;
    }

    public static com.balboawatergroup.BalboaSpa.FilterCycle ParseFilterCycle(byte[] p11)
    {
        int v10_3;
        com.balboawatergroup.BalboaSpa.FilterCycle v8_1 = new com.balboawatergroup.BalboaSpa.FilterCycle();
        v8_1.FilterCycle1StartsAtHour = p11[5];
        v8_1.FilterCycle1StartsAtMinute = p11[6];
        v8_1.FilterCycle1DurationHour = p11[7];
        v8_1.FilterCycle1DurationMinute = p11[8];
        byte v7 = p11[9];
        v8_1.FilterCycle2StartsAtHour = (v7 & 127);
        if ((v7 & 128) <= 0) {
            v10_3 = 0;
        } else {
            v10_3 = 1;
        }
        v8_1.FilterCycle2Enabled = v10_3;
        v8_1.FilterCycle2StartsAtMinute = p11[10];
        v8_1.FilterCycle2DurationHour = p11[11];
        v8_1.FilterCycle2DurationMinute = p11[12];
        return v8_1;
    }

    public static com.balboawatergroup.BalboaSpa.SpaModuleIdentification ParseModuleIdentication(byte[] p5)
    {
        com.balboawatergroup.BalboaSpa.SpaModuleIdentification v0_1 = new com.balboawatergroup.BalboaSpa.SpaModuleIdentification();
        System.arraycopy(p5, 14, v0_1.iDigiDeviceID, 0, 16);
        return v0_1;
    }

    public static com.balboawatergroup.BalboaSpa.SpaControlState ParsePanelUpdate(byte[] p26)
    {
        com.balboawatergroup.BalboaSpa.SpaControlState v15_1 = new com.balboawatergroup.BalboaSpa.SpaControlState();
        v15_1.CurrentTimeHour = p26[8];
        v15_1.CurrentTimeMinute = p26[9];
        byte v3 = p26[14];
        if ((v3 & 2) != 0) {
            v15_1.Is24HourTime = 1;
        } else {
            v15_1.Is24HourTime = 0;
        }
        if ((v3 & 1) != 0) {
            v15_1.TemperatureScale = com.balboawatergroup.BalboaSpa.TemperatureScale.Celsius;
        } else {
            v15_1.TemperatureScale = com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit;
        }
        byte v12 = p26[7];
        if (v12 != 255) {
            com.balboawatergroup.BalboaSpa.SpaWifiState v24_94;
            if (v15_1.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit) {
                v24_94 = (((float) v12) / 1073741824);
            } else {
                v24_94 = ((float) v12);
            }
            v15_1.ActualTemperature = v24_94;
        } else {
            v15_1.ActualTemperature = ((float) v12);
        }
        com.balboawatergroup.BalboaSpa.SpaWifiState v24_105;
        byte v10 = p26[25];
        if (v15_1.TemperatureScale != com.balboawatergroup.BalboaSpa.TemperatureScale.Farenheit) {
            v24_105 = (((float) v10) / 1073741824);
        } else {
            v24_105 = ((float) v10);
        }
        v15_1.TargetTemperature = v24_105;
        int v16_2 = (v3 & 12);
        if (v16_2 != 0) {
            if (v16_2 != 4) {
                if (v16_2 != 12) {
                    if (v16_2 != 8) {
                        v15_1.FilterMode = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_OFF;
                    } else {
                        v15_1.FilterMode = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_2;
                    }
                } else {
                    v15_1.FilterMode = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1_2;
                }
            } else {
                v15_1.FilterMode = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_1;
            }
        } else {
            v15_1.FilterMode = com.balboawatergroup.BalboaSpa.FilterMode.FILTER_OFF;
        }
        int v16_3 = (v3 & 48);
        if (v16_3 != 16) {
            if (v16_3 != 32) {
                if (v16_3 != 48) {
                    v15_1.AccessibilityType = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_ALL;
                } else {
                    v15_1.AccessibilityType = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE;
                }
            } else {
                v15_1.AccessibilityType = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_NONE;
            }
        } else {
            v15_1.AccessibilityType = com.balboawatergroup.BalboaSpa.Accessibility.ACCESSIBILITY_PUMP_LIGHT;
        }
        byte v4 = p26[15];
        if ((v4 & 4) != 4) {
            v15_1.TemperateRange = com.balboawatergroup.BalboaSpa.TemperatureRange.Low;
        } else {
            v15_1.TemperateRange = com.balboawatergroup.BalboaSpa.TemperatureRange.High;
        }
        byte v8 = p26[19];
        if ((v8 & 3) != 0) {
            v15_1.Light1On = 1;
        } else {
            v15_1.Light1On = 0;
        }
        if ((v8 & 12) != 0) {
            v15_1.Light2On = 1;
        } else {
            v15_1.Light2On = 0;
        }
        byte v2 = p26[10];
        if (v2 != 0) {
            if (v2 != 1) {
                if (v2 != 2) {
                    v15_1.HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.None;
                } else {
                    v15_1.HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.ReadyInRest;
                }
            } else {
                v15_1.HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.Rest;
            }
        } else {
            v15_1.HeatMode = com.balboawatergroup.BalboaSpa.HeatMode.Ready;
        }
        int v17_1 = (v4 & 48);
        byte v5 = p26[16];
        int v18_0 = (v5 & 3);
        if (v18_0 != 1) {
            if (v18_0 != 2) {
                v15_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                if ((v17_1 == 0) || (com.balboawatergroup.BalboaSpa.SpaController.HasPump0)) {
                    v15_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.High;
                } else {
                    v15_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.HighHeat;
                }
            }
        } else {
            if ((v17_1 == 0) || (com.balboawatergroup.BalboaSpa.SpaController.HasPump0)) {
                v15_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.Low;
            } else {
                v15_1.Pump1State = com.balboawatergroup.BalboaSpa.PumpState.LowHeat;
            }
        }
        int v18_1 = (v5 & 12);
        if (v18_1 != 4) {
            if (v18_1 != 8) {
                v15_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                v15_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.High;
            }
        } else {
            v15_1.Pump2State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        }
        int v18_2 = (v5 & 48);
        if (v18_2 != 16) {
            if (v18_2 != 32) {
                v15_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                v15_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.High;
            }
        } else {
            v15_1.Pump3State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        }
        int v18_3 = (v5 & 192);
        if (v18_3 != 64) {
            if (v18_3 != 128) {
                v15_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                v15_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.High;
            }
        } else {
            v15_1.Pump4State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        }
        byte v6 = p26[17];
        int v19_0 = (v6 & 3);
        if (v19_0 != 1) {
            if (v19_0 != 2) {
                v15_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                v15_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.High;
            }
        } else {
            v15_1.Pump5State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        }
        int v19_1 = (v6 & 12);
        if (v19_1 != 4) {
            if (v19_1 != 8) {
                v15_1.Pump6State = com.balboawatergroup.BalboaSpa.PumpState.Off;
            } else {
                v15_1.Pump6State = com.balboawatergroup.BalboaSpa.PumpState.High;
            }
        } else {
            v15_1.Pump6State = com.balboawatergroup.BalboaSpa.PumpState.Low;
        }
        byte v7 = p26[18];
        int v20_0 = (v7 & 12);
        if (v20_0 != 4) {
            if (v20_0 != 8) {
                if (v20_0 != 12) {
                    v15_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Off;
                } else {
                    v15_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.High;
                }
            } else {
                v15_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Medium;
            }
        } else {
            v15_1.BlowerState = com.balboawatergroup.BalboaSpa.BlowerState.Low;
        }
        byte v9 = p26[20];
        if ((v9 & 1) != 0) {
            v15_1.MisterOn = 1;
        } else {
            v15_1.MisterOn = 0;
        }
        if ((v9 & 8) != 0) {
            v15_1.Aux1On = 1;
        } else {
            v15_1.Aux1On = 0;
        }
        if ((v9 & 16) != 0) {
            v15_1.Aux2On = 1;
        } else {
            v15_1.Aux2On = 0;
        }
        if ((v5 < 1) && ((v6 < 1) && ((v7 & 3) < 1))) {
            v15_1.PumpStateStatus = com.balboawatergroup.BalboaSpa.PumpState.Off;
        } else {
            if ((v4 & 48) != 0) {
                v15_1.PumpStateStatus = com.balboawatergroup.BalboaSpa.PumpState.LowHeat;
            } else {
                v15_1.PumpStateStatus = com.balboawatergroup.BalboaSpa.PumpState.Low;
            }
        }
        int v23 = (p26[27] & 240);
        if (v23 != 0) {
            if (v23 != 16) {
                if (v23 != 32) {
                    if (v23 != 48) {
                        if (v23 != 64) {
                            if (v23 == 80) {
                                v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.Panel;
                            }
                        } else {
                            v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.Hold;
                        }
                    } else {
                        v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.Prime;
                    }
                } else {
                    v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.Startup;
                }
            } else {
                v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.SpaNotCommunicating;
            }
        } else {
            v15_1.WifiState = com.balboawatergroup.BalboaSpa.SpaWifiState.Ok;
        }
        return v15_1;
    }

    public static com.balboawatergroup.BalboaSpa.SpaSystemInformation ParseSystemInformation(byte[] p3)
    {
        com.balboawatergroup.BalboaSpa.SpaSystemInformation v1_1 = new com.balboawatergroup.BalboaSpa.SpaSystemInformation();
        v1_1.isOldVersion = 0;
        if (p3[7] < 6) {
            v1_1.isOldVersion = 1;
        }
        return v1_1;
    }
}
