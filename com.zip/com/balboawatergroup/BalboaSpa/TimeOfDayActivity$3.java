package com.balboawatergroup.BalboaSpa;
 class TimeOfDayActivity$3 implements android.view.View$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.TimeOfDayActivity this$0;

    TimeOfDayActivity$3(com.balboawatergroup.BalboaSpa.TimeOfDayActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p2)
    {
        com.balboawatergroup.BalboaSpa.TimeOfDayActivity.access$100(this.this$0);
        return;
    }
}
