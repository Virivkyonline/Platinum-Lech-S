package com.balboawatergroup.BalboaSpa;
public class SpaSystemInformation implements java.io.Serializable {
    private static final long serialVersionUID;
    public boolean isOldVersion;

    public SpaSystemInformation()
    {
        return;
    }
}
