package com.balboawatergroup.BalboaSpa;
 class DigiMessageDialogFragment$2 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment this$0;

    DigiMessageDialogFragment$2(com.balboawatergroup.BalboaSpa.DigiMessageDialogFragment p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.content.DialogInterface p1, int p2)
    {
        return;
    }
}
