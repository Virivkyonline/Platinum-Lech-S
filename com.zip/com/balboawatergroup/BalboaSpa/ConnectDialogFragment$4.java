package com.balboawatergroup.BalboaSpa;
 class ConnectDialogFragment$4 extends java.util.TimerTask {
    final synthetic com.balboawatergroup.BalboaSpa.ConnectDialogFragment this$0;
    final synthetic android.os.Handler val$handler;

    ConnectDialogFragment$4(com.balboawatergroup.BalboaSpa.ConnectDialogFragment p1, android.os.Handler p2)
    {
        this.this$0 = p1;
        this.val$handler = p2;
        return;
    }

    public void run()
    {
        this.val$handler.post(new com.balboawatergroup.BalboaSpa.ConnectDialogFragment$4$1(this));
        return;
    }
}
