package com.balboawatergroup.BalboaSpa;
public final enum class PanelRequestType extends java.lang.Enum {
    private static final synthetic com.balboawatergroup.BalboaSpa.PanelRequestType[] $VALUES;
    public static final enum com.balboawatergroup.BalboaSpa.PanelRequestType DeviceConfiguration;
    public static final enum com.balboawatergroup.BalboaSpa.PanelRequestType FilterCycles;
    public static final enum com.balboawatergroup.BalboaSpa.PanelRequestType SetupParameters;
    public static final enum com.balboawatergroup.BalboaSpa.PanelRequestType SystemInfo;

    static PanelRequestType()
    {
        com.balboawatergroup.BalboaSpa.PanelRequestType.SystemInfo = new com.balboawatergroup.BalboaSpa.PanelRequestType("SystemInfo", 0);
        com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles = new com.balboawatergroup.BalboaSpa.PanelRequestType("FilterCycles", 1);
        com.balboawatergroup.BalboaSpa.PanelRequestType.SetupParameters = new com.balboawatergroup.BalboaSpa.PanelRequestType("SetupParameters", 2);
        com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration = new com.balboawatergroup.BalboaSpa.PanelRequestType("DeviceConfiguration", 3);
        com.balboawatergroup.BalboaSpa.PanelRequestType[] v0_6 = new com.balboawatergroup.BalboaSpa.PanelRequestType[4];
        v0_6[0] = com.balboawatergroup.BalboaSpa.PanelRequestType.SystemInfo;
        v0_6[1] = com.balboawatergroup.BalboaSpa.PanelRequestType.FilterCycles;
        v0_6[2] = com.balboawatergroup.BalboaSpa.PanelRequestType.SetupParameters;
        v0_6[3] = com.balboawatergroup.BalboaSpa.PanelRequestType.DeviceConfiguration;
        com.balboawatergroup.BalboaSpa.PanelRequestType.$VALUES = v0_6;
        return;
    }

    private PanelRequestType(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.balboawatergroup.BalboaSpa.PanelRequestType valueOf(String p1)
    {
        return ((com.balboawatergroup.BalboaSpa.PanelRequestType) Enum.valueOf(com.balboawatergroup.BalboaSpa.PanelRequestType, p1));
    }

    public static com.balboawatergroup.BalboaSpa.PanelRequestType[] values()
    {
        return ((com.balboawatergroup.BalboaSpa.PanelRequestType[]) com.balboawatergroup.BalboaSpa.PanelRequestType.$VALUES.clone());
    }
}
