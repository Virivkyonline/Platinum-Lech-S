package com.balboawatergroup.BalboaSpa;
public class DisplayMessageActivity extends com.balboawatergroup.BalboaSpa.BaseActivity {
    private android.webkit.WebView webView;

    public DisplayMessageActivity()
    {
        return;
    }

    public void onCreate(android.os.Bundle p9)
    {
        super.onCreate(p9);
        this.setContentView(2130903044);
        try {
            android.content.pm.PackageInfo v2 = this.getPackageManager().getPackageInfo(this.getPackageName(), 0);
        } catch (android.content.pm.PackageManager$NameNotFoundException v0) {
            v0.printStackTrace();
        }
        String v3 = v2.versionName;
        this.webView = ((android.webkit.WebView) this.findViewById(2131230784));
        this.webView.loadData(new StringBuilder().append("<html><body style=\"font-family:sans-serif;font-size:15px;background-color:transparent;text-align:justify;color:#FFFFFF;\">Control your hot tub with your smartdevice. The Balboa Worldwide App (bwa&#0153;), is an app for your smart device (Android&#174; or iPhone&#174;) that allows you to access your hot tub via a direct connection anywhere in the local proximity of your tub, anywhere in your house that you can connect to your local WiFi network, or anywhere in the World you have an internet connection to your smart device via 3G, 4G, or WiFi hot spots.<br/><br/> For detailed installation and user guides visit <a style=\'color:#CFFFA4\' href=\'http://www.balboawater.com/bwa\'>www.balboawater.com/bwa </a></br></br> Version ").append(v3).append("</br></br>&#0169; Balboa Water Group 2013.</br>").append("</br></br>bwa&#0153;, BALBOA WATER GROUP and the Stylized Balboa Logo are registered trademarks or applications applied for in the US Patent & Trademark Office.  All Rights reserved.  All other product or service names are the property of their respective owners.</br>").append("</br></br>Products are covered under one of more of the following US Patents: 5332944, 5361215, 5550753, 5559720,   5,883,459, 6282370, 6590188, 7030343,   7,417,834 B2  & Canadian Pat 2342614 plus others. Other patents both foreign and domestic applied for and pending.</br>").append("</br></br> <a style=\'color:#CFFFA4\' href=\'http://www.balboawatergroup.com/Privacy-Policy\'> PRIVACY POLICY </a></br></br>").append("<a style=\'color:#CFFFA4\' href=\'http://www.balboawatergroup.com/Legal\'>TERMS OF USE</a> </br></br>").append("</body>").append("</html>").toString(), "text/html", 0);
        this.webView.setBackgroundColor(0);
        return;
    }

    public void onWindowFocusChanged(boolean p1)
    {
        return;
    }
}
