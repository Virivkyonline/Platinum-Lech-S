package com.balboawatergroup.BalboaSpa;
final class SpaController$1 implements java.lang.Runnable {

    SpaController$1()
    {
        return;
    }

    public void run()
    {
        com.balboawatergroup.BalboaSpa.SpaController.SetIDigiMode(com.balboawatergroup.BalboaSpa.SpaController.access$000());
        return;
    }
}
