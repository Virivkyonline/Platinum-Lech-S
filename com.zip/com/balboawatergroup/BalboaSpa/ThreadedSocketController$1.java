package com.balboawatergroup.BalboaSpa;
final class ThreadedSocketController$1 extends android.os.Handler {

    ThreadedSocketController$1()
    {
        return;
    }

    public void handleMessage(android.os.Message p11)
    {
        if (p11.what == 0) {
            switch (p11.getData().getInt("packetType")) {
                case 1:
                    com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentState = ((com.balboawatergroup.BalboaSpa.SpaControlState) p11.getData().getSerializable("state"));
                    android.content.Intent v0_1 = new android.content.Intent("spa-state-updated");
                    android.util.Log.d("sender", "Broadcasting state update message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v0_1);
                    if (com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentState.WifiState != com.balboawatergroup.BalboaSpa.SpaWifiState.Ok) {
                        android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(new android.content.Intent("returnToHome"));
                    }
                    break;
                case 2:
                    com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentConfiguration = ((com.balboawatergroup.BalboaSpa.SpaDeviceConfiguration) p11.getData().getSerializable("state"));
                    android.content.Intent v1_3 = new android.content.Intent("spa-state-updated");
                    android.util.Log.d("sender", "Broadcasting state update message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v1_3);
                case 3:
                case 5:
                default:
                    break;
                case 4:
                    com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentSystemInformation = ((com.balboawatergroup.BalboaSpa.SpaSystemInformation) p11.getData().getSerializable("state"));
                    android.content.Intent v5_1 = new android.content.Intent("spa-state-updated");
                    android.util.Log.d("sender", "Broadcasting state update message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v5_1);
                case 3:
                case 5:
                    break;
                case 6:
                    com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentFilterCycle = ((com.balboawatergroup.BalboaSpa.FilterCycle) p11.getData().getSerializable("state"));
                    android.content.Intent v4_1 = new android.content.Intent(com.balboawatergroup.BalboaSpa.BroadcastMessage.FilterCyclesUpdated.name());
                    android.util.Log.d("sender", "Broadcasting state update message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v4_1);
                    break;
                case 7:
                    com.balboawatergroup.BalboaSpa.SpaModuleIdentification v6_1 = ((com.balboawatergroup.BalboaSpa.SpaModuleIdentification) p11.getData().getSerializable("state"));
                    com.balboawatergroup.BalboaSpa.ThreadedSocketController.currentModuleIdentification = v6_1;
                    android.content.Intent v3_1 = new android.content.Intent("spa-module-identification-received");
                    com.balboawatergroup.BalboaSpa.SpaController.SaveDigiDeviceIdentifier(v6_1.iDigiDeviceID);
                    android.util.Log.d("sender", "Broadcasting module identification message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v3_1);
                    break;
                case 8:
                    android.content.Intent v2_0 = new android.content.Intent("connection-established");
                    android.util.Log.d("sender", "Broadcasting connection established message");
                    android.support.v4.content.LocalBroadcastManager.getInstance(com.balboawatergroup.BalboaSpa.ThreadedSocketController.access$000()).sendBroadcast(v2_0);
                    com.balboawatergroup.BalboaSpa.SpaController.SendDevicePresentQuery();
                    break;
            }
        }
        return;
    }
}
