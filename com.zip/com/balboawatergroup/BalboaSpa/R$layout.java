package com.balboawatergroup.BalboaSpa;
public final class R$layout {
    public static final int advancedsettings = 2130903040;
    public static final int configure = 2130903041;
    public static final int controls = 2130903042;
    public static final int filtercycles = 2130903043;
    public static final int info = 2130903044;
    public static final int instructions = 2130903045;
    public static final int main = 2130903046;
    public static final int settings = 2130903047;
    public static final int timeofday = 2130903048;

    public R$layout()
    {
        return;
    }
}
